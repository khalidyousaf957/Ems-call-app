# replit.md

## Overview

EMS Call is a mobile-first application that connects Emergency Medical Services (EMS) professionals with companies needing EMS staffing in specific cities/regions. The app has three user roles:

- **EMS professionals** (EMTs/Paramedics) who browse and apply for shift calls in their region
- **Companies** who post shift calls (e.g., Dialysis runs) visible only to EMS workers in the same city/region
- **Admin** who manages users (verify/suspend), views platform stats, and handles support tickets

Key features include region-based call matching, a negotiation system for pay rates, shift tracking with start/end functionality, support tickets, posting limits (2 free/day, $5 for 3rd+), and balance/payment tracking for both roles.

## User Preferences

Preferred communication style: Simple, everyday language.

## Recent Changes

- **Feb 2026**: Migrated from AsyncStorage (local-only) to full PostgreSQL backend with JWT authentication
  - Expanded Drizzle schema to cover all data models (users, calls, applications, shifts, negotiation messages, support tickets)
  - Implemented bcrypt password hashing and JWT tokens (12h expiry) for authentication
  - Built complete REST API for all CRUD operations
  - Created `lib/api.ts` as the API layer with token management
  - Updated `lib/storage.ts` to use backend APIs while maintaining same function signatures (minimized frontend changes)
  - Admin user auto-seeded on server startup
  - Fixed sign-out redirect loops with ref guards
  - CORS configured to allow Authorization header
- **Feb 2026**: Added withdrawal/payout system
  - Withdrawals table in schema (status: pending/completed/rejected, method: bank/cashapp)
  - User-facing withdrawal UI on EMS and Company profile screens with method selection and amount quick buttons
  - Admin "Payouts" tab for reviewing, approving, and rejecting withdrawal requests
  - Rejected withdrawals automatically restore user balance

## System Architecture

### Frontend — React Native (Expo)

- **Framework**: Expo SDK 54 with Expo Router v6 for file-based routing
- **Navigation Structure**: Tab-based layouts separated by role:
  - `(ems)/` — Tabs: Calls list, My Shifts, Profile
  - `(company)/` — Tabs: My Calls, Post Call, Profile
  - `(admin)/` — Tabs: Dashboard, Users, Support Tickets, Payouts, Announcements, Settings
  - `(auth)/` — Stack: Login, Create EMS, Create Company, Forgot Password
  - Modal screens: `call/[id]` (call details), `negotiate/[id]` (pay negotiation), `support` (support tickets)
- **State Management**: React Context for auth (`lib/auth-context.tsx`), TanStack React Query for server data fetching
- **API Layer**: `lib/api.ts` handles all HTTP requests with JWT token management (stored in AsyncStorage)
- **Fonts**: Inter (400, 500, 600, 700) via `@expo-google-fonts/inter`
- **UI Libraries**: `react-native-reanimated`, `react-native-gesture-handler`, `expo-haptics` for feedback, `expo-linear-gradient`, `expo-blur`/`expo-glass-effect` for tab bar styling
- **Platform support**: iOS, Android, and Web (with platform-specific adjustments for insets and keyboard handling)

### Backend — Express Server (Fully Implemented)

- **Server**: Express 5 running on port 5000 (`server/index.ts`)
- **Authentication**: JWT tokens with bcrypt password hashing (`server/auth.ts`)
  - `POST /api/auth/register` — Register EMS or Company user
  - `POST /api/auth/login` — Login with email/password, returns JWT token
  - Auth middleware validates Bearer token on protected routes
- **API Routes** (`server/routes.ts`):
  - `/api/calls` — CRUD for calls (region-filtered for EMS users)
  - `/api/applications` — Apply for calls, accept/reject applications
  - `/api/shifts` — Start/end shifts, track active shifts
  - `/api/negotiations` — Pay rate negotiation messages
  - `/api/support` — Support ticket management
  - `/api/admin/*` — Admin routes: stats, user management (verify/suspend), all users/tickets
  - `/api/user/profile` — Get/update user profile, balance, payment methods
- **Storage Layer** (`server/storage.ts`): `DatabaseStorage` class with full PostgreSQL CRUD via Drizzle ORM
- **Admin Seeding**: Admin user auto-created on startup (email: khalidyousaf957@gmail.com)
- **CORS**: Configured for Replit domains, localhost, with Authorization header support

### Database Schema — Drizzle ORM with PostgreSQL

- **Schema file**: `shared/schema.ts` — Full schema with tables:
  - `users` — All user types (ems/company/admin) with role-specific nullable fields
  - `calls` — Shift postings by companies with status, pay, location, dates
  - `applications` — EMS applications to calls with status tracking
  - `negotiationMessages` — Pay negotiation messages linked to applications
  - `shifts` — Active/completed shifts with start/end times
  - `supportTickets` — Support tickets with status and admin responses
- **ID Generation**: UUID via `gen_random_uuid()` in PostgreSQL
- **Drizzle config**: `drizzle.config.ts` uses `DATABASE_URL` environment variable
- **Migration**: Use `npm run db:push` to push schema changes

### Build & Development

- **Dev workflow**: Two processes run in parallel:
  - `npm run expo:dev` — Expo dev server for the mobile/web frontend (port 8081)
  - `npm run server:dev` — Express backend via tsx (port 5000)
- **Production build**: `npm run expo:static:build` builds the Expo web app, `npm run server:build` bundles the server with esbuild, `npm run server:prod` runs the production server
- **The server serves the built Expo web app as static files in production**

### Key Architectural Decisions

1. **API-backed storage with preserved interfaces**: `lib/storage.ts` keeps the same function signatures but now calls `lib/api.ts` which makes HTTP requests to the Express backend. This minimized changes needed in screen components.

2. **Role-based routing**: EMS, Company, and Admin users have completely separate tab navigators, with the root `index.tsx` redirecting based on `user.role` after login.

3. **Region segmentation**: All call visibility is filtered by the user's city+state. EMS users only see calls from companies in their same city/state.

4. **JWT Authentication**: Tokens stored in AsyncStorage on frontend, sent via `Authorization: Bearer <token>` header. 12-hour expiry. bcrypt (10 rounds) for password hashing.

5. **Shared schema directory**: `shared/` contains Drizzle schema and types shared between frontend and backend.

## External Dependencies

- **PostgreSQL**: Connected via `DATABASE_URL` environment variable (Replit built-in Neon-backed database)
- **Expo ecosystem**: Heavy use of Expo modules (image-picker, location, secure-store, haptics, crypto, etc.)
- **bcryptjs**: Password hashing (server-side)
- **jsonwebtoken**: JWT token generation and verification (server-side)
- **No payment processor**: Payment/balance features (posting fees, shift pay, transfers to Zelle/CashApp) are simulated with no real payment integration
- **No email service**: Forgot password flow is simulated (shows success UI but doesn't actually send emails)
