import type { Express, Request, Response } from "express";
import { createServer, type Server } from "node:http";
import bcrypt from "bcryptjs";
import { signToken, authMiddleware, adminOnly, type JwtPayload } from "./auth";
import * as storage from "./storage";

function getUser(req: Request): JwtPayload {
  return (req as any).user;
}

export async function seedAdmin() {
  const email = "khalidyousaf957@gmail.com";
  const existing = await storage.getUserByEmail(email);
  if (existing) return;

  const hashedPassword = await bcrypt.hash("Yousafkhalidali8138413343f", 10);
  await storage.createUser({
    role: "admin",
    email,
    password: hashedPassword,
    fullName: "App Owner",
  });
  console.log("Admin user seeded");
}

export async function registerRoutes(app: Express): Promise<Server> {
  await seedAdmin();

  app.post("/api/auth/register", async (req: Request, res: Response) => {
    try {
      const { email, password, role, ...rest } = req.body;
      if (!email || !password || !role) {
        return res.status(400).json({ message: "Email, password, and role are required" });
      }
      if (role === "admin") {
        return res.status(403).json({ message: "Cannot register as admin" });
      }

      const existing = await storage.getUserByEmail(email);
      if (existing) {
        return res.status(409).json({ message: "An account with this email already exists" });
      }

      const hashedPassword = await bcrypt.hash(password, 10);
      const user = await storage.createUser({
        ...rest,
        email,
        password: hashedPassword,
        role,
      });

      const token = signToken({ id: user.id, role: user.role });
      const { password: _, ...safeUser } = user;
      res.status(201).json({ token, user: safeUser });
    } catch (err: any) {
      res.status(500).json({ message: err.message || "Registration failed" });
    }
  });

  app.post("/api/auth/login", async (req: Request, res: Response) => {
    try {
      const { email, password } = req.body;
      if (!email || !password) {
        return res.status(400).json({ message: "Email and password are required" });
      }

      const user = await storage.getUserByEmail(email);
      if (!user) {
        return res.status(404).json({ message: "No account found with this email" });
      }

      const isMatch = await bcrypt.compare(password, user.password);
      if (!isMatch) {
        return res.status(401).json({ message: "Incorrect password" });
      }

      if (user.isSuspended) {
        return res.status(403).json({ message: "Your account has been suspended" });
      }

      const token = signToken({ id: user.id, role: user.role });
      const { password: _, ...safeUser } = user;
      res.json({ token, user: safeUser });
    } catch (err: any) {
      res.status(500).json({ message: err.message || "Login failed" });
    }
  });

  app.post("/api/auth/admin/login", async (req: Request, res: Response) => {
    try {
      const { email, password } = req.body;
      const admin = await storage.getUserByEmail(email);
      if (!admin || admin.role !== "admin") {
        return res.status(403).json({ message: "Access denied" });
      }

      const isMatch = await bcrypt.compare(password, admin.password);
      if (!isMatch) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      const token = signToken({ id: admin.id, role: admin.role });
      const { password: _, ...safeUser } = admin;
      res.json({ token, user: safeUser });
    } catch (err: any) {
      res.status(500).json({ message: err.message || "Login failed" });
    }
  });

  app.get("/api/auth/me", authMiddleware, async (req: Request, res: Response) => {
    try {
      const { id } = getUser(req);
      const user = await storage.getUserById(id);
      if (!user) return res.status(404).json({ message: "User not found" });

      const { password: _, ...safeUser } = user;
      res.json(safeUser);
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.put("/api/auth/me", authMiddleware, async (req: Request, res: Response) => {
    try {
      const { id } = getUser(req);
      const { password, role, id: _, ...updates } = req.body;
      const user = await storage.updateUser(id, updates);
      if (!user) return res.status(404).json({ message: "User not found" });

      const { password: __, ...safeUser } = user;
      res.json(safeUser);
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.post("/api/auth/reset-password", async (req: Request, res: Response) => {
    try {
      const { email } = req.body;
      const user = await storage.getUserByEmail(email);
      res.json({ success: !!user });
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.get("/api/calls", authMiddleware, async (req: Request, res: Response) => {
    try {
      const { role } = getUser(req);
      const { city, state } = req.query;

      if (role === "ems") {
        if (!city || !state) {
          return res.status(400).json({ message: "City and state are required to view calls" });
        }
        const regionCalls = await storage.getCallsByRegion(city as string, state as string);
        return res.json(regionCalls);
      }

      if (role === "admin") {
        const allCalls = await storage.getAllCalls();
        return res.json(allCalls);
      }

      if (city && state) {
        const regionCalls = await storage.getCallsByRegion(city as string, state as string);
        return res.json(regionCalls);
      }
      const allCalls = await storage.getAllCalls();
      res.json(allCalls);
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.get("/api/calls/company", authMiddleware, async (req: Request, res: Response) => {
    try {
      const { id } = getUser(req);
      const companyCalls = await storage.getCallsByCompany(id);
      res.json(companyCalls);
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.post("/api/calls", authMiddleware, async (req: Request, res: Response) => {
    try {
      const { id, role } = getUser(req);
      if (role !== "company") {
        return res.status(403).json({ message: "Only companies can post calls" });
      }

      const company = await storage.getUserById(id);
      if (!company) return res.status(404).json({ message: "Company not found" });

      const todayCount = await storage.getCompanyCallsToday(id);
      const call = await storage.createCall({
        ...req.body,
        companyId: id,
        city: company.city!,
        state: company.state!,
        companyName: company.companyName || req.body.companyName,
      });
      res.status(201).json({ call, postsToday: todayCount + 1 });
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.get("/api/calls/:id", authMiddleware, async (req: Request, res: Response) => {
    try {
      const call = await storage.getCallById(req.params.id as string);
      if (!call) return res.status(404).json({ message: "Call not found" });
      res.json(call);
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.put("/api/calls/:id", authMiddleware, async (req: Request, res: Response) => {
    try {
      const { id, createdAt, ...updateData } = req.body;
      const call = await storage.updateCall(req.params.id as string, updateData);
      if (!call) return res.status(404).json({ message: "Call not found" });
      res.json(call);
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.post("/api/applications", authMiddleware, async (req: Request, res: Response) => {
    try {
      const { id, role } = getUser(req);
      if (role !== "ems") {
        return res.status(403).json({ message: "Only EMS workers can apply" });
      }
      const app = await storage.createApplication({ ...req.body, emsId: id });
      res.status(201).json(app);
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.get("/api/applications/call/:callId", authMiddleware, async (req: Request, res: Response) => {
    try {
      const apps = await storage.getApplicationsByCall(req.params.callId as string);
      res.json(apps);
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.get("/api/applications/ems", authMiddleware, async (req: Request, res: Response) => {
    try {
      const { id } = getUser(req);
      const apps = await storage.getApplicationsByEMS(id);
      res.json(apps);
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.get("/api/applications/:id", authMiddleware, async (req: Request, res: Response) => {
    try {
      const app = await storage.getApplicationById(req.params.id as string);
      if (!app) return res.status(404).json({ message: "Application not found" });

      const messages = await storage.getMessagesByApplication(app.id);
      res.json({ ...app, messages });
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.put("/api/applications/:id", authMiddleware, async (req: Request, res: Response) => {
    try {
      const app = await storage.updateApplication(req.params.id as string, req.body);
      if (!app) return res.status(404).json({ message: "Application not found" });
      res.json(app);
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.post("/api/applications/:id/messages", authMiddleware, async (req: Request, res: Response) => {
    try {
      const { id, role } = getUser(req);
      const msg = await storage.createNegotiationMessage({
        applicationId: req.params.id as string,
        senderId: id,
        senderRole: role,
        message: req.body.message,
        proposedPay: req.body.proposedPay,
      });
      res.status(201).json(msg);
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.get("/api/shifts/ems", authMiddleware, async (req: Request, res: Response) => {
    try {
      const { id } = getUser(req);
      const emsShifts = await storage.getShiftsByEMS(id);
      res.json(emsShifts);
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.get("/api/shifts/company", authMiddleware, async (req: Request, res: Response) => {
    try {
      const { id } = getUser(req);
      const companyShifts = await storage.getShiftsByCompany(id);
      res.json(companyShifts);
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.post("/api/shifts", authMiddleware, async (req: Request, res: Response) => {
    try {
      const shift = await storage.createShift(req.body);
      res.status(201).json(shift);
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.put("/api/shifts/:id", authMiddleware, async (req: Request, res: Response) => {
    try {
      const shift = await storage.updateShift(req.params.id as string, req.body);
      if (!shift) return res.status(404).json({ message: "Shift not found" });
      res.json(shift);
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.post("/api/support-tickets", authMiddleware, async (req: Request, res: Response) => {
    try {
      const ticket = await storage.createSupportTicket(req.body);
      res.status(201).json(ticket);
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.get("/api/support-tickets/mine", authMiddleware, async (req: Request, res: Response) => {
    try {
      const { id } = getUser(req);
      const tickets = await storage.getSupportTicketsByUser(id);
      res.json(tickets);
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.get("/api/admin/stats", authMiddleware, adminOnly, async (_req: Request, res: Response) => {
    try {
      const stats = await storage.getStats();
      res.json(stats);
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.get("/api/admin/users", authMiddleware, adminOnly, async (_req: Request, res: Response) => {
    try {
      const allUsers = await storage.getAllUsers();
      const safeUsers = allUsers.map(({ password, certificationImage, licenseImage, ...u }) => ({
        ...u,
        hasDocuments: !!(certificationImage || licenseImage),
      }));
      res.json(safeUsers);
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.get("/api/admin/users/:id/documents", authMiddleware, adminOnly, async (req: Request, res: Response) => {
    try {
      const user = await storage.getUserById(req.params.id as string);
      if (!user) return res.status(404).json({ message: "User not found" });
      res.json({
        certificationImage: user.certificationImage || null,
        licenseImage: user.licenseImage || null,
        licenseNumber: user.licenseNumber || null,
        certType: user.certType || null,
        fullName: user.fullName || null,
        companyName: user.companyName || null,
      });
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.put("/api/admin/users/:id", authMiddleware, adminOnly, async (req: Request, res: Response) => {
    try {
      const { isVerified, isSuspended } = req.body;
      const user = await storage.updateUser(req.params.id as string, { isVerified, isSuspended });
      if (!user) return res.status(404).json({ message: "User not found" });
      const { password: _, ...safeUser } = user;
      res.json(safeUser);
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.get("/api/admin/tickets", authMiddleware, adminOnly, async (_req: Request, res: Response) => {
    try {
      const tickets = await storage.getAllSupportTickets();
      res.json(tickets);
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.put("/api/admin/tickets/:id", authMiddleware, adminOnly, async (req: Request, res: Response) => {
    try {
      const ticket = await storage.updateSupportTicket(req.params.id as string, req.body);
      if (!ticket) return res.status(404).json({ message: "Ticket not found" });
      res.json(ticket);
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.get("/api/admin/calls", authMiddleware, adminOnly, async (_req: Request, res: Response) => {
    try {
      const allCalls = await storage.getAllCalls();
      res.json(allCalls);
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.delete("/api/admin/calls/:id", authMiddleware, adminOnly, async (req: Request, res: Response) => {
    try {
      const deleted = await storage.deleteCall(req.params.id as string);
      if (!deleted) return res.status(404).json({ message: "Call not found" });
      res.json({ message: "Call removed" });
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.get("/api/admin/shifts", authMiddleware, adminOnly, async (_req: Request, res: Response) => {
    try {
      const allShifts = await storage.getAllShifts();
      res.json(allShifts);
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.get("/api/admin/applications", authMiddleware, adminOnly, async (_req: Request, res: Response) => {
    try {
      const allApps = await storage.getAllApplications();
      res.json(allApps);
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.post("/api/admin/announcements", authMiddleware, adminOnly, async (req: Request, res: Response) => {
    try {
      const { title, message, image, city, state } = req.body;
      if (!title || !message) return res.status(400).json({ message: "Title and message are required" });
      const ann = await storage.createAnnouncement({ title, message, image: image || null, city: city || null, state: state || null });
      res.status(201).json(ann);
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.get("/api/admin/announcements", authMiddleware, adminOnly, async (_req: Request, res: Response) => {
    try {
      const all = await storage.getAllAnnouncements();
      res.json(all);
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.delete("/api/admin/announcements/:id", authMiddleware, adminOnly, async (req: Request, res: Response) => {
    try {
      const deleted = await storage.deleteAnnouncement(req.params.id as string);
      if (!deleted) return res.status(404).json({ message: "Announcement not found" });
      res.json({ message: "Announcement removed" });
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.post("/api/ad-unlock-request", authMiddleware, async (req: Request, res: Response) => {
    try {
      const { id, role } = getUser(req);
      if (role !== "company") {
        return res.status(403).json({ message: "Only companies can request ad unlock" });
      }
      const company = await storage.getUserById(id);
      if (!company) return res.status(404).json({ message: "User not found" });
      if (company.adsUnlocked) {
        return res.status(400).json({ message: "Ads are already unlocked for your account" });
      }
      const existing = await storage.getAdUnlockRequestsByCompany(id);
      const pending = existing.find(r => r.status === "pending");
      if (pending) {
        return res.status(400).json({ message: "You already have a pending unlock request" });
      }
      const request = await storage.createAdUnlockRequest({
        companyId: id,
        companyName: company.companyName || company.fullName || "Company",
      });
      res.status(201).json(request);
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.get("/api/ad-unlock-request/mine", authMiddleware, async (req: Request, res: Response) => {
    try {
      const { id } = getUser(req);
      const requests = await storage.getAdUnlockRequestsByCompany(id);
      res.json(requests);
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.get("/api/admin/ad-unlock-requests", authMiddleware, adminOnly, async (_req: Request, res: Response) => {
    try {
      const requests = await storage.getAllAdUnlockRequests();
      res.json(requests);
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.post("/api/admin/ad-unlock-requests/:id/approve", authMiddleware, adminOnly, async (req: Request, res: Response) => {
    try {
      const request = await storage.getAdUnlockRequestById(req.params.id as string);
      if (!request) return res.status(404).json({ message: "Request not found" });
      if (request.status !== "pending") return res.status(400).json({ message: "Request already processed" });
      await storage.updateAdUnlockRequest(request.id, { status: "approved", reviewedAt: new Date() });
      await storage.updateUser(request.companyId, { adsUnlocked: true });
      res.json({ message: "Ad unlock approved. Company can now post premium ads." });
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.post("/api/admin/ad-unlock-requests/:id/reject", authMiddleware, adminOnly, async (req: Request, res: Response) => {
    try {
      const request = await storage.getAdUnlockRequestById(req.params.id as string);
      if (!request) return res.status(404).json({ message: "Request not found" });
      if (request.status !== "pending") return res.status(400).json({ message: "Request already processed" });
      await storage.updateAdUnlockRequest(request.id, { status: "rejected", reviewedAt: new Date() });
      res.json({ message: "Ad unlock request rejected." });
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.post("/api/premium-ads", authMiddleware, async (req: Request, res: Response) => {
    try {
      const { id, role } = getUser(req);
      if (role !== "company") {
        return res.status(403).json({ message: "Only companies can create premium ads" });
      }
      const company = await storage.getUserById(id);
      if (!company) return res.status(404).json({ message: "User not found" });

      if (!company.adsUnlocked) {
        return res.status(403).json({ message: "Ads are not unlocked. Please pay the $69 fee and get approval from the app owner first." });
      }

      const { title, description, hourlyRate, daysNeeded, whyBest } = req.body;
      if (!title || !description || !hourlyRate || !daysNeeded || !whyBest) {
        return res.status(400).json({ message: "All fields are required" });
      }

      const now = new Date();
      const endDate = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);

      const ad = await storage.createPremiumAd({
        companyId: id,
        companyName: company.companyName || company.fullName || "Company",
        title,
        description,
        hourlyRate: Number(hourlyRate),
        daysNeeded: Number(daysNeeded),
        whyBest,
        city: company.city || "",
        state: company.state || "",
        paidAmount: 69,
        startDate: now,
        endDate,
      });

      res.status(201).json(ad);
    } catch (err: any) {
      res.status(500).json({ message: err.message || "Failed to create premium ad" });
    }
  });

  app.get("/api/premium-ads", authMiddleware, async (_req: Request, res: Response) => {
    try {
      const ads = await storage.getActivePremiumAds();
      res.json(ads);
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.get("/api/premium-ads/mine", authMiddleware, async (req: Request, res: Response) => {
    try {
      const { id } = getUser(req);
      const ads = await storage.getPremiumAdsByCompany(id);
      res.json(ads);
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.get("/api/admin/premium-ads", authMiddleware, adminOnly, async (_req: Request, res: Response) => {
    try {
      const ads = await storage.getAllPremiumAds();
      res.json(ads);
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.delete("/api/admin/premium-ads/:id", authMiddleware, adminOnly, async (req: Request, res: Response) => {
    try {
      const deleted = await storage.deletePremiumAd(req.params.id as string);
      if (!deleted) return res.status(404).json({ message: "Premium ad not found" });
      res.json({ message: "Premium ad removed" });
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.post("/api/withdrawals", authMiddleware, async (req: Request, res: Response) => {
    try {
      const { id } = getUser(req);
      const { amount, method } = req.body;

      if (!amount || !method) {
        return res.status(400).json({ message: "Amount and method are required" });
      }
      if (!["bank", "cashapp"].includes(method)) {
        return res.status(400).json({ message: "Method must be 'bank' or 'cashapp'" });
      }

      const user = await storage.getUserById(id);
      if (!user) return res.status(404).json({ message: "User not found" });

      if (user.balance < amount) {
        return res.status(400).json({ message: "Insufficient balance" });
      }

      await storage.updateUser(id, { balance: user.balance - amount });

      const withdrawal = await storage.createWithdrawal({
        userId: id,
        amount: Number(amount),
        method,
      });

      res.status(201).json({ message: "Withdrawal request submitted", withdrawal });
    } catch (err: any) {
      res.status(500).json({ message: err.message || "Withdrawal failed" });
    }
  });

  app.get("/api/withdrawals/mine", authMiddleware, async (req: Request, res: Response) => {
    try {
      const { id } = getUser(req);
      const list = await storage.getWithdrawalsByUser(id);
      res.json(list);
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.get("/api/admin/withdrawals", authMiddleware, adminOnly, async (_req: Request, res: Response) => {
    try {
      const allWithdrawals = await storage.getAllWithdrawals();
      const enriched = await Promise.all(allWithdrawals.map(async (w) => {
        const user = await storage.getUserById(w.userId);
        return {
          ...w,
          userName: user?.fullName || user?.companyName || user?.email || "Unknown",
          userRole: user?.role || "unknown",
          userEmail: user?.email || "",
        };
      }));
      res.json(enriched);
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.patch("/api/admin/withdrawals/:id/complete", authMiddleware, adminOnly, async (req: Request, res: Response) => {
    try {
      const withdrawal = await storage.updateWithdrawal(req.params.id as string, { status: "completed" });
      if (!withdrawal) return res.status(404).json({ message: "Withdrawal not found" });
      res.json({ message: "Withdrawal completed", withdrawal });
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.patch("/api/admin/withdrawals/:id/reject", authMiddleware, adminOnly, async (req: Request, res: Response) => {
    try {
      const withdrawal = await storage.getWithdrawalById(req.params.id as string);
      if (!withdrawal) return res.status(404).json({ message: "Withdrawal not found" });

      const user = await storage.getUserById(withdrawal.userId);
      if (user) {
        await storage.updateUser(user.id, { balance: user.balance + withdrawal.amount });
      }

      const updated = await storage.updateWithdrawal(withdrawal.id, { status: "rejected" });
      res.json({ message: "Withdrawal rejected & balance restored", withdrawal: updated });
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.get("/api/announcements", authMiddleware, async (req: Request, res: Response) => {
    try {
      const user = await storage.getUserById((req as any).user.id);
      if (!user) return res.status(404).json({ message: "User not found" });
      if (user.city && user.state) {
        const anns = await storage.getAnnouncementsByRegion(user.city, user.state);
        res.json(anns);
      } else {
        const anns = await storage.getAllAnnouncements();
        res.json(anns);
      }
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
