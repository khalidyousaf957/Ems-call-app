import React, { useState, useCallback } from 'react';
import { View, Text, FlatList, Pressable, StyleSheet, RefreshControl, Platform, Image } from 'react-native';
import { router } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import Colors from '@/constants/colors';
import { useAuth } from '@/lib/auth-context';
import { getCalls, Call, getApplicationsForEMS, getUserRegion, getAnnouncements, Announcement, getActivePremiumAds } from '@/lib/storage';
import { useFocusEffect } from 'expo-router';

export default function EMSCallsScreen() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const webTopInset = Platform.OS === 'web' ? 67 : 0;
  const [calls, setCalls] = useState<Call[]>([]);
  const [appliedCallIds, setAppliedCallIds] = useState<Set<string>>(new Set());
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [premiumAdCount, setPremiumAdCount] = useState(0);
  const [refreshing, setRefreshing] = useState(false);

  const loadData = useCallback(async () => {
    if (!user) return;
    const regionCalls = await getCalls(user.city, user.state);
    const openCalls = regionCalls.filter(c => c.status === 'open' || c.status === 'pending');
    setCalls(openCalls.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()));
    const apps = await getApplicationsForEMS(user.id);
    setAppliedCallIds(new Set(apps.map(a => a.callId)));
    try {
      const anns = await getAnnouncements();
      setAnnouncements(anns);
    } catch {}
    try {
      const ads = await getActivePremiumAds();
      setPremiumAdCount(ads.length);
    } catch {}
  }, [user]);

  useFocusEffect(useCallback(() => { loadData(); }, [loadData]));

  const onRefresh = async () => {
    setRefreshing(true);
    await loadData();
    setRefreshing(false);
  };

  const formatTime = (iso: string) => {
    const d = new Date(iso);
    return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  const formatDate = (iso: string) => {
    const d = new Date(iso);
    return d.toLocaleDateString([], { month: 'short', day: 'numeric' });
  };

  const renderCall = ({ item }: { item: Call }) => {
    const applied = appliedCallIds.has(item.id);
    return (
      <Pressable
        style={({ pressed }) => [styles.card, pressed && { opacity: 0.95, transform: [{ scale: 0.99 }] }]}
        onPress={() => router.push({ pathname: '/call/[id]', params: { id: item.id } })}
      >
        <View style={styles.cardHeader}>
          <View style={styles.companyBadge}>
            <Ionicons name="business" size={14} color={Colors.secondary} />
            <Text style={styles.companyName}>{item.companyName}</Text>
          </View>
          {applied && (
            <View style={styles.appliedBadge}>
              <Text style={styles.appliedText}>Applied</Text>
            </View>
          )}
        </View>

        <Text style={styles.jobType}>{item.jobType}</Text>

        <View style={styles.detailsRow}>
          <View style={styles.detailItem}>
            <Ionicons name="calendar-outline" size={14} color={Colors.textTertiary} />
            <Text style={styles.detailText}>{formatDate(item.startTime)}</Text>
          </View>
          <View style={styles.detailItem}>
            <Ionicons name="time-outline" size={14} color={Colors.textTertiary} />
            <Text style={styles.detailText}>{formatTime(item.startTime)} - {formatTime(item.endTime)}</Text>
          </View>
        </View>

        <View style={styles.detailsRow}>
          <View style={styles.detailItem}>
            <Ionicons name="location-outline" size={14} color={Colors.textTertiary} />
            <Text style={styles.detailText} numberOfLines={1}>{item.location}</Text>
          </View>
        </View>

        <View style={styles.cardFooter}>
          <View style={styles.footerTag}>
            <Ionicons name="shield-checkmark-outline" size={12} color={Colors.primary} />
            <Text style={styles.footerTagText}>{item.certRequired}</Text>
          </View>
          <View style={styles.footerTag}>
            <Ionicons name="people-outline" size={12} color={Colors.primary} />
            <Text style={styles.footerTagText}>{item.numberNeeded} needed</Text>
          </View>
        </View>
      </Pressable>
    );
  };

  return (
    <View style={styles.container}>
      <View style={[styles.header, { paddingTop: insets.top + webTopInset + 12 }]}>
        <View>
          <Text style={styles.greeting}>Available Calls</Text>
          <View style={styles.regionRow}>
            <Ionicons name="location" size={14} color={Colors.accent} />
            <Text style={styles.regionText}>{getUserRegion(user)}</Text>
          </View>
        </View>
        <View style={styles.headerRight}>
          <Pressable style={styles.headerBtn} onPress={() => router.push('/premium-ads')}>
            <Ionicons name="notifications" size={20} color={Colors.accent} />
            {premiumAdCount > 0 && (
              <View style={styles.bellBadge}>
                <Text style={styles.bellBadgeText}>{premiumAdCount > 9 ? '9+' : premiumAdCount}</Text>
              </View>
            )}
          </Pressable>
        </View>
      </View>

      <FlatList
        data={calls}
        renderItem={renderCall}
        keyExtractor={item => item.id}
        contentContainerStyle={[styles.listContent, calls.length === 0 && { flex: 1 }]}
        contentInsetAdjustmentBehavior="automatic"
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={Colors.primary} />}
        showsVerticalScrollIndicator={false}
        ListHeaderComponent={announcements.length > 0 ? (
          <View style={styles.announcementsSection}>
            {announcements.slice(0, 3).map(ann => (
              <View key={ann.id} style={styles.announcementCard}>
                <View style={styles.announcementIcon}>
                  <Ionicons name="megaphone" size={14} color={Colors.accent} />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={styles.announcementTitle}>{ann.title}</Text>
                  <Text style={styles.announcementMsg} numberOfLines={2}>{ann.message}</Text>
                  {ann.image && (
                    <Image source={{ uri: ann.image }} style={styles.announcementImage} />
                  )}
                </View>
              </View>
            ))}
          </View>
        ) : null}
        ListEmptyComponent={
          <View style={styles.emptyState}>
            <Ionicons name="megaphone-outline" size={48} color={Colors.textTertiary} />
            <Text style={styles.emptyTitle}>No Calls Available</Text>
            <Text style={styles.emptyText}>
              No calls posted in your region yet.{'\n'}Pull down to refresh.
            </Text>
          </View>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  header: {
    paddingHorizontal: 20,
    paddingBottom: 12,
    backgroundColor: Colors.surface,
    borderBottomWidth: 1,
    borderBottomColor: Colors.divider,
  },
  greeting: { fontSize: 24, fontFamily: 'Inter_700Bold', color: Colors.text },
  regionRow: { flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: 4 },
  regionText: { fontSize: 13, fontFamily: 'Inter_500Medium', color: Colors.accent },
  headerRight: { position: 'absolute', right: 20, bottom: 16 },
  headerBtn: {
    width: 36,
    height: 36,
    borderRadius: 10,
    backgroundColor: 'rgba(27,58,92,0.08)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  listContent: { padding: 16, paddingBottom: 100, gap: 12 },
  card: {
    backgroundColor: Colors.surface,
    borderRadius: 16,
    padding: 16,
    gap: 10,
    borderWidth: 1,
    borderColor: Colors.cardBorder,
  },
  cardHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  companyBadge: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  companyName: { fontSize: 13, fontFamily: 'Inter_500Medium', color: Colors.secondary },
  appliedBadge: {
    backgroundColor: 'rgba(46,204,113,0.1)',
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 6,
  },
  appliedText: { fontSize: 11, fontFamily: 'Inter_600SemiBold', color: Colors.success },
  jobType: { fontSize: 17, fontFamily: 'Inter_600SemiBold', color: Colors.text },
  detailsRow: { flexDirection: 'row', gap: 16 },
  detailItem: { flexDirection: 'row', alignItems: 'center', gap: 4, flex: 1 },
  detailText: { fontSize: 13, fontFamily: 'Inter_400Regular', color: Colors.textSecondary },
  cardFooter: { flexDirection: 'row', alignItems: 'center', gap: 8, marginTop: 4 },
  footerTag: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: 'rgba(27,58,92,0.06)',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
  },
  footerTagText: { fontSize: 11, fontFamily: 'Inter_500Medium', color: Colors.primary },
  payRate: { fontSize: 15, fontFamily: 'Inter_700Bold', color: Colors.success, marginLeft: 'auto' },
  emptyState: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 12, paddingBottom: 60 },
  emptyTitle: { fontSize: 18, fontFamily: 'Inter_600SemiBold', color: Colors.text },
  emptyText: { fontSize: 14, fontFamily: 'Inter_400Regular', color: Colors.textSecondary, textAlign: 'center', lineHeight: 20 },
  bellBadge: {
    position: 'absolute', top: -4, right: -4,
    backgroundColor: Colors.accent, borderRadius: 10,
    minWidth: 18, height: 18, alignItems: 'center', justifyContent: 'center',
    paddingHorizontal: 4, borderWidth: 2, borderColor: Colors.surface,
  },
  bellBadgeText: { fontSize: 10, fontFamily: 'Inter_700Bold', color: Colors.white },
  announcementsSection: { gap: 8, marginBottom: 12 },
  announcementCard: {
    flexDirection: 'row', gap: 10, alignItems: 'flex-start',
    backgroundColor: 'rgba(230,57,70,0.04)', borderRadius: 12, padding: 12,
    borderWidth: 1, borderColor: 'rgba(230,57,70,0.12)',
  },
  announcementIcon: {
    width: 28, height: 28, borderRadius: 14,
    backgroundColor: 'rgba(230,57,70,0.1)',
    alignItems: 'center', justifyContent: 'center', marginTop: 2,
  },
  announcementTitle: { fontSize: 13, fontFamily: 'Inter_600SemiBold', color: Colors.text },
  announcementMsg: { fontSize: 12, fontFamily: 'Inter_400Regular', color: Colors.textSecondary, marginTop: 2, lineHeight: 17 },
  announcementImage: { width: '100%', height: 120, borderRadius: 8, marginTop: 8, backgroundColor: Colors.background },
});
