import React, { useState, useCallback } from 'react';
import { View, Text, FlatList, Pressable, StyleSheet, Alert, Platform } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import Colors from '@/constants/colors';
import { useAuth } from '@/lib/auth-context';
import { getShiftsForEMS, getCall, updateShift, updateUser, Shift, Call } from '@/lib/storage';
import { useFocusEffect } from 'expo-router';
import * as Haptics from 'expo-haptics';

interface ShiftWithCall extends Shift {
  call?: Call;
}

export default function MyShiftsScreen() {
  const { user, refreshUser } = useAuth();
  const insets = useSafeAreaInsets();
  const webTopInset = Platform.OS === 'web' ? 67 : 0;
  const [shifts, setShifts] = useState<ShiftWithCall[]>([]);

  const loadData = useCallback(async () => {
    if (!user) return;
    const rawShifts = await getShiftsForEMS(user.id);
    const enriched = await Promise.all(rawShifts.map(async s => {
      const call = await getCall(s.callId);
      return { ...s, call };
    }));
    setShifts(enriched.sort((a, b) => new Date(b.startedAt).getTime() - new Date(a.startedAt).getTime()));
  }, [user]);

  useFocusEffect(useCallback(() => { loadData(); }, [loadData]));

  const handleEndShift = async (shift: ShiftWithCall) => {
    Alert.alert('End Shift', 'Are you sure you want to end this shift?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'End Shift',
        style: 'destructive',
        onPress: async () => {
          Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
          const updated: Shift = {
            ...shift,
            endedAt: new Date().toISOString(),
            status: 'ended_pending',
          };
          delete (updated as any).call;
          await updateShift(updated);

          if (user && user.role === 'ems') {
            const updatedUser = { ...user, balance: user.balance + shift.payAmount };
            await updateUser(updatedUser);
            await refreshUser();
          }
          await loadData();
        },
      },
    ]);
  };

  const formatDateTime = (iso: string) => {
    const d = new Date(iso);
    return `${d.toLocaleDateString([], { month: 'short', day: 'numeric' })} ${d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
  };

  const getStatusInfo = (status: string) => {
    switch (status) {
      case 'active': return { label: 'Active', color: Colors.success, bg: 'rgba(46,204,113,0.1)' };
      case 'ended_pending': return { label: 'Pending Confirm', color: Colors.warning, bg: 'rgba(243,156,18,0.1)' };
      case 'completed': return { label: 'Completed', color: Colors.secondary, bg: 'rgba(69,123,157,0.1)' };
      default: return { label: status, color: Colors.textSecondary, bg: Colors.inputBg };
    }
  };

  const renderShift = ({ item }: { item: ShiftWithCall }) => {
    const status = getStatusInfo(item.status);
    return (
      <View style={styles.card}>
        <View style={styles.cardHeader}>
          <Text style={styles.jobType}>{item.call?.jobType || 'Shift'}</Text>
          <View style={[styles.statusBadge, { backgroundColor: status.bg }]}>
            <Text style={[styles.statusText, { color: status.color }]}>{status.label}</Text>
          </View>
        </View>

        <View style={styles.detailRow}>
          <Ionicons name="business-outline" size={14} color={Colors.textTertiary} />
          <Text style={styles.detailText}>{item.call?.companyName || 'Unknown'}</Text>
        </View>

        <View style={styles.detailRow}>
          <Ionicons name="time-outline" size={14} color={Colors.textTertiary} />
          <Text style={styles.detailText}>Started: {formatDateTime(item.startedAt)}</Text>
        </View>

        {item.endedAt && (
          <View style={styles.detailRow}>
            <Ionicons name="checkmark-circle-outline" size={14} color={Colors.textTertiary} />
            <Text style={styles.detailText}>Ended: {formatDateTime(item.endedAt)}</Text>
          </View>
        )}

        <View style={styles.cardFooter}>
          <Text style={styles.payAmount}>${item.payAmount.toFixed(2)}</Text>
          {item.status === 'active' && (
            <Pressable
              style={({ pressed }) => [styles.endBtn, pressed && { opacity: 0.8 }]}
              onPress={() => handleEndShift(item)}
            >
              <Ionicons name="stop-circle" size={18} color={Colors.white} />
              <Text style={styles.endBtnText}>End Shift</Text>
            </Pressable>
          )}
        </View>
      </View>
    );
  };

  return (
    <View style={styles.container}>
      <View style={[styles.header, { paddingTop: insets.top + webTopInset + 12 }]}>
        <Text style={styles.title}>My Shifts</Text>
      </View>

      <FlatList
        data={shifts}
        renderItem={renderShift}
        keyExtractor={item => item.id}
        contentContainerStyle={[styles.listContent, shifts.length === 0 && { flex: 1 }]}
        contentInsetAdjustmentBehavior="automatic"
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={
          <View style={styles.emptyState}>
            <Ionicons name="time-outline" size={48} color={Colors.textTertiary} />
            <Text style={styles.emptyTitle}>No Shifts Yet</Text>
            <Text style={styles.emptyText}>Your shift history will appear here once you start working calls.</Text>
          </View>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  header: {
    paddingHorizontal: 20,
    paddingBottom: 12,
    backgroundColor: Colors.surface,
    borderBottomWidth: 1,
    borderBottomColor: Colors.divider,
  },
  title: { fontSize: 24, fontFamily: 'Inter_700Bold', color: Colors.text },
  listContent: { padding: 16, paddingBottom: 100, gap: 12 },
  card: {
    backgroundColor: Colors.surface,
    borderRadius: 16,
    padding: 16,
    gap: 8,
    borderWidth: 1,
    borderColor: Colors.cardBorder,
  },
  cardHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  jobType: { fontSize: 16, fontFamily: 'Inter_600SemiBold', color: Colors.text },
  statusBadge: { paddingHorizontal: 8, paddingVertical: 3, borderRadius: 6 },
  statusText: { fontSize: 11, fontFamily: 'Inter_600SemiBold' },
  detailRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  detailText: { fontSize: 13, fontFamily: 'Inter_400Regular', color: Colors.textSecondary },
  cardFooter: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 4 },
  payAmount: { fontSize: 18, fontFamily: 'Inter_700Bold', color: Colors.success },
  endBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: Colors.accent,
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 10,
  },
  endBtnText: { fontSize: 13, fontFamily: 'Inter_600SemiBold', color: Colors.white },
  emptyState: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 12, paddingBottom: 60 },
  emptyTitle: { fontSize: 18, fontFamily: 'Inter_600SemiBold', color: Colors.text },
  emptyText: { fontSize: 14, fontFamily: 'Inter_400Regular', color: Colors.textSecondary, textAlign: 'center', lineHeight: 20 },
});
