import React, { useState, useCallback } from 'react';
import {
  View, Text, TextInput, Pressable, StyleSheet, ScrollView, Platform,
  Alert, KeyboardAvoidingView, ActivityIndicator,
} from 'react-native';
import { router, useFocusEffect } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import Colors from '@/constants/colors';
import { useAuth } from '@/lib/auth-context';
import { createPremiumAd, requestAdUnlock, getMyAdUnlockRequests, AdUnlockRequest } from '@/lib/storage';

export default function CreatePremiumAdScreen() {
  const { user, refreshUser } = useAuth();
  const insets = useSafeAreaInsets();
  const webTopInset = Platform.OS === 'web' ? 67 : 0;
  const webBottomInset = Platform.OS === 'web' ? 34 : 0;

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [daysNeeded, setDaysNeeded] = useState('');
  const [whyBest, setWhyBest] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [unlockRequests, setUnlockRequests] = useState<AdUnlockRequest[]>([]);
  const [requestingUnlock, setRequestingUnlock] = useState(false);

  const adsUnlocked = user && user.role === 'company' ? (user as any).adsUnlocked : false;

  const loadRequests = useCallback(async () => {
    try {
      const reqs = await getMyAdUnlockRequests();
      setUnlockRequests(reqs);
    } catch {}
  }, []);

  useFocusEffect(useCallback(() => { loadRequests(); }, [loadRequests]));

  const pendingRequest = unlockRequests.find(r => r.status === 'pending');

  const handleRequestUnlock = async () => {
    setRequestingUnlock(true);
    try {
      await requestAdUnlock();
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      Alert.alert('Request Sent', 'Your ad unlock request has been sent. The app owner will review and confirm once the $69 fee is received.');
      loadRequests();
    } catch (err: any) {
      Alert.alert('Error', err.message || 'Failed to send request');
    } finally {
      setRequestingUnlock(false);
    }
  };

  const handleSubmit = async () => {
    if (!title.trim() || !description.trim() || !daysNeeded.trim() || !whyBest.trim()) {
      Alert.alert('Missing Info', 'Please fill in all fields.');
      return;
    }
    const days = parseInt(daysNeeded, 10);
    if (isNaN(days) || days <= 0) {
      Alert.alert('Invalid Days', 'Please enter a valid number of days.');
      return;
    }

    setSubmitting(true);
    try {
      await createPremiumAd({ title: title.trim(), description: description.trim(), hourlyRate: 0, daysNeeded: days, whyBest: whyBest.trim() });
      if (refreshUser) await refreshUser();
      Alert.alert('Ad Published', 'Your premium advertisement is now live for 7 days. All users can see it.', [
        { text: 'OK', onPress: () => router.back() }
      ]);
    } catch (err: any) {
      Alert.alert('Error', err.message || 'Failed to create premium ad');
    } finally {
      setSubmitting(false);
    }
  };

  if (!adsUnlocked) {
    return (
      <View style={styles.container}>
        <View style={[styles.header, { paddingTop: insets.top + webTopInset + 12 }]}>
          <Pressable onPress={() => router.back()} style={styles.backBtn}>
            <Ionicons name="arrow-back" size={22} color={Colors.text} />
          </Pressable>
          <View style={{ flex: 1 }}>
            <Text style={styles.headerTitle}>Premium Ads</Text>
            <Text style={styles.headerSub}>Unlock to advertise your company</Text>
          </View>
        </View>

        <ScrollView contentContainerStyle={[styles.form, { paddingBottom: insets.bottom + webBottomInset + 40 }]}>
          <View style={styles.lockCard}>
            <View style={styles.lockIconWrap}>
              <Ionicons name="lock-closed" size={40} color={Colors.primary} />
            </View>
            <Text style={styles.lockTitle}>Unlock Premium Ads</Text>
            <Text style={styles.lockDesc}>
              Pay a one-time $69 fee to the app owner to unlock the ability to post premium advertisements visible to all EMS workers for 7 days each.
            </Text>

            <View style={styles.lockSteps}>
              <View style={styles.lockStep}>
                <View style={[styles.lockStepNum, { backgroundColor: 'rgba(27,58,92,0.1)' }]}>
                  <Text style={[styles.lockStepNumText, { color: Colors.primary }]}>1</Text>
                </View>
                <Text style={styles.lockStepText}>Pay $69 to the app owner</Text>
              </View>
              <View style={styles.lockStep}>
                <View style={[styles.lockStepNum, { backgroundColor: 'rgba(69,123,157,0.1)' }]}>
                  <Text style={[styles.lockStepNumText, { color: Colors.secondary }]}>2</Text>
                </View>
                <Text style={styles.lockStepText}>Tap the button below to send your unlock request</Text>
              </View>
              <View style={styles.lockStep}>
                <View style={[styles.lockStepNum, { backgroundColor: 'rgba(46,204,113,0.1)' }]}>
                  <Text style={[styles.lockStepNumText, { color: Colors.success }]}>3</Text>
                </View>
                <Text style={styles.lockStepText}>App owner confirms payment and unlocks your ads</Text>
              </View>
            </View>

            {pendingRequest ? (
              <View style={styles.pendingBox}>
                <Ionicons name="time" size={20} color={Colors.warning} />
                <View style={{ flex: 1 }}>
                  <Text style={styles.pendingTitle}>Request Pending</Text>
                  <Text style={styles.pendingText}>
                    Your unlock request was sent. Waiting for the app owner to confirm your $69 payment.
                  </Text>
                </View>
              </View>
            ) : (
              <Pressable
                style={[styles.unlockBtn, requestingUnlock && { opacity: 0.6 }]}
                onPress={handleRequestUnlock}
                disabled={requestingUnlock}
              >
                {requestingUnlock ? (
                  <ActivityIndicator color={Colors.white} />
                ) : (
                  <>
                    <Ionicons name="star" size={18} color={Colors.white} />
                    <Text style={styles.unlockBtnText}>Request Ad Unlock - $69</Text>
                  </>
                )}
              </Pressable>
            )}
          </View>
        </ScrollView>
      </View>
    );
  }

  return (
    <KeyboardAvoidingView
      style={{ flex: 1 }}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      keyboardVerticalOffset={90}
    >
      <View style={styles.container}>
        <View style={[styles.header, { paddingTop: insets.top + webTopInset + 12 }]}>
          <Pressable onPress={() => router.back()} style={styles.backBtn}>
            <Ionicons name="arrow-back" size={22} color={Colors.text} />
          </Pressable>
          <View style={{ flex: 1 }}>
            <Text style={styles.headerTitle}>Create Premium Ad</Text>
            <Text style={styles.headerSub}>Visible to all users for 7 days</Text>
          </View>
        </View>

        <ScrollView contentContainerStyle={[styles.form, { paddingBottom: insets.bottom + webBottomInset + 100 }]} showsVerticalScrollIndicator={false}>
          <View style={styles.unlockedBadge}>
            <Ionicons name="shield-checkmark" size={18} color={Colors.success} />
            <Text style={styles.unlockedText}>Ads Unlocked</Text>
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>Ad Title</Text>
            <TextInput
              style={styles.input}
              placeholder="e.g., Hiring EMTs - Great Benefits"
              placeholderTextColor={Colors.textTertiary}
              value={title}
              onChangeText={setTitle}
              maxLength={100}
            />
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>Description</Text>
            <TextInput
              style={[styles.input, styles.textArea]}
              placeholder="Describe the position and what makes your company great..."
              placeholderTextColor={Colors.textTertiary}
              value={description}
              onChangeText={setDescription}
              multiline
              numberOfLines={4}
              textAlignVertical="top"
              maxLength={500}
            />
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>Days Needed</Text>
            <TextInput
              style={styles.input}
              placeholder="7"
              placeholderTextColor={Colors.textTertiary}
              value={daysNeeded}
              onChangeText={setDaysNeeded}
              keyboardType="number-pad"
            />
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>Why Your Company Is Best</Text>
            <TextInput
              style={[styles.input, styles.textArea]}
              placeholder="Tell workers why they should choose your company..."
              placeholderTextColor={Colors.textTertiary}
              value={whyBest}
              onChangeText={setWhyBest}
              multiline
              numberOfLines={3}
              textAlignVertical="top"
              maxLength={300}
            />
          </View>

          <View style={styles.infoBox}>
            <Ionicons name="information-circle-outline" size={16} color={Colors.primary} />
            <Text style={styles.infoText}>Your ad will be shown to all EMS workers for 7 days with a notification badge on their home screen.</Text>
          </View>

          <Pressable
            style={[styles.submitBtn, submitting && styles.submitBtnDisabled]}
            onPress={handleSubmit}
            disabled={submitting}
          >
            {submitting ? (
              <ActivityIndicator color={Colors.white} />
            ) : (
              <>
                <Ionicons name="star" size={18} color={Colors.white} />
                <Text style={styles.submitBtnText}>Publish Ad</Text>
              </>
            )}
          </Pressable>
        </ScrollView>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  header: {
    paddingHorizontal: 20, paddingBottom: 14,
    backgroundColor: Colors.surface,
    borderBottomWidth: 1, borderBottomColor: Colors.divider,
    flexDirection: 'row', alignItems: 'center', gap: 12,
  },
  backBtn: {
    width: 36, height: 36, borderRadius: 10,
    backgroundColor: 'rgba(27,58,92,0.08)',
    alignItems: 'center', justifyContent: 'center',
  },
  headerTitle: { fontSize: 20, fontFamily: 'Inter_700Bold', color: Colors.text },
  headerSub: { fontSize: 12, fontFamily: 'Inter_400Regular', color: Colors.textSecondary, marginTop: 1 },
  form: { padding: 20, gap: 16 },
  lockCard: {
    backgroundColor: Colors.surface, borderRadius: 20, padding: 24,
    borderWidth: 1, borderColor: Colors.cardBorder, alignItems: 'center', gap: 16,
  },
  lockIconWrap: {
    width: 80, height: 80, borderRadius: 40,
    backgroundColor: 'rgba(27,58,92,0.06)',
    alignItems: 'center', justifyContent: 'center',
  },
  lockTitle: { fontSize: 22, fontFamily: 'Inter_700Bold', color: Colors.text },
  lockDesc: {
    fontSize: 14, fontFamily: 'Inter_400Regular', color: Colors.textSecondary,
    textAlign: 'center', lineHeight: 21,
  },
  lockSteps: { width: '100%', gap: 12, marginTop: 8 },
  lockStep: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  lockStepNum: {
    width: 32, height: 32, borderRadius: 16,
    alignItems: 'center', justifyContent: 'center',
  },
  lockStepNumText: { fontSize: 14, fontFamily: 'Inter_700Bold' },
  lockStepText: { flex: 1, fontSize: 14, fontFamily: 'Inter_500Medium', color: Colors.text },
  pendingBox: {
    width: '100%', flexDirection: 'row', alignItems: 'flex-start', gap: 12,
    backgroundColor: 'rgba(243,156,18,0.06)', borderRadius: 12, padding: 14,
    borderWidth: 1, borderColor: 'rgba(243,156,18,0.15)', marginTop: 8,
  },
  pendingTitle: { fontSize: 14, fontFamily: 'Inter_600SemiBold', color: Colors.warning },
  pendingText: { fontSize: 13, fontFamily: 'Inter_400Regular', color: Colors.textSecondary, marginTop: 2, lineHeight: 18 },
  unlockBtn: {
    width: '100%', flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8,
    backgroundColor: Colors.primary, borderRadius: 14, paddingVertical: 16, marginTop: 8,
  },
  unlockBtnText: { fontSize: 16, fontFamily: 'Inter_700Bold', color: Colors.white },
  unlockedBadge: {
    flexDirection: 'row', alignItems: 'center', gap: 6,
    backgroundColor: 'rgba(46,204,113,0.08)', borderRadius: 10, paddingHorizontal: 12, paddingVertical: 8,
    alignSelf: 'flex-start',
  },
  unlockedText: { fontSize: 13, fontFamily: 'Inter_600SemiBold', color: Colors.success },
  inputGroup: { gap: 6 },
  label: { fontSize: 13, fontFamily: 'Inter_600SemiBold', color: Colors.text },
  input: {
    backgroundColor: Colors.inputBg, borderRadius: 12, padding: 14,
    fontSize: 15, fontFamily: 'Inter_400Regular', color: Colors.text,
    borderWidth: 1, borderColor: Colors.inputBorder,
  },
  textArea: { minHeight: 90 },
  row: { flexDirection: 'row', gap: 12 },
  infoBox: {
    flexDirection: 'row', alignItems: 'flex-start', gap: 8,
    backgroundColor: 'rgba(27,58,92,0.04)', borderRadius: 10, padding: 12,
  },
  infoText: { flex: 1, fontSize: 12, fontFamily: 'Inter_400Regular', color: Colors.textSecondary, lineHeight: 17 },
  submitBtn: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8,
    backgroundColor: Colors.accent, borderRadius: 14, paddingVertical: 16, marginTop: 8,
  },
  submitBtnDisabled: { opacity: 0.5 },
  submitBtnText: { fontSize: 16, fontFamily: 'Inter_700Bold', color: Colors.white },
});
