import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, Pressable, StyleSheet, Alert, FlatList, Platform } from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import Colors from '@/constants/colors';
import { useAuth } from '@/lib/auth-context';
import {
  getApplication, updateApplication, Application, NegotiationMessage,
  getCall, updateCall, createShift, addNegotiationMessage,
} from '@/lib/storage';
import * as Haptics from 'expo-haptics';

export default function NegotiateScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const webTopInset = Platform.OS === 'web' ? 67 : 0;
  const [application, setApplication] = useState<Application | null>(null);
  const [message, setMessage] = useState('');
  const [proposedPay, setProposedPay] = useState('');

  useEffect(() => {
    if (id) loadApp();
  }, [id]);

  const loadApp = async () => {
    if (!id) return;
    const app = await getApplication(id);
    if (app) {
      setApplication(app);
      setProposedPay(app.proposedPay.toString());
    }
  };

  const handleSendMessage = async () => {
    if (!application || !user || !message.trim()) return;
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);

    await addNegotiationMessage(application.id, message.trim(), proposedPay ? parseFloat(proposedPay) : undefined);
    await updateApplication({ ...application, status: 'negotiating', proposedPay: proposedPay ? parseFloat(proposedPay) : application.proposedPay });
    await loadApp();
    setMessage('');
  };

  const handleFinalAccept = async () => {
    if (!application) return;
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);

    const updated: Application = { ...application, status: 'accepted' };
    await updateApplication(updated);

    const call = await getCall(application.callId);
    if (call) {
      await updateCall({ ...call, status: 'accepted' });
      await createShift({
        callId: call.id,
        applicationId: application.id,
        emsId: application.emsId,
        companyId: call.companyId,
        startedAt: new Date().toISOString(),
        payAmount: application.proposedPay,
        status: 'active',
      });
    }

    Alert.alert('Accepted', 'The negotiation is complete. A shift has been created.', [
      { text: 'OK', onPress: () => router.dismissAll() },
    ]);
  };

  const handleReject = async () => {
    if (!application) return;
    Alert.alert('Reject', 'Are you sure you want to reject this application?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Reject',
        style: 'destructive',
        onPress: async () => {
          const updated: Application = { ...application, status: 'rejected' };
          await updateApplication(updated);
          Alert.alert('Rejected', 'The application has been rejected.', [
            { text: 'OK', onPress: () => router.back() },
          ]);
        },
      },
    ]);
  };

  if (!application) return (
    <View style={[styles.container, styles.center]}>
      <Text style={styles.loadingText}>Loading...</Text>
    </View>
  );

  const renderMessage = ({ item }: { item: NegotiationMessage }) => {
    const isMe = item.senderId === user?.id;
    return (
      <View style={[styles.msgBubble, isMe ? styles.msgRight : styles.msgLeft]}>
        <Text style={styles.msgRole}>{item.senderRole === 'ems' ? 'EMS' : 'Company'}</Text>
        <Text style={[styles.msgText, isMe && { color: Colors.white }]}>{item.message}</Text>
        <Text style={[styles.msgTime, isMe && { color: 'rgba(255,255,255,0.5)' }]}>
          {new Date(item.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
        </Text>
      </View>
    );
  };

  return (
    <View style={styles.container}>
      <View style={[styles.topBar, { paddingTop: insets.top + webTopInset + 8 }]}>
        <Pressable style={styles.closeBtn} onPress={() => router.back()}>
          <Ionicons name="arrow-back" size={22} color={Colors.text} />
        </Pressable>
        <View style={styles.topBarCenter}>
          <Text style={styles.topBarTitle}>Negotiation</Text>
          <Text style={styles.topBarSub}>{application.emsName}</Text>
        </View>
        <View style={{ width: 36 }} />
      </View>


      <FlatList
        data={application.messages}
        renderItem={renderMessage}
        keyExtractor={item => item.id}
        contentContainerStyle={[styles.msgList, application.messages.length === 0 && { flex: 1, justifyContent: 'center' }]}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={
          <View style={styles.emptyMsgs}>
            <Ionicons name="chatbubbles-outline" size={40} color={Colors.textTertiary} />
            <Text style={styles.emptyMsgsText}>Start negotiating pay rate</Text>
          </View>
        }
      />

      <View style={[styles.inputArea, { paddingBottom: insets.bottom + (Platform.OS === 'web' ? 34 : 12) }]}>
        <View style={styles.actionBtns}>
          <Pressable style={[styles.finalBtn, styles.acceptFinalBtn]} onPress={handleFinalAccept}>
            <Ionicons name="checkmark" size={16} color={Colors.white} />
            <Text style={styles.finalBtnText}>Final Accept</Text>
          </Pressable>
          <Pressable style={[styles.finalBtn, styles.rejectFinalBtn]} onPress={handleReject}>
            <Ionicons name="close" size={16} color={Colors.white} />
            <Text style={styles.finalBtnText}>Reject</Text>
          </Pressable>
        </View>


        <View style={styles.msgInputRow}>
          <TextInput
            style={styles.msgInput}
            value={message}
            onChangeText={setMessage}
            placeholder="Type a message..."
            placeholderTextColor={Colors.textTertiary}
            multiline
          />
          <Pressable
            style={[styles.sendBtn, !message.trim() && { opacity: 0.5 }]}
            onPress={handleSendMessage}
            disabled={!message.trim()}
          >
            <Ionicons name="send" size={18} color={Colors.white} />
          </Pressable>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  center: { alignItems: 'center', justifyContent: 'center' },
  loadingText: { fontSize: 16, fontFamily: 'Inter_500Medium', color: Colors.textSecondary },
  topBar: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingBottom: 12,
    backgroundColor: Colors.surface,
    borderBottomWidth: 1,
    borderBottomColor: Colors.divider,
  },
  closeBtn: {
    width: 36,
    height: 36,
    borderRadius: 10,
    backgroundColor: Colors.inputBg,
    alignItems: 'center',
    justifyContent: 'center',
  },
  topBarCenter: { flex: 1, alignItems: 'center' },
  topBarTitle: { fontSize: 16, fontFamily: 'Inter_600SemiBold', color: Colors.text },
  topBarSub: { fontSize: 12, fontFamily: 'Inter_400Regular', color: Colors.textSecondary },
  payBar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 16,
    paddingVertical: 12,
    paddingHorizontal: 20,
    backgroundColor: Colors.surface,
    borderBottomWidth: 1,
    borderBottomColor: Colors.divider,
  },
  payItem: { alignItems: 'center', gap: 2 },
  payLabel: { fontSize: 11, fontFamily: 'Inter_500Medium', color: Colors.textTertiary, textTransform: 'uppercase' },
  payValue: { fontSize: 18, fontFamily: 'Inter_700Bold', color: Colors.text },
  msgList: { padding: 16, gap: 8 },
  emptyMsgs: { alignItems: 'center', gap: 8 },
  emptyMsgsText: { fontSize: 14, fontFamily: 'Inter_400Regular', color: Colors.textTertiary },
  msgBubble: { maxWidth: '80%', borderRadius: 14, padding: 12, gap: 4, marginBottom: 4 },
  msgLeft: { alignSelf: 'flex-start', backgroundColor: Colors.surface, borderWidth: 1, borderColor: Colors.cardBorder },
  msgRight: { alignSelf: 'flex-end', backgroundColor: Colors.primary },
  msgRole: { fontSize: 10, fontFamily: 'Inter_600SemiBold', color: Colors.textTertiary, textTransform: 'uppercase' },
  msgText: { fontSize: 14, fontFamily: 'Inter_400Regular', color: Colors.text, lineHeight: 20 },
  msgPay: { fontSize: 13, fontFamily: 'Inter_600SemiBold', color: Colors.success },
  msgTime: { fontSize: 10, fontFamily: 'Inter_400Regular', color: Colors.textTertiary, alignSelf: 'flex-end' },
  inputArea: {
    paddingHorizontal: 12,
    paddingTop: 8,
    backgroundColor: Colors.surface,
    borderTopWidth: 1,
    borderTopColor: Colors.divider,
    gap: 8,
  },
  actionBtns: { flexDirection: 'row', gap: 8 },
  finalBtn: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingVertical: 10,
    borderRadius: 10,
  },
  acceptFinalBtn: { backgroundColor: Colors.success },
  rejectFinalBtn: { backgroundColor: Colors.accent },
  finalBtnText: { fontSize: 13, fontFamily: 'Inter_600SemiBold', color: Colors.white },
  payInputRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: Colors.inputBg,
    borderRadius: 10,
    paddingHorizontal: 12,
    height: 40,
  },
  payInputLabel: { fontSize: 13, fontFamily: 'Inter_600SemiBold', color: Colors.textSecondary },
  payInput: { flex: 1, fontSize: 14, fontFamily: 'Inter_500Medium', color: Colors.text },
  msgInputRow: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    gap: 8,
  },
  msgInput: {
    flex: 1,
    backgroundColor: Colors.inputBg,
    borderRadius: 12,
    paddingHorizontal: 14,
    paddingVertical: 10,
    fontSize: 14,
    fontFamily: 'Inter_400Regular',
    color: Colors.text,
    maxHeight: 80,
  },
  sendBtn: {
    width: 40,
    height: 40,
    borderRadius: 12,
    backgroundColor: Colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
