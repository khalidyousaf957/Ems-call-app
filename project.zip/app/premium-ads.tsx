import React, { useState, useCallback } from 'react';
import { View, Text, FlatList, Pressable, StyleSheet, Platform, ActivityIndicator } from 'react-native';
import { router } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import Colors from '@/constants/colors';
import { useAuth } from '@/lib/auth-context';
import { getActivePremiumAds, PremiumAd } from '@/lib/storage';
import { useFocusEffect } from 'expo-router';

export default function PremiumAdsScreen() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const webTopInset = Platform.OS === 'web' ? 67 : 0;
  const [ads, setAds] = useState<PremiumAd[]>([]);
  const [loading, setLoading] = useState(true);

  const loadAds = useCallback(async () => {
    try {
      const result = await getActivePremiumAds();
      setAds(result);
    } catch {} finally {
      setLoading(false);
    }
  }, []);

  useFocusEffect(useCallback(() => { loadAds(); }, [loadAds]));

  const daysLeft = (endDate: string) => {
    const end = new Date(endDate).getTime();
    const now = Date.now();
    const diff = Math.ceil((end - now) / (1000 * 60 * 60 * 24));
    return Math.max(0, diff);
  };

  const renderAd = ({ item }: { item: PremiumAd }) => (
    <View style={styles.adCard}>
      <View style={styles.adBadgeRow}>
        <View style={styles.premiumBadge}>
          <Ionicons name="star" size={12} color="#FFD700" />
          <Text style={styles.premiumBadgeText}>PROMOTED</Text>
        </View>
        <Text style={styles.daysLeftText}>{daysLeft(item.endDate)}d left</Text>
      </View>

      <Text style={styles.adTitle}>{item.title}</Text>

      <View style={styles.companyRow}>
        <Ionicons name="business" size={14} color={Colors.secondary} />
        <Text style={styles.companyName}>{item.companyName}</Text>
        <Text style={styles.regionChip}>{item.city}, {item.state}</Text>
      </View>

      <Text style={styles.adDescription}>{item.description}</Text>

      <View style={styles.detailsGrid}>
        <View style={styles.detailBox}>
          <Ionicons name="calendar-outline" size={18} color={Colors.primary} />
          <Text style={styles.detailValue}>{item.daysNeeded} days</Text>
          <Text style={styles.detailLabel}>Duration</Text>
        </View>
      </View>

      <View style={styles.whySection}>
        <View style={styles.whyHeader}>
          <Ionicons name="trophy-outline" size={16} color={Colors.warning} />
          <Text style={styles.whyTitle}>Why Choose Us</Text>
        </View>
        <Text style={styles.whyText}>{item.whyBest}</Text>
      </View>
    </View>
  );

  return (
    <View style={styles.container}>
      <View style={[styles.header, { paddingTop: insets.top + webTopInset + 12 }]}>
        <Pressable onPress={() => router.back()} style={styles.backBtn}>
          <Ionicons name="arrow-back" size={22} color={Colors.text} />
        </Pressable>
        <View style={{ flex: 1 }}>
          <Text style={styles.headerTitle}>Featured Jobs</Text>
          <Text style={styles.headerSub}>Premium company advertisements</Text>
        </View>
        {user?.role === 'company' && (
          <Pressable onPress={() => router.push('/create-premium-ad')} style={styles.createBtn}>
            <Ionicons name="add" size={20} color={Colors.white} />
          </Pressable>
        )}
      </View>

      {loading ? (
        <View style={styles.centered}>
          <ActivityIndicator size="large" color={Colors.primary} />
        </View>
      ) : (
        <FlatList
          data={ads}
          renderItem={renderAd}
          keyExtractor={item => item.id}
          contentContainerStyle={[styles.listContent, ads.length === 0 && { flex: 1 }]}
          showsVerticalScrollIndicator={false}
          ListEmptyComponent={
            <View style={styles.emptyState}>
              <Ionicons name="star-outline" size={48} color={Colors.textTertiary} />
              <Text style={styles.emptyTitle}>No Featured Jobs</Text>
              <Text style={styles.emptyText}>
                {user?.role === 'company'
                  ? 'Promote your company to all EMS workers for $69/week.'
                  : 'No companies are currently running premium ads.'}
              </Text>
              {user?.role === 'company' && (
                <Pressable style={styles.ctaBtn} onPress={() => router.push('/create-premium-ad')}>
                  <Text style={styles.ctaBtnText}>Create Premium Ad</Text>
                </Pressable>
              )}
            </View>
          }
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  header: {
    paddingHorizontal: 20, paddingBottom: 14,
    backgroundColor: Colors.surface,
    borderBottomWidth: 1, borderBottomColor: Colors.divider,
    flexDirection: 'row', alignItems: 'center', gap: 12,
  },
  backBtn: {
    width: 36, height: 36, borderRadius: 10,
    backgroundColor: 'rgba(27,58,92,0.08)',
    alignItems: 'center', justifyContent: 'center',
  },
  headerTitle: { fontSize: 20, fontFamily: 'Inter_700Bold', color: Colors.text },
  headerSub: { fontSize: 12, fontFamily: 'Inter_400Regular', color: Colors.textSecondary, marginTop: 1 },
  createBtn: {
    width: 36, height: 36, borderRadius: 10,
    backgroundColor: Colors.accent,
    alignItems: 'center', justifyContent: 'center',
  },
  centered: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  listContent: { padding: 16, paddingBottom: 100, gap: 16 },
  adCard: {
    backgroundColor: Colors.surface, borderRadius: 16, padding: 16, gap: 12,
    borderWidth: 1.5, borderColor: 'rgba(255,215,0,0.3)',
  },
  adBadgeRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  premiumBadge: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    backgroundColor: 'rgba(255,215,0,0.12)', paddingHorizontal: 10, paddingVertical: 4, borderRadius: 8,
  },
  premiumBadgeText: { fontSize: 10, fontFamily: 'Inter_700Bold', color: '#B8860B', letterSpacing: 1 },
  daysLeftText: { fontSize: 12, fontFamily: 'Inter_500Medium', color: Colors.textTertiary },
  adTitle: { fontSize: 18, fontFamily: 'Inter_700Bold', color: Colors.text },
  companyRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  companyName: { fontSize: 14, fontFamily: 'Inter_500Medium', color: Colors.secondary },
  regionChip: {
    fontSize: 11, fontFamily: 'Inter_500Medium', color: Colors.textSecondary,
    backgroundColor: Colors.inputBg, paddingHorizontal: 8, paddingVertical: 2, borderRadius: 6, marginLeft: 'auto',
  },
  adDescription: { fontSize: 14, fontFamily: 'Inter_400Regular', color: Colors.textSecondary, lineHeight: 21 },
  detailsGrid: { flexDirection: 'row', gap: 12 },
  detailBox: {
    flex: 1, backgroundColor: Colors.inputBg, borderRadius: 12, padding: 14,
    alignItems: 'center', gap: 4,
  },
  detailValue: { fontSize: 16, fontFamily: 'Inter_700Bold', color: Colors.text },
  detailLabel: { fontSize: 11, fontFamily: 'Inter_400Regular', color: Colors.textTertiary },
  whySection: {
    backgroundColor: 'rgba(243,156,18,0.06)', borderRadius: 12, padding: 14, gap: 6,
    borderWidth: 1, borderColor: 'rgba(243,156,18,0.12)',
  },
  whyHeader: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  whyTitle: { fontSize: 13, fontFamily: 'Inter_600SemiBold', color: Colors.warning },
  whyText: { fontSize: 13, fontFamily: 'Inter_400Regular', color: Colors.textSecondary, lineHeight: 19 },
  emptyState: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 12, paddingBottom: 60, paddingHorizontal: 30 },
  emptyTitle: { fontSize: 18, fontFamily: 'Inter_600SemiBold', color: Colors.text },
  emptyText: { fontSize: 14, fontFamily: 'Inter_400Regular', color: Colors.textSecondary, textAlign: 'center', lineHeight: 20 },
  ctaBtn: {
    backgroundColor: Colors.accent, paddingHorizontal: 24, paddingVertical: 12, borderRadius: 12, marginTop: 8,
  },
  ctaBtnText: { fontSize: 14, fontFamily: 'Inter_600SemiBold', color: Colors.white },
});
