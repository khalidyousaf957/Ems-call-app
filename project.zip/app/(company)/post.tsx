import React, { useState, useCallback, useRef } from 'react';
import { View, Text, TextInput, Pressable, StyleSheet, Alert, ActivityIndicator, Platform, Modal, FlatList } from 'react-native';
import { router, useFocusEffect } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import Colors from '@/constants/colors';
import { useAuth } from '@/lib/auth-context';
import { createCall, getCompanyPostCount, JOB_TYPES, CertType, CompanyUser } from '@/lib/storage';
import { KeyboardAwareScrollViewCompat } from '@/components/KeyboardAwareScrollViewCompat';
import * as Haptics from 'expo-haptics';

function generateCalendarDays(year: number, month: number) {
  const firstDay = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const days: (number | null)[] = [];
  for (let i = 0; i < firstDay; i++) days.push(null);
  for (let i = 1; i <= daysInMonth; i++) days.push(i);
  return days;
}

const MONTH_NAMES = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
const DAY_HEADERS = ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'];

export default function PostCallScreen() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const webTopInset = Platform.OS === 'web' ? 67 : 0;
  const companyUser = user as CompanyUser;

  const [jobType, setJobType] = useState('');
  const [showJobTypes, setShowJobTypes] = useState(false);
  const [location, setLocation] = useState('');
  const [startDate, setStartDate] = useState('');
  const [startTimeStr, setStartTimeStr] = useState('');
  const [endTimeStr, setEndTimeStr] = useState('');
  const [certRequired, setCertRequired] = useState<CertType>('EMT');
  const [numberNeeded, setNumberNeeded] = useState('1');
  const [loading, setLoading] = useState(false);
  const [postsToday, setPostsToday] = useState(0);
  const [showCalendar, setShowCalendar] = useState(false);
  const submittingRef = useRef(false);

  const today = new Date();
  const [calYear, setCalYear] = useState(today.getFullYear());
  const [calMonth, setCalMonth] = useState(today.getMonth());

  useFocusEffect(useCallback(() => {
    if (user) getCompanyPostCount(user.id).then(setPostsToday);
  }, [user]));

  const handlePost = async () => {
    if (!jobType || !location.trim() || !startDate.trim() || !startTimeStr.trim() || !endTimeStr.trim()) {
      Alert.alert('Missing Fields', 'Please fill in all fields.');
      return;
    }

    if (postsToday >= 2) {
      Alert.alert(
        'Post Limit Reached',
        'You\'ve used your 2 free posts today. The 3rd post costs $5.',
        [
          { text: 'Cancel', style: 'cancel' },
          {
            text: 'Pay $5 & Post',
            onPress: () => submitCall(),
          },
        ]
      );
      return;
    }

    submitCall();
  };

  const submitCall = async () => {
    if (submittingRef.current) return;
    submittingRef.current = true;
    setLoading(true);
    try {
      const startTime = new Date(`${startDate}T${startTimeStr}:00`).toISOString();
      const endTime = new Date(`${startDate}T${endTimeStr}:00`).toISOString();

      await createCall({
        companyId: companyUser.id,
        companyName: companyUser.companyName,
        jobType,
        location: location.trim(),
        startTime,
        endTime,
        certRequired,
        numberNeeded: parseInt(numberNeeded) || 1,
        payRate: 0,
        city: companyUser.city,
        state: companyUser.state,
      });

      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      resetForm();
      Alert.alert('Call Posted', 'Your call has been posted and is visible to EMS in your region.');
      router.push('/(company)');
    } catch (err: any) {
      Alert.alert('Error', err.message);
    }
    setLoading(false);
    submittingRef.current = false;
  };

  const resetForm = () => {
    setJobType('');
    setLocation('');
    setStartDate('');
    setStartTimeStr('');
    setEndTimeStr('');
    setNumberNeeded('1');
  };

  const handleSelectDate = (day: number) => {
    const m = String(calMonth + 1).padStart(2, '0');
    const d = String(day).padStart(2, '0');
    setStartDate(`${calYear}-${m}-${d}`);
    setShowCalendar(false);
  };

  const goToPrevMonth = () => {
    if (calMonth === 0) {
      setCalMonth(11);
      setCalYear(calYear - 1);
    } else {
      setCalMonth(calMonth - 1);
    }
  };

  const goToNextMonth = () => {
    if (calMonth === 11) {
      setCalMonth(0);
      setCalYear(calYear + 1);
    } else {
      setCalMonth(calMonth + 1);
    }
  };

  const calendarDays = generateCalendarDays(calYear, calMonth);
  const todayStr = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;

  const formatDisplayDate = (dateStr: string) => {
    if (!dateStr) return '';
    const [y, m, d] = dateStr.split('-');
    const monthName = MONTH_NAMES[parseInt(m) - 1];
    return `${monthName} ${parseInt(d)}, ${y}`;
  };

  return (
    <>
      <KeyboardAwareScrollViewCompat
        style={styles.container}
        contentContainerStyle={[styles.content, { paddingTop: insets.top + webTopInset + 16, paddingBottom: insets.bottom + 100 }]}
        bottomOffset={60}
      >
        <View style={styles.headerArea}>
          <Text style={styles.title}>Post a Call</Text>
          <View style={styles.postCountRow}>
            <Ionicons name="megaphone" size={14} color={postsToday >= 2 ? Colors.accent : Colors.success} />
            <Text style={[styles.postCountText, postsToday >= 2 && { color: Colors.accent }]}>
              {postsToday}/2 free posts used today
            </Text>
          </View>
        </View>

        <View style={styles.form}>
          <View style={styles.inputGroup}>
            <Text style={styles.label}>Job Type</Text>
            <Pressable style={styles.selectBtn} onPress={() => setShowJobTypes(!showJobTypes)}>
              <Ionicons name="briefcase-outline" size={18} color={jobType ? Colors.text : Colors.textTertiary} />
              <Text style={[styles.selectText, !jobType && { color: Colors.textTertiary }]}>
                {jobType || 'Select job type'}
              </Text>
              <Ionicons name={showJobTypes ? "chevron-up" : "chevron-down"} size={16} color={Colors.textTertiary} />
            </Pressable>
            {showJobTypes && (
              <View style={styles.dropdownList}>
                {JOB_TYPES.map(j => (
                  <Pressable
                    key={j}
                    style={[styles.dropdownItem, jobType === j && styles.dropdownItemActive]}
                    onPress={() => { setJobType(j); setShowJobTypes(false); }}
                  >
                    <Text style={[styles.dropdownText, jobType === j && styles.dropdownTextActive]}>{j}</Text>
                    {jobType === j && <Ionicons name="checkmark" size={18} color={Colors.primary} />}
                  </Pressable>
                ))}
              </View>
            )}
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>Location</Text>
            <View style={styles.inputWrap}>
              <Ionicons name="location-outline" size={18} color={Colors.textTertiary} />
              <TextInput
                style={styles.input}
                placeholder="Enter pickup/job location"
                placeholderTextColor={Colors.textTertiary}
                value={location}
                onChangeText={setLocation}
              />
            </View>
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>Date</Text>
            <Pressable style={styles.selectBtn} onPress={() => setShowCalendar(true)}>
              <Ionicons name="calendar-outline" size={18} color={startDate ? Colors.text : Colors.textTertiary} />
              <Text style={[styles.selectText, !startDate && { color: Colors.textTertiary }]}>
                {startDate ? formatDisplayDate(startDate) : 'Select date'}
              </Text>
              <Ionicons name="chevron-down" size={16} color={Colors.textTertiary} />
            </Pressable>
          </View>

          <View style={styles.timeRow}>
            <View style={[styles.inputGroup, { flex: 1 }]}>
              <Text style={styles.label}>Start Time</Text>
              <View style={styles.inputWrap}>
                <Ionicons name="time-outline" size={18} color={Colors.textTertiary} />
                <TextInput
                  style={styles.input}
                  placeholder="08:00"
                  placeholderTextColor={Colors.textTertiary}
                  value={startTimeStr}
                  onChangeText={setStartTimeStr}
                />
              </View>
            </View>
            <View style={[styles.inputGroup, { flex: 1 }]}>
              <Text style={styles.label}>End Time</Text>
              <View style={styles.inputWrap}>
                <Ionicons name="time-outline" size={18} color={Colors.textTertiary} />
                <TextInput
                  style={styles.input}
                  placeholder="17:00"
                  placeholderTextColor={Colors.textTertiary}
                  value={endTimeStr}
                  onChangeText={setEndTimeStr}
                />
              </View>
            </View>
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>Certification Required</Text>
            <View style={styles.certRow}>
              {(['EMT', 'Paramedic'] as CertType[]).map(type => (
                <Pressable
                  key={type}
                  style={[styles.certChip, certRequired === type && styles.certChipActive]}
                  onPress={() => setCertRequired(type)}
                >
                  <Text style={[styles.certChipText, certRequired === type && styles.certChipTextActive]}>{type}</Text>
                </Pressable>
              ))}
            </View>
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>Number Needed</Text>
            <View style={styles.inputWrap}>
              <Ionicons name="people-outline" size={18} color={Colors.textTertiary} />
              <TextInput
                style={styles.input}
                placeholder="1"
                placeholderTextColor={Colors.textTertiary}
                value={numberNeeded}
                onChangeText={setNumberNeeded}
                keyboardType="number-pad"
              />
            </View>
          </View>

          <Pressable
            style={({ pressed }) => [styles.postBtn, pressed && { opacity: 0.9 }, loading && { opacity: 0.7 }]}
            onPress={handlePost}
            disabled={loading}
          >
            {loading ? <ActivityIndicator color={Colors.white} /> : (
              <>
                <Ionicons name="send" size={18} color={Colors.white} />
                <Text style={styles.postBtnText}>Post Call</Text>
              </>
            )}
          </Pressable>
        </View>
      </KeyboardAwareScrollViewCompat>

      <Modal visible={showCalendar} transparent animationType="fade" onRequestClose={() => setShowCalendar(false)}>
        <Pressable style={styles.modalOverlay} onPress={() => setShowCalendar(false)}>
          <Pressable style={styles.calendarCard} onPress={() => {}}>
            <View style={styles.calHeader}>
              <Pressable onPress={goToPrevMonth} hitSlop={12}>
                <Ionicons name="chevron-back" size={22} color={Colors.text} />
              </Pressable>
              <Text style={styles.calTitle}>{MONTH_NAMES[calMonth]} {calYear}</Text>
              <Pressable onPress={goToNextMonth} hitSlop={12}>
                <Ionicons name="chevron-forward" size={22} color={Colors.text} />
              </Pressable>
            </View>
            <View style={styles.calDayHeaders}>
              {DAY_HEADERS.map(dh => (
                <Text key={dh} style={styles.calDayHeader}>{dh}</Text>
              ))}
            </View>
            <View style={styles.calGrid}>
              {calendarDays.map((day, i) => {
                if (day === null) return <View key={`empty-${i}`} style={styles.calDayCell} />;
                const dateStr = `${calYear}-${String(calMonth + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
                const isSelected = dateStr === startDate;
                const isToday = dateStr === todayStr;
                const isPast = dateStr < todayStr;
                return (
                  <Pressable
                    key={`day-${day}`}
                    style={[styles.calDayCell, isSelected && styles.calDayCellSelected, isToday && !isSelected && styles.calDayCellToday]}
                    onPress={() => !isPast && handleSelectDate(day)}
                    disabled={isPast}
                  >
                    <Text style={[styles.calDayText, isSelected && styles.calDayTextSelected, isPast && styles.calDayTextPast, isToday && !isSelected && styles.calDayTextToday]}>
                      {day}
                    </Text>
                  </Pressable>
                );
              })}
            </View>
          </Pressable>
        </Pressable>
      </Modal>
    </>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  content: { padding: 20, gap: 20 },
  headerArea: { gap: 6 },
  title: { fontSize: 24, fontFamily: 'Inter_700Bold', color: Colors.text },
  postCountRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  postCountText: { fontSize: 13, fontFamily: 'Inter_500Medium', color: Colors.success },
  form: { gap: 18 },
  inputGroup: { gap: 6 },
  label: { fontSize: 13, fontFamily: 'Inter_600SemiBold', color: Colors.text, marginLeft: 4 },
  inputWrap: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    backgroundColor: Colors.surface,
    borderWidth: 1,
    borderColor: Colors.inputBorder,
    borderRadius: 12,
    paddingHorizontal: 14,
    height: 50,
  },
  input: { flex: 1, fontSize: 15, fontFamily: 'Inter_400Regular', color: Colors.text },
  selectBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    backgroundColor: Colors.surface,
    borderWidth: 1,
    borderColor: Colors.inputBorder,
    borderRadius: 12,
    paddingHorizontal: 14,
    height: 50,
  },
  selectText: { flex: 1, fontSize: 15, fontFamily: 'Inter_400Regular', color: Colors.text },
  dropdownList: {
    backgroundColor: Colors.surface,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: Colors.inputBorder,
    maxHeight: 200,
  },
  dropdownItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 12,
    paddingHorizontal: 14,
    borderBottomWidth: 0.5,
    borderBottomColor: Colors.divider,
  },
  dropdownItemActive: { backgroundColor: 'rgba(27,58,92,0.05)' },
  dropdownText: { fontSize: 14, fontFamily: 'Inter_400Regular', color: Colors.text },
  dropdownTextActive: { fontFamily: 'Inter_600SemiBold', color: Colors.primary },
  timeRow: { flexDirection: 'row', gap: 12 },
  certRow: { flexDirection: 'row', gap: 10 },
  certChip: {
    flex: 1,
    paddingVertical: 12,
    borderRadius: 10,
    backgroundColor: Colors.surface,
    borderWidth: 1,
    borderColor: Colors.inputBorder,
    alignItems: 'center',
  },
  certChipActive: { backgroundColor: Colors.primary, borderColor: Colors.primary },
  certChipText: { fontSize: 14, fontFamily: 'Inter_500Medium', color: Colors.text },
  certChipTextActive: { color: Colors.white },
  postBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: Colors.primary,
    borderRadius: 14,
    height: 52,
    marginTop: 8,
  },
  postBtnText: { fontSize: 16, fontFamily: 'Inter_600SemiBold', color: Colors.white },
  modalOverlay: {
    flex: 1,
    backgroundColor: Colors.overlay,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  calendarCard: {
    width: '100%',
    maxWidth: 360,
    backgroundColor: Colors.surface,
    borderRadius: 20,
    padding: 20,
  },
  calHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  calTitle: { fontSize: 17, fontFamily: 'Inter_600SemiBold', color: Colors.text },
  calDayHeaders: {
    flexDirection: 'row',
    marginBottom: 8,
  },
  calDayHeader: {
    flex: 1,
    textAlign: 'center',
    fontSize: 12,
    fontFamily: 'Inter_600SemiBold',
    color: Colors.textTertiary,
  },
  calGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  calDayCell: {
    width: '14.28%',
    aspectRatio: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  calDayCellSelected: {
    backgroundColor: Colors.primary,
    borderRadius: 20,
  },
  calDayCellToday: {
    borderWidth: 1.5,
    borderColor: Colors.primary,
    borderRadius: 20,
  },
  calDayText: {
    fontSize: 14,
    fontFamily: 'Inter_500Medium',
    color: Colors.text,
  },
  calDayTextSelected: { color: Colors.white, fontFamily: 'Inter_700Bold' },
  calDayTextPast: { color: Colors.textTertiary, opacity: 0.5 },
  calDayTextToday: { color: Colors.primary, fontFamily: 'Inter_700Bold' },
});
