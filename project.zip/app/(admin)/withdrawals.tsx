import React, { useState, useCallback } from 'react';
import { View, Text, FlatList, Pressable, StyleSheet, Alert, Platform, ActivityIndicator, RefreshControl } from 'react-native';
import { useFocusEffect } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import Colors from '@/constants/colors';
import { Withdrawal, adminGetWithdrawals, adminCompleteWithdrawal, adminRejectWithdrawal } from '@/lib/storage';

type EnrichedWithdrawal = Withdrawal & { userName: string; userRole: string; userEmail: string };
type FilterTab = 'pending' | 'completed' | 'rejected' | 'all';

export default function AdminWithdrawalsScreen() {
  const insets = useSafeAreaInsets();
  const webTopInset = Platform.OS === 'web' ? 67 : 0;

  const [withdrawals, setWithdrawals] = useState<EnrichedWithdrawal[]>([]);
  const [filterTab, setFilterTab] = useState<FilterTab>('pending');
  const [refreshing, setRefreshing] = useState(false);
  const [processing, setProcessing] = useState<string | null>(null);

  const loadWithdrawals = useCallback(async () => {
    try {
      const all = await adminGetWithdrawals() as EnrichedWithdrawal[];
      setWithdrawals(all.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()));
    } catch {}
  }, []);

  useFocusEffect(useCallback(() => { loadWithdrawals(); }, [loadWithdrawals]));

  const onRefresh = async () => {
    setRefreshing(true);
    await loadWithdrawals();
    setRefreshing(false);
  };

  const filtered = withdrawals.filter(w => filterTab === 'all' || w.status === filterTab);

  const pendingCount = withdrawals.filter(w => w.status === 'pending').length;
  const totalPending = withdrawals.filter(w => w.status === 'pending').reduce((s, w) => s + w.amount, 0);

  const handleComplete = async (id: string, amount: number, name: string) => {
    Alert.alert(
      'Approve Withdrawal',
      `Complete $${amount.toFixed(2)} payout to ${name}?`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Approve', style: 'default',
          onPress: async () => {
            setProcessing(id);
            try {
              await adminCompleteWithdrawal(id);
              Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
              await loadWithdrawals();
            } catch (err: any) {
              Alert.alert('Error', err.message || 'Failed to complete withdrawal.');
            } finally {
              setProcessing(null);
            }
          }
        }
      ]
    );
  };

  const handleReject = async (id: string, amount: number, name: string) => {
    Alert.alert(
      'Reject Withdrawal',
      `Reject $${amount.toFixed(2)} request from ${name}? Their balance will be restored.`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Reject', style: 'destructive',
          onPress: async () => {
            setProcessing(id);
            try {
              await adminRejectWithdrawal(id);
              Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
              await loadWithdrawals();
            } catch (err: any) {
              Alert.alert('Error', err.message || 'Failed to reject withdrawal.');
            } finally {
              setProcessing(null);
            }
          }
        }
      ]
    );
  };

  const formatDate = (iso: string) => {
    const d = new Date(iso);
    return d.toLocaleDateString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
  };

  const getStatusStyle = (status: string) => {
    switch (status) {
      case 'pending': return { color: '#F59E0B', bg: 'rgba(245,158,11,0.1)', icon: 'time' as const };
      case 'completed': return { color: Colors.success, bg: 'rgba(46,204,113,0.1)', icon: 'checkmark-circle' as const };
      case 'rejected': return { color: Colors.accent, bg: 'rgba(231,76,60,0.1)', icon: 'close-circle' as const };
      default: return { color: Colors.textSecondary, bg: Colors.inputBg, icon: 'ellipse' as const };
    }
  };

  const filterTabs: { key: FilterTab; label: string; count?: number }[] = [
    { key: 'pending', label: 'Pending', count: pendingCount },
    { key: 'completed', label: 'Completed' },
    { key: 'rejected', label: 'Rejected' },
    { key: 'all', label: 'All' },
  ];

  const renderItem = ({ item }: { item: EnrichedWithdrawal }) => {
    const st = getStatusStyle(item.status);
    const isProcessing = processing === item.id;

    return (
      <View style={styles.card}>
        <View style={styles.cardTop}>
          <View style={styles.cardLeft}>
            <View style={[styles.methodIcon, { backgroundColor: item.method === 'bank' ? 'rgba(27,58,92,0.1)' : 'rgba(0,214,50,0.1)' }]}>
              <Ionicons name={item.method === 'bank' ? 'card' : 'cash'} size={20} color={item.method === 'bank' ? Colors.primary : '#00D632'} />
            </View>
            <View>
              <Text style={styles.userName}>{item.userName}</Text>
              <Text style={styles.userMeta}>
                {item.userRole === 'ems' ? 'EMS' : 'Company'} · {item.method === 'bank' ? 'Bank Transfer' : 'Cash App'}
              </Text>
            </View>
          </View>
          <View style={styles.cardRight}>
            <Text style={styles.amount}>${item.amount.toFixed(2)}</Text>
            <View style={[styles.statusBadge, { backgroundColor: st.bg }]}>
              <Ionicons name={st.icon} size={11} color={st.color} />
              <Text style={[styles.statusText, { color: st.color }]}>{item.status}</Text>
            </View>
          </View>
        </View>

        <Text style={styles.dateText}>{formatDate(item.createdAt)}</Text>

        {item.status === 'pending' && (
          <View style={styles.actionRow}>
            {isProcessing ? (
              <ActivityIndicator color={Colors.primary} />
            ) : (
              <>
                <Pressable
                  style={({ pressed }) => [styles.approveBtn, pressed && { opacity: 0.8 }]}
                  onPress={() => handleComplete(item.id, item.amount, item.userName)}
                >
                  <Ionicons name="checkmark" size={16} color={Colors.white} />
                  <Text style={styles.actionBtnText}>Approve</Text>
                </Pressable>
                <Pressable
                  style={({ pressed }) => [styles.rejectBtn, pressed && { opacity: 0.8 }]}
                  onPress={() => handleReject(item.id, item.amount, item.userName)}
                >
                  <Ionicons name="close" size={16} color={Colors.accent} />
                  <Text style={[styles.actionBtnText, { color: Colors.accent }]}>Reject</Text>
                </Pressable>
              </>
            )}
          </View>
        )}
      </View>
    );
  };

  return (
    <View style={[styles.container, { paddingTop: insets.top + webTopInset }]}>
      <View style={styles.header}>
        <Text style={styles.title}>Payouts</Text>
        {pendingCount > 0 && (
          <View style={styles.pendingSummary}>
            <Text style={styles.pendingText}>{pendingCount} pending · ${totalPending.toFixed(2)}</Text>
          </View>
        )}
      </View>

      <View style={styles.filterRow}>
        {filterTabs.map(tab => (
          <Pressable
            key={tab.key}
            style={[styles.filterTab, filterTab === tab.key && styles.filterTabActive]}
            onPress={() => setFilterTab(tab.key)}
          >
            <Text style={[styles.filterTabText, filterTab === tab.key && styles.filterTabTextActive]}>
              {tab.label}
            </Text>
            {tab.count !== undefined && tab.count > 0 && (
              <View style={styles.filterBadge}>
                <Text style={styles.filterBadgeText}>{tab.count}</Text>
              </View>
            )}
          </Pressable>
        ))}
      </View>

      <FlatList
        data={filtered}
        keyExtractor={(item) => item.id}
        renderItem={renderItem}
        contentContainerStyle={[styles.list, { paddingBottom: insets.bottom + (Platform.OS === 'web' ? 34 : 0) + 90 }]}
        showsVerticalScrollIndicator={false}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={Colors.primary} />}
        ListEmptyComponent={
          <View style={styles.empty}>
            <Ionicons name="wallet-outline" size={48} color={Colors.textTertiary} />
            <Text style={styles.emptyText}>No {filterTab !== 'all' ? filterTab : ''} withdrawal requests</Text>
          </View>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  header: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingHorizontal: 20, paddingVertical: 16,
  },
  title: { fontSize: 28, fontFamily: 'Inter_700Bold', color: Colors.text },
  pendingSummary: {
    backgroundColor: 'rgba(245,158,11,0.1)', borderRadius: 12, paddingHorizontal: 12, paddingVertical: 6,
  },
  pendingText: { fontSize: 13, fontFamily: 'Inter_600SemiBold', color: '#F59E0B' },
  filterRow: {
    flexDirection: 'row', paddingHorizontal: 16, gap: 8, marginBottom: 12,
  },
  filterTab: {
    paddingVertical: 8, paddingHorizontal: 14, borderRadius: 20,
    backgroundColor: Colors.surface, borderWidth: 1, borderColor: Colors.cardBorder,
    flexDirection: 'row', alignItems: 'center', gap: 6,
  },
  filterTabActive: { backgroundColor: Colors.primary, borderColor: Colors.primary },
  filterTabText: { fontSize: 13, fontFamily: 'Inter_500Medium', color: Colors.textSecondary },
  filterTabTextActive: { color: Colors.white },
  filterBadge: {
    backgroundColor: Colors.accent, borderRadius: 10,
    minWidth: 20, height: 20, justifyContent: 'center', alignItems: 'center',
    paddingHorizontal: 5,
  },
  filterBadgeText: { fontSize: 11, fontFamily: 'Inter_700Bold', color: Colors.white },
  list: { paddingHorizontal: 16 },
  card: {
    backgroundColor: Colors.surface, borderRadius: 16, padding: 16, marginBottom: 12,
    borderWidth: 1, borderColor: Colors.cardBorder,
  },
  cardTop: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start',
  },
  cardLeft: { flexDirection: 'row', alignItems: 'center', gap: 12, flex: 1 },
  methodIcon: {
    width: 40, height: 40, borderRadius: 12, justifyContent: 'center', alignItems: 'center',
  },
  userName: { fontSize: 15, fontFamily: 'Inter_600SemiBold', color: Colors.text },
  userMeta: { fontSize: 12, fontFamily: 'Inter_400Regular', color: Colors.textSecondary, marginTop: 2 },
  cardRight: { alignItems: 'flex-end', gap: 6 },
  amount: { fontSize: 18, fontFamily: 'Inter_700Bold', color: Colors.text },
  statusBadge: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    paddingHorizontal: 8, paddingVertical: 3, borderRadius: 8,
  },
  statusText: { fontSize: 11, fontFamily: 'Inter_600SemiBold', textTransform: 'uppercase' as const },
  dateText: { fontSize: 12, fontFamily: 'Inter_400Regular', color: Colors.textTertiary, marginTop: 10, marginLeft: 52 },
  actionRow: {
    flexDirection: 'row', gap: 10, marginTop: 14, paddingTop: 14,
    borderTopWidth: 1, borderTopColor: Colors.divider,
  },
  approveBtn: {
    flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6,
    backgroundColor: Colors.success, borderRadius: 12, paddingVertical: 12,
  },
  rejectBtn: {
    flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6,
    backgroundColor: 'rgba(231,76,60,0.08)', borderRadius: 12, paddingVertical: 12,
    borderWidth: 1, borderColor: 'rgba(231,76,60,0.3)',
  },
  actionBtnText: { fontSize: 14, fontFamily: 'Inter_600SemiBold', color: Colors.white },
  empty: { alignItems: 'center', justifyContent: 'center', paddingTop: 60, gap: 12 },
  emptyText: { fontSize: 15, fontFamily: 'Inter_500Medium', color: Colors.textTertiary },
});
