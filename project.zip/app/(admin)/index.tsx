import React, { useState, useCallback } from 'react';
import { View, Text, ScrollView, StyleSheet, Platform, Pressable } from 'react-native';
import { useFocusEffect } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import Colors from '@/constants/colors';
import { useAuth } from '@/lib/auth-context';
import { AdminUser, getAllUsers, getAllCalls, getAllSupportTickets, getAllShifts, getAllApplications } from '@/lib/storage';

interface Stats {
  totalEMS: number;
  totalCompanies: number;
  totalCalls: number;
  openCalls: number;
  completedShifts: number;
  activeShifts: number;
  openTickets: number;
  totalApplications: number;
  verifiedEMS: number;
  verifiedCompanies: number;
  suspendedUsers: number;
}

export default function AdminDashboard() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const webTopInset = Platform.OS === 'web' ? 67 : 0;
  const admin = user as AdminUser;

  const [stats, setStats] = useState<Stats>({
    totalEMS: 0, totalCompanies: 0, totalCalls: 0, openCalls: 0,
    completedShifts: 0, activeShifts: 0, openTickets: 0, totalApplications: 0,
    verifiedEMS: 0, verifiedCompanies: 0, suspendedUsers: 0,
  });
  const [refreshing, setRefreshing] = useState(false);

  const loadStats = useCallback(async () => {
    setRefreshing(true);
    const [users, calls, tickets, shifts, applications] = await Promise.all([
      getAllUsers(), getAllCalls(), getAllSupportTickets(), getAllShifts(), getAllApplications(),
    ]);

    const emsUsers = users.filter(u => u.role === 'ems');
    const companyUsers = users.filter(u => u.role === 'company');

    setStats({
      totalEMS: emsUsers.length,
      totalCompanies: companyUsers.length,
      totalCalls: calls.length,
      openCalls: calls.filter(c => c.status === 'open').length,
      completedShifts: shifts.filter(s => s.status === 'completed').length,
      activeShifts: shifts.filter(s => s.status === 'active').length,
      openTickets: tickets.filter(t => t.status === 'open').length,
      totalApplications: applications.length,
      verifiedEMS: emsUsers.filter(u => u.isVerified).length,
      verifiedCompanies: companyUsers.filter(u => u.isVerified).length,
      suspendedUsers: users.filter(u => u.isSuspended).length,
    });
    setRefreshing(false);
  }, []);

  useFocusEffect(useCallback(() => { loadStats(); }, [loadStats]));

  if (!admin) return null;

  const statCards: { label: string; value: number; icon: any; color: string; bg: string }[] = [
    { label: 'EMS Workers', value: stats.totalEMS, icon: 'medkit', color: Colors.accent, bg: 'rgba(230,57,70,0.08)' },
    { label: 'Companies', value: stats.totalCompanies, icon: 'business', color: Colors.primary, bg: 'rgba(27,58,92,0.08)' },
    { label: 'Total Calls', value: stats.totalCalls, icon: 'document-text', color: Colors.secondary, bg: 'rgba(69,123,157,0.08)' },
    { label: 'Open Calls', value: stats.openCalls, icon: 'radio', color: Colors.success, bg: 'rgba(46,204,113,0.08)' },
    { label: 'Active Shifts', value: stats.activeShifts, icon: 'time', color: Colors.warning, bg: 'rgba(243,156,18,0.08)' },
    { label: 'Completed Shifts', value: stats.completedShifts, icon: 'checkmark-circle', color: Colors.success, bg: 'rgba(46,204,113,0.08)' },
    { label: 'Applications', value: stats.totalApplications, icon: 'paper-plane', color: Colors.primaryLight, bg: 'rgba(42,85,128,0.08)' },
    { label: 'Open Tickets', value: stats.openTickets, icon: 'chatbubble-ellipses', color: Colors.accent, bg: 'rgba(230,57,70,0.08)' },
  ];

  return (
    <View style={styles.container}>
      <View style={[styles.header, { paddingTop: insets.top + webTopInset + 12 }]}>
        <View>
          <Text style={styles.greeting}>Admin Panel</Text>
          <Text style={styles.adminName}>{admin.fullName}</Text>
        </View>
        <Pressable style={styles.refreshBtn} onPress={loadStats}>
          <Ionicons name="refresh" size={20} color={Colors.white} />
        </Pressable>
      </View>

      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={[styles.content, { paddingBottom: insets.bottom + (Platform.OS === 'web' ? 118 : 100) }]}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.grid}>
          {statCards.map((card) => (
            <View key={card.label} style={styles.statCard}>
              <View style={[styles.statIconWrap, { backgroundColor: card.bg }]}>
                <Ionicons name={card.icon} size={20} color={card.color} />
              </View>
              <Text style={styles.statValue}>{card.value}</Text>
              <Text style={styles.statLabel}>{card.label}</Text>
            </View>
          ))}
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Verification Status</Text>
          <View style={styles.verifyRow}>
            <View style={styles.verifyCard}>
              <View style={styles.verifyHeader}>
                <Ionicons name="shield-checkmark" size={18} color={Colors.success} />
                <Text style={styles.verifyLabel}>Verified EMS</Text>
              </View>
              <Text style={styles.verifyValue}>{stats.verifiedEMS} / {stats.totalEMS}</Text>
              <View style={styles.progressBar}>
                <View style={[styles.progressFill, { width: `${stats.totalEMS > 0 ? (stats.verifiedEMS / stats.totalEMS) * 100 : 0}%`, backgroundColor: Colors.success }]} />
              </View>
            </View>
            <View style={styles.verifyCard}>
              <View style={styles.verifyHeader}>
                <Ionicons name="shield-checkmark" size={18} color={Colors.primary} />
                <Text style={styles.verifyLabel}>Verified Co.</Text>
              </View>
              <Text style={styles.verifyValue}>{stats.verifiedCompanies} / {stats.totalCompanies}</Text>
              <View style={styles.progressBar}>
                <View style={[styles.progressFill, { width: `${stats.totalCompanies > 0 ? (stats.verifiedCompanies / stats.totalCompanies) * 100 : 0}%`, backgroundColor: Colors.primary }]} />
              </View>
            </View>
          </View>
          {stats.suspendedUsers > 0 && (
            <View style={styles.alertCard}>
              <Ionicons name="warning" size={18} color={Colors.accent} />
              <Text style={styles.alertText}>{stats.suspendedUsers} suspended user{stats.suspendedUsers !== 1 ? 's' : ''}</Text>
            </View>
          )}
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  header: {
    backgroundColor: Colors.primary,
    paddingHorizontal: 20,
    paddingBottom: 20,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-end',
  },
  greeting: { fontSize: 13, fontFamily: 'Inter_500Medium', color: 'rgba(255,255,255,0.6)', textTransform: 'uppercase', letterSpacing: 1 },
  adminName: { fontSize: 24, fontFamily: 'Inter_700Bold', color: Colors.white, marginTop: 4 },
  refreshBtn: {
    width: 40, height: 40, borderRadius: 12,
    backgroundColor: 'rgba(255,255,255,0.15)',
    alignItems: 'center', justifyContent: 'center',
  },
  content: { padding: 16, gap: 20 },
  grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 12 },
  statCard: {
    width: '47%' as any,
    backgroundColor: Colors.surface,
    borderRadius: 16,
    padding: 16,
    gap: 6,
    borderWidth: 1,
    borderColor: Colors.cardBorder,
  },
  statIconWrap: {
    width: 40, height: 40, borderRadius: 12,
    alignItems: 'center', justifyContent: 'center',
    marginBottom: 4,
  },
  statValue: { fontSize: 28, fontFamily: 'Inter_700Bold', color: Colors.text },
  statLabel: { fontSize: 12, fontFamily: 'Inter_500Medium', color: Colors.textSecondary },
  section: { gap: 12 },
  sectionTitle: { fontSize: 16, fontFamily: 'Inter_600SemiBold', color: Colors.text, marginLeft: 4 },
  verifyRow: { flexDirection: 'row', gap: 12 },
  verifyCard: {
    flex: 1, backgroundColor: Colors.surface, borderRadius: 14, padding: 14, gap: 8,
    borderWidth: 1, borderColor: Colors.cardBorder,
  },
  verifyHeader: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  verifyLabel: { fontSize: 13, fontFamily: 'Inter_500Medium', color: Colors.textSecondary },
  verifyValue: { fontSize: 18, fontFamily: 'Inter_700Bold', color: Colors.text },
  progressBar: { height: 6, borderRadius: 3, backgroundColor: Colors.inputBg, overflow: 'hidden' as const },
  progressFill: { height: '100%' as any, borderRadius: 3 },
  alertCard: {
    flexDirection: 'row', alignItems: 'center', gap: 10,
    backgroundColor: 'rgba(230,57,70,0.06)', borderRadius: 12,
    padding: 14, borderWidth: 1, borderColor: 'rgba(230,57,70,0.15)',
  },
  alertText: { fontSize: 14, fontFamily: 'Inter_500Medium', color: Colors.accent },
});
