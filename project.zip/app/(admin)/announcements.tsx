import React, { useState, useCallback } from 'react';
import { View, Text, FlatList, Pressable, StyleSheet, Alert, Platform, TextInput, Modal, Image, ScrollView, ActivityIndicator } from 'react-native';
import { useFocusEffect } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import * as ImagePicker from 'expo-image-picker';
import * as FileSystem from 'expo-file-system';
import Colors from '@/constants/colors';
import {
  Announcement, adminGetAnnouncements, adminCreateAnnouncement, adminDeleteAnnouncement,
  REGIONS, RegionOption, AdUnlockRequest, adminGetAdUnlockRequests, adminApproveAdUnlock, adminRejectAdUnlock,
} from '@/lib/storage';

type TabView = 'announcements' | 'adRequests';

export default function AdminAnnouncementsScreen() {
  const insets = useSafeAreaInsets();
  const webTopInset = Platform.OS === 'web' ? 67 : 0;

  const [tab, setTab] = useState<TabView>('announcements');
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [adRequests, setAdRequests] = useState<AdUnlockRequest[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [title, setTitle] = useState('');
  const [message, setMessage] = useState('');
  const [announcementImage, setAnnouncementImage] = useState<string | undefined>();
  const [selectedRegion, setSelectedRegion] = useState<RegionOption | null>(null);
  const [showRegions, setShowRegions] = useState(false);
  const [isGlobal, setIsGlobal] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [imagePreview, setImagePreview] = useState<string | null>(null);

  const loadData = useCallback(async () => {
    const [anns, reqs] = await Promise.all([
      adminGetAnnouncements(),
      adminGetAdUnlockRequests(),
    ]);
    setAnnouncements(anns);
    setAdRequests(reqs);
  }, []);

  useFocusEffect(useCallback(() => { loadData(); }, [loadData]));

  const convertToBase64 = async (uri: string): Promise<string> => {
    if (Platform.OS === 'web') {
      const response = await fetch(uri);
      const blob = await response.blob();
      return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onloadend = () => resolve(reader.result as string);
        reader.onerror = reject;
        reader.readAsDataURL(blob);
      });
    }
    const base64 = await FileSystem.readAsStringAsync(uri, { encoding: FileSystem.EncodingType.Base64 });
    return `data:image/jpeg;base64,${base64}`;
  };

  const pickImage = async () => {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ['images'],
      quality: 0.5,
    });
    if (!result.canceled && result.assets[0]) {
      setAnnouncementImage(result.assets[0].uri);
    }
  };

  const handleCreate = async () => {
    if (!title.trim() || !message.trim()) {
      Alert.alert('Missing Fields', 'Title and message are required.');
      return;
    }
    if (!isGlobal && !selectedRegion) {
      Alert.alert('Missing Region', 'Please select a region or make the announcement global.');
      return;
    }
    setSubmitting(true);
    try {
      let imageBase64: string | undefined;
      if (announcementImage) {
        imageBase64 = await convertToBase64(announcementImage);
      }
      await adminCreateAnnouncement({
        title: title.trim(),
        message: message.trim(),
        image: imageBase64,
        ...(isGlobal ? {} : { city: selectedRegion!.city, state: selectedRegion!.state }),
      });
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      setTitle('');
      setMessage('');
      setAnnouncementImage(undefined);
      setSelectedRegion(null);
      setIsGlobal(true);
      setShowForm(false);
      loadData();
    } catch (err: any) {
      Alert.alert('Error', err.message);
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = (id: string) => {
    const doDelete = async () => {
      await adminDeleteAnnouncement(id);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      loadData();
    };
    if (Platform.OS === 'web') {
      if (window.confirm('Delete this announcement?')) doDelete();
    } else {
      Alert.alert('Delete', 'Delete this announcement?', [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Delete', style: 'destructive', onPress: doDelete },
      ]);
    }
  };

  const handleApproveAdUnlock = (id: string, companyName: string) => {
    const doApprove = async () => {
      try {
        await adminApproveAdUnlock(id);
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        loadData();
      } catch (err: any) {
        Alert.alert('Error', err.message);
      }
    };
    if (Platform.OS === 'web') {
      if (window.confirm(`Approve ad unlock for ${companyName}? This confirms they paid the $69 fee.`)) doApprove();
    } else {
      Alert.alert('Approve Ad Unlock', `Confirm ${companyName} has paid the $69 fee to unlock ads?`, [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Approve', onPress: doApprove },
      ]);
    }
  };

  const handleRejectAdUnlock = (id: string, companyName: string) => {
    const doReject = async () => {
      try {
        await adminRejectAdUnlock(id);
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        loadData();
      } catch (err: any) {
        Alert.alert('Error', err.message);
      }
    };
    if (Platform.OS === 'web') {
      if (window.confirm(`Reject ad unlock request from ${companyName}?`)) doReject();
    } else {
      Alert.alert('Reject', `Reject ad unlock from ${companyName}?`, [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Reject', style: 'destructive', onPress: doReject },
      ]);
    }
  };

  const formatDate = (iso: string) => {
    const d = new Date(iso);
    return d.toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric', hour: '2-digit', minute: '2-digit' });
  };

  const pendingRequests = adRequests.filter(r => r.status === 'pending');

  const renderAnnouncement = ({ item }: { item: Announcement }) => (
    <View style={styles.card}>
      <View style={styles.cardTop}>
        <View style={styles.cardTitleRow}>
          <Ionicons name="megaphone" size={18} color={Colors.accent} />
          <Text style={styles.cardTitle} numberOfLines={2}>{item.title}</Text>
        </View>
        <Pressable onPress={() => handleDelete(item.id)} hitSlop={8}>
          <Ionicons name="trash-outline" size={18} color={Colors.textTertiary} />
        </Pressable>
      </View>
      <Text style={styles.cardMessage}>{item.message}</Text>
      {item.image && (
        <Pressable onPress={() => setImagePreview(item.image)}>
          <Image source={{ uri: item.image }} style={styles.cardImage} />
        </Pressable>
      )}
      <View style={styles.cardFooter}>
        <View style={[styles.scopeBadge, { backgroundColor: item.city ? 'rgba(69,123,157,0.1)' : 'rgba(46,204,113,0.1)' }]}>
          <Ionicons name={item.city ? 'location' : 'globe'} size={12} color={item.city ? Colors.secondary : Colors.success} />
          <Text style={[styles.scopeText, { color: item.city ? Colors.secondary : Colors.success }]}>
            {item.city ? `${item.city}, ${item.state}` : 'All Regions'}
          </Text>
        </View>
        <Text style={styles.cardDate}>{formatDate(item.createdAt)}</Text>
      </View>
    </View>
  );

  const renderAdRequest = ({ item }: { item: AdUnlockRequest }) => (
    <View style={styles.card}>
      <View style={styles.cardTop}>
        <View style={styles.cardTitleRow}>
          <Ionicons name="business" size={18} color={Colors.primary} />
          <Text style={styles.cardTitle}>{item.companyName}</Text>
        </View>
        <View style={[
          styles.statusBadge,
          item.status === 'approved' ? styles.statusApproved :
          item.status === 'rejected' ? styles.statusRejected : styles.statusPending,
        ]}>
          <Text style={[
            styles.statusText,
            item.status === 'approved' ? { color: Colors.success } :
            item.status === 'rejected' ? { color: Colors.accent } : { color: Colors.warning },
          ]}>
            {item.status.charAt(0).toUpperCase() + item.status.slice(1)}
          </Text>
        </View>
      </View>
      <View style={styles.feeRow}>
        <Ionicons name="cash" size={16} color={Colors.success} />
        <Text style={styles.feeText}>$69 Ad Unlock Fee</Text>
      </View>
      <Text style={styles.cardDate}>{formatDate(item.createdAt)}</Text>
      {item.status === 'pending' && (
        <View style={styles.actionRow}>
          <Pressable
            style={[styles.actionBtn, styles.actionBtnGreen]}
            onPress={() => handleApproveAdUnlock(item.id, item.companyName)}
          >
            <Ionicons name="checkmark-circle" size={16} color={Colors.white} />
            <Text style={[styles.actionBtnText, { color: Colors.white }]}>Approve</Text>
          </Pressable>
          <Pressable
            style={[styles.actionBtn, styles.actionBtnRed]}
            onPress={() => handleRejectAdUnlock(item.id, item.companyName)}
          >
            <Ionicons name="close-circle" size={16} color={Colors.white} />
            <Text style={[styles.actionBtnText, { color: Colors.white }]}>Reject</Text>
          </Pressable>
        </View>
      )}
    </View>
  );

  return (
    <View style={styles.container}>
      <View style={[styles.header, { paddingTop: insets.top + webTopInset + 12 }]}>
        <View>
          <Text style={styles.headerTitle}>Content Management</Text>
          <Text style={styles.headerCount}>
            {tab === 'announcements' ? `${announcements.length} announcement${announcements.length !== 1 ? 's' : ''}` : `${pendingRequests.length} pending request${pendingRequests.length !== 1 ? 's' : ''}`}
          </Text>
        </View>
        {tab === 'announcements' && (
          <Pressable style={styles.addBtn} onPress={() => setShowForm(true)}>
            <Ionicons name="add" size={22} color={Colors.white} />
          </Pressable>
        )}
      </View>

      <View style={styles.tabRow}>
        <Pressable
          style={[styles.tabBtn, tab === 'announcements' && styles.tabBtnActive]}
          onPress={() => setTab('announcements')}
        >
          <Ionicons name="megaphone" size={16} color={tab === 'announcements' ? Colors.white : Colors.textSecondary} />
          <Text style={[styles.tabText, tab === 'announcements' && styles.tabTextActive]}>Announcements</Text>
        </Pressable>
        <Pressable
          style={[styles.tabBtn, tab === 'adRequests' && styles.tabBtnActive]}
          onPress={() => setTab('adRequests')}
        >
          <Ionicons name="star" size={16} color={tab === 'adRequests' ? Colors.white : Colors.textSecondary} />
          <Text style={[styles.tabText, tab === 'adRequests' && styles.tabTextActive]}>Ad Requests</Text>
          {pendingRequests.length > 0 && (
            <View style={styles.badge}>
              <Text style={styles.badgeText}>{pendingRequests.length}</Text>
            </View>
          )}
        </Pressable>
      </View>

      {tab === 'announcements' ? (
        <FlatList
          data={announcements}
          renderItem={renderAnnouncement}
          keyExtractor={item => item.id}
          contentContainerStyle={[styles.listContent, announcements.length === 0 && { flex: 1 }]}
          showsVerticalScrollIndicator={false}
          ListEmptyComponent={
            <View style={styles.emptyState}>
              <Ionicons name="megaphone-outline" size={48} color={Colors.textTertiary} />
              <Text style={styles.emptyTitle}>No Announcements</Text>
              <Text style={styles.emptyText}>Tap + to create an announcement for EMS workers and companies.</Text>
            </View>
          }
        />
      ) : (
        <FlatList
          data={adRequests}
          renderItem={renderAdRequest}
          keyExtractor={item => item.id}
          contentContainerStyle={[styles.listContent, adRequests.length === 0 && { flex: 1 }]}
          showsVerticalScrollIndicator={false}
          ListEmptyComponent={
            <View style={styles.emptyState}>
              <Ionicons name="star-outline" size={48} color={Colors.textTertiary} />
              <Text style={styles.emptyTitle}>No Ad Requests</Text>
              <Text style={styles.emptyText}>Companies who want to post premium ads ($69) will appear here for approval.</Text>
            </View>
          }
        />
      )}

      <Modal visible={showForm} animationType="slide" transparent>
        <View style={styles.modalOverlay}>
          <View style={[styles.modalContent, { paddingBottom: insets.bottom + 20 }]}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>New Announcement</Text>
              <Pressable onPress={() => { setShowForm(false); setAnnouncementImage(undefined); }} hitSlop={8}>
                <Ionicons name="close" size={24} color={Colors.text} />
              </Pressable>
            </View>

            <ScrollView showsVerticalScrollIndicator={false}>
              <View style={styles.formGroup}>
                <Text style={styles.formLabel}>Title</Text>
                <TextInput
                  style={styles.formInput}
                  placeholder="Announcement title"
                  placeholderTextColor={Colors.textTertiary}
                  value={title}
                  onChangeText={setTitle}
                />
              </View>

              <View style={styles.formGroup}>
                <Text style={styles.formLabel}>Message</Text>
                <TextInput
                  style={[styles.formInput, { minHeight: 100, textAlignVertical: 'top' }]}
                  placeholder="Write your announcement..."
                  placeholderTextColor={Colors.textTertiary}
                  value={message}
                  onChangeText={setMessage}
                  multiline
                />
              </View>

              <View style={styles.formGroup}>
                <Text style={styles.formLabel}>Photo (Optional)</Text>
                <Pressable style={styles.uploadBtn} onPress={pickImage}>
                  {announcementImage ? (
                    <View>
                      <Image source={{ uri: announcementImage }} style={styles.uploadPreview} />
                      <Pressable style={styles.removeImageBtn} onPress={() => setAnnouncementImage(undefined)}>
                        <Ionicons name="close-circle" size={24} color={Colors.accent} />
                      </Pressable>
                    </View>
                  ) : (
                    <View style={styles.uploadPlaceholder}>
                      <Ionicons name="image-outline" size={28} color={Colors.textTertiary} />
                      <Text style={styles.uploadText}>Add a photo</Text>
                    </View>
                  )}
                </Pressable>
              </View>

              <View style={styles.formGroup}>
                <Text style={styles.formLabel}>Audience</Text>
                <View style={styles.toggleRow}>
                  <Pressable
                    style={[styles.toggleBtn, isGlobal && styles.toggleBtnActive]}
                    onPress={() => { setIsGlobal(true); setSelectedRegion(null); }}
                  >
                    <Ionicons name="globe" size={16} color={isGlobal ? Colors.white : Colors.textSecondary} />
                    <Text style={[styles.toggleText, isGlobal && styles.toggleTextActive]}>All Regions</Text>
                  </Pressable>
                  <Pressable
                    style={[styles.toggleBtn, !isGlobal && styles.toggleBtnActive]}
                    onPress={() => setIsGlobal(false)}
                  >
                    <Ionicons name="location" size={16} color={!isGlobal ? Colors.white : Colors.textSecondary} />
                    <Text style={[styles.toggleText, !isGlobal && styles.toggleTextActive]}>Specific Region</Text>
                  </Pressable>
                </View>
              </View>

              {!isGlobal && (
                <View style={styles.formGroup}>
                  <Pressable style={styles.selectBtn} onPress={() => setShowRegions(!showRegions)}>
                    <Ionicons name="location-outline" size={18} color={selectedRegion ? Colors.text : Colors.textTertiary} />
                    <Text style={[styles.selectText, !selectedRegion && { color: Colors.textTertiary }]}>
                      {selectedRegion ? selectedRegion.label : 'Select region'}
                    </Text>
                    <Ionicons name={showRegions ? 'chevron-up' : 'chevron-down'} size={16} color={Colors.textTertiary} />
                  </Pressable>
                  {showRegions && (
                    <View style={styles.regionList}>
                      {REGIONS.map(r => (
                        <Pressable
                          key={r.label}
                          style={[styles.regionItem, selectedRegion?.label === r.label && styles.regionItemActive]}
                          onPress={() => { setSelectedRegion(r); setShowRegions(false); }}
                        >
                          <Text style={[styles.regionText, selectedRegion?.label === r.label && { color: Colors.white }]}>{r.label}</Text>
                        </Pressable>
                      ))}
                    </View>
                  )}
                </View>
              )}

              <Pressable
                style={({ pressed }) => [styles.submitBtn, pressed && { opacity: 0.8 }, submitting && { opacity: 0.5 }]}
                onPress={handleCreate}
                disabled={submitting}
              >
                {submitting ? (
                  <ActivityIndicator color={Colors.white} />
                ) : (
                  <>
                    <Ionicons name="megaphone" size={18} color={Colors.white} />
                    <Text style={styles.submitText}>Publish Announcement</Text>
                  </>
                )}
              </Pressable>
            </ScrollView>
          </View>
        </View>
      </Modal>

      <Modal visible={!!imagePreview} animationType="fade" transparent>
        <Pressable style={styles.previewOverlay} onPress={() => setImagePreview(null)}>
          <Pressable onPress={() => setImagePreview(null)} style={styles.previewClose}>
            <Ionicons name="close-circle" size={36} color={Colors.white} />
          </Pressable>
          {imagePreview && (
            <Image source={{ uri: imagePreview }} style={styles.previewImage} resizeMode="contain" />
          )}
        </Pressable>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  header: {
    backgroundColor: Colors.primary,
    paddingHorizontal: 20,
    paddingBottom: 16,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-end',
  },
  headerTitle: { fontSize: 22, fontFamily: 'Inter_700Bold', color: Colors.white },
  headerCount: { fontSize: 13, fontFamily: 'Inter_500Medium', color: 'rgba(255,255,255,0.6)', marginTop: 2 },
  addBtn: {
    width: 36, height: 36, borderRadius: 18,
    backgroundColor: Colors.accent,
    alignItems: 'center', justifyContent: 'center',
  },
  tabRow: {
    flexDirection: 'row', gap: 8,
    paddingHorizontal: 16, paddingVertical: 10,
  },
  tabBtn: {
    flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6,
    paddingVertical: 10, borderRadius: 10,
    backgroundColor: Colors.surface, borderWidth: 1, borderColor: Colors.cardBorder,
  },
  tabBtnActive: { backgroundColor: Colors.primary, borderColor: Colors.primary },
  tabText: { fontSize: 13, fontFamily: 'Inter_600SemiBold', color: Colors.textSecondary },
  tabTextActive: { color: Colors.white },
  badge: {
    backgroundColor: Colors.accent, borderRadius: 10,
    minWidth: 20, height: 20, alignItems: 'center', justifyContent: 'center',
    paddingHorizontal: 6,
  },
  badgeText: { fontSize: 11, fontFamily: 'Inter_700Bold', color: Colors.white },
  listContent: { padding: 16, paddingBottom: 120, gap: 12 },
  card: {
    backgroundColor: Colors.surface,
    borderRadius: 16,
    padding: 16,
    gap: 10,
    borderWidth: 1,
    borderColor: Colors.cardBorder,
  },
  cardTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' },
  cardTitleRow: { flexDirection: 'row', alignItems: 'center', gap: 8, flex: 1, marginRight: 8 },
  cardTitle: { fontSize: 16, fontFamily: 'Inter_600SemiBold', color: Colors.text, flex: 1 },
  cardMessage: { fontSize: 14, fontFamily: 'Inter_400Regular', color: Colors.textSecondary, lineHeight: 20 },
  cardImage: { width: '100%', height: 180, borderRadius: 12, backgroundColor: Colors.background },
  cardFooter: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 4 },
  scopeBadge: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    paddingHorizontal: 8, paddingVertical: 3, borderRadius: 6,
  },
  scopeText: { fontSize: 11, fontFamily: 'Inter_600SemiBold' },
  cardDate: { fontSize: 11, fontFamily: 'Inter_400Regular', color: Colors.textTertiary },
  statusBadge: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 8 },
  statusPending: { backgroundColor: 'rgba(243,156,18,0.1)' },
  statusApproved: { backgroundColor: 'rgba(46,204,113,0.1)' },
  statusRejected: { backgroundColor: 'rgba(230,57,70,0.1)' },
  statusText: { fontSize: 12, fontFamily: 'Inter_600SemiBold' },
  feeRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  feeText: { fontSize: 14, fontFamily: 'Inter_600SemiBold', color: Colors.success },
  actionRow: { flexDirection: 'row', gap: 8, marginTop: 4 },
  actionBtn: {
    flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
    gap: 6, paddingVertical: 10, borderRadius: 10,
  },
  actionBtnGreen: { backgroundColor: Colors.success },
  actionBtnRed: { backgroundColor: Colors.accent },
  actionBtnText: { fontSize: 13, fontFamily: 'Inter_600SemiBold' },
  emptyState: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 12 },
  emptyTitle: { fontSize: 18, fontFamily: 'Inter_600SemiBold', color: Colors.text },
  emptyText: { fontSize: 14, fontFamily: 'Inter_400Regular', color: Colors.textSecondary, textAlign: 'center', paddingHorizontal: 40 },
  modalOverlay: {
    flex: 1,
    backgroundColor: Colors.overlay,
    justifyContent: 'flex-end',
  },
  modalContent: {
    backgroundColor: Colors.surface,
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    padding: 20,
    maxHeight: '90%',
  },
  modalHeader: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    marginBottom: 20,
  },
  modalTitle: { fontSize: 20, fontFamily: 'Inter_700Bold', color: Colors.text },
  formGroup: { marginBottom: 16 },
  formLabel: { fontSize: 13, fontFamily: 'Inter_600SemiBold', color: Colors.textSecondary, marginBottom: 6 },
  formInput: {
    backgroundColor: Colors.inputBg,
    borderWidth: 1, borderColor: Colors.inputBorder,
    borderRadius: 12, padding: 14,
    fontSize: 15, fontFamily: 'Inter_400Regular', color: Colors.text,
  },
  uploadBtn: {
    borderRadius: 12, borderWidth: 1, borderColor: Colors.inputBorder,
    borderStyle: 'dashed', overflow: 'hidden', backgroundColor: Colors.inputBg,
  },
  uploadPlaceholder: { paddingVertical: 24, alignItems: 'center', gap: 6 },
  uploadText: { fontSize: 13, fontFamily: 'Inter_400Regular', color: Colors.textTertiary },
  uploadPreview: { width: '100%', height: 160, resizeMode: 'cover' },
  removeImageBtn: { position: 'absolute', top: 8, right: 8 },
  toggleRow: { flexDirection: 'row', gap: 8 },
  toggleBtn: {
    flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6,
    paddingVertical: 10, borderRadius: 10,
    backgroundColor: Colors.inputBg, borderWidth: 1, borderColor: Colors.inputBorder,
  },
  toggleBtnActive: { backgroundColor: Colors.primary, borderColor: Colors.primary },
  toggleText: { fontSize: 13, fontFamily: 'Inter_500Medium', color: Colors.textSecondary },
  toggleTextActive: { color: Colors.white },
  selectBtn: {
    flexDirection: 'row', alignItems: 'center', gap: 8,
    backgroundColor: Colors.inputBg, borderWidth: 1, borderColor: Colors.inputBorder,
    borderRadius: 12, padding: 14,
  },
  selectText: { flex: 1, fontSize: 15, fontFamily: 'Inter_400Regular', color: Colors.text },
  regionList: {
    marginTop: 8, backgroundColor: Colors.surface,
    borderWidth: 1, borderColor: Colors.cardBorder,
    borderRadius: 12, overflow: 'hidden',
    maxHeight: 200,
  },
  regionItem: {
    paddingHorizontal: 16, paddingVertical: 12,
    borderBottomWidth: 1, borderBottomColor: Colors.divider,
  },
  regionItemActive: { backgroundColor: Colors.primary },
  regionText: { fontSize: 14, fontFamily: 'Inter_500Medium', color: Colors.text },
  submitBtn: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8,
    backgroundColor: Colors.accent, borderRadius: 12, paddingVertical: 14,
    marginTop: 8,
  },
  submitText: { fontSize: 15, fontFamily: 'Inter_600SemiBold', color: Colors.white },
  previewOverlay: {
    flex: 1, backgroundColor: 'rgba(0,0,0,0.9)',
    justifyContent: 'center', alignItems: 'center',
  },
  previewClose: { position: 'absolute', top: 50, right: 20, zIndex: 10 },
  previewImage: { width: '90%', height: '80%' },
});
