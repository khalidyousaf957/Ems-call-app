import { apiGet, apiPost, apiPut, apiPatch, apiDelete } from './api';

export type UserRole = 'ems' | 'company' | 'admin';
export type CertType = 'EMT' | 'Paramedic';
export type CallStatus = 'open' | 'pending' | 'accepted' | 'in_progress' | 'completed';
export type NegotiationStatus = 'pending' | 'negotiating' | 'accepted' | 'rejected';

export interface EMSUser {
  id: string;
  role: 'ems';
  email: string;
  fullName: string;
  certType: CertType;
  certificationImage?: string;
  licenseImage?: string;
  city: string;
  state: string;
  balance: number;
  isVerified: boolean;
  isSuspended: boolean;
  createdAt: string;
}

export interface CompanyUser {
  id: string;
  role: 'company';
  email: string;
  companyName: string;
  ownerName: string;
  phone: string;
  licenseNumber: string;
  city: string;
  state: string;
  balance: number;
  postsToday: number;
  lastPostDate: string;
  bankName?: string;
  bankAccountLast4?: string;
  subscriptionPaidThrough?: string;
  adsUnlocked: boolean;
  isVerified: boolean;
  isSuspended: boolean;
  createdAt: string;
}

export interface AdminUser {
  id: string;
  role: 'admin';
  email: string;
  fullName: string;
  isVerified: boolean;
  isSuspended: boolean;
  createdAt: string;
}

export type AppUser = EMSUser | CompanyUser | AdminUser;

export function getUserRegion(user: AppUser | null | undefined): string {
  if (!user) return 'Unknown';
  if (user.role === 'admin') return 'All Regions';
  return `${user.city}, ${user.state}`;
}

export interface Call {
  id: string;
  companyId: string;
  companyName: string;
  jobType: string;
  location: string;
  startTime: string;
  endTime: string;
  certRequired: CertType;
  numberNeeded: number;
  payRate: number;
  city: string;
  state: string;
  status: CallStatus;
  createdAt: string;
}

export interface Application {
  id: string;
  callId: string;
  emsId: string;
  emsName: string;
  emsCertType: CertType;
  status: NegotiationStatus;
  proposedPay: number;
  originalPay: number;
  messages: NegotiationMessage[];
  createdAt: string;
}

export interface NegotiationMessage {
  id: string;
  senderId: string;
  senderRole: UserRole;
  message: string;
  proposedPay?: number;
  createdAt: string;
}

export interface Shift {
  id: string;
  callId: string;
  applicationId: string;
  emsId: string;
  companyId: string;
  startedAt: string;
  endedAt?: string;
  confirmedAt?: string;
  payAmount: number;
  status: 'active' | 'ended_pending' | 'completed';
}

export interface SupportTicket {
  id: string;
  userId: string;
  userRole: 'ems' | 'company';
  userName: string;
  category: string;
  subject: string;
  description: string;
  status: 'open' | 'in_review' | 'resolved';
  adminNote?: string;
  createdAt: string;
}

export interface RegionOption {
  city: string;
  state: string;
  label: string;
}

export const REGIONS: RegionOption[] = [
  { city: 'Houston', state: 'TX', label: 'Houston, TX' },
  { city: 'Dallas', state: 'TX', label: 'Dallas, TX' },
  { city: 'Austin', state: 'TX', label: 'Austin, TX' },
  { city: 'San Antonio', state: 'TX', label: 'San Antonio, TX' },
  { city: 'Fort Worth', state: 'TX', label: 'Fort Worth, TX' },
  { city: 'El Paso', state: 'TX', label: 'El Paso, TX' },
  { city: 'Phoenix', state: 'AZ', label: 'Phoenix, AZ' },
  { city: 'Los Angeles', state: 'CA', label: 'Los Angeles, CA' },
  { city: 'San Diego', state: 'CA', label: 'San Diego, CA' },
  { city: 'Miami', state: 'FL', label: 'Miami, FL' },
  { city: 'Orlando', state: 'FL', label: 'Orlando, FL' },
  { city: 'Atlanta', state: 'GA', label: 'Atlanta, GA' },
  { city: 'Chicago', state: 'IL', label: 'Chicago, IL' },
  { city: 'New York', state: 'NY', label: 'New York, NY' },
  { city: 'Denver', state: 'CO', label: 'Denver, CO' },
];

export const JOB_TYPES = [
  'Dialysis Transport',
  'ER Standby',
  'Event Coverage',
  'Hospital Transfer',
  'Home Health Visit',
  'Skilled Nursing Transport',
  'Wheelchair Transport',
  'BLS Transport',
  'ALS Transport',
  'Critical Care Transport',
];

export async function updateUser(updated: Partial<AppUser>): Promise<AppUser> {
  return apiPut<AppUser>('/api/auth/me', updated);
}

export async function createCall(call: Omit<Call, 'id' | 'createdAt' | 'status'>): Promise<Call> {
  const result = await apiPost<{ call: Call; postsToday: number }>('/api/calls', call);
  return result.call;
}

export async function getCalls(city?: string, state?: string): Promise<Call[]> {
  const params = city && state ? `?city=${encodeURIComponent(city)}&state=${encodeURIComponent(state)}` : '';
  return apiGet<Call[]>(`/api/calls${params}`);
}

export async function getCall(id: string): Promise<Call | undefined> {
  try {
    return await apiGet<Call>(`/api/calls/${id}`);
  } catch {
    return undefined;
  }
}

export async function updateCall(updated: Call): Promise<void> {
  await apiPut(`/api/calls/${updated.id}`, updated);
}

export async function createApplication(app: Omit<Application, 'id' | 'createdAt' | 'messages'>): Promise<Application> {
  return apiPost<Application>('/api/applications', app);
}

export async function getApplicationsForCall(callId: string): Promise<Application[]> {
  return apiGet<Application[]>(`/api/applications/call/${callId}`);
}

export async function getApplicationsForEMS(emsId: string): Promise<Application[]> {
  return apiGet<Application[]>('/api/applications/ems');
}

export async function getApplication(id: string): Promise<Application | undefined> {
  try {
    return await apiGet<Application>(`/api/applications/${id}`);
  } catch {
    return undefined;
  }
}

export async function updateApplication(updated: Application): Promise<void> {
  await apiPut(`/api/applications/${updated.id}`, updated);
}

export async function addNegotiationMessage(applicationId: string, message: string, proposedPay?: number): Promise<NegotiationMessage> {
  return apiPost<NegotiationMessage>(`/api/applications/${applicationId}/messages`, { message, proposedPay });
}

export async function createShift(shift: Omit<Shift, 'id'>): Promise<Shift> {
  return apiPost<Shift>('/api/shifts', shift);
}

export async function getShiftsForEMS(emsId: string): Promise<Shift[]> {
  return apiGet<Shift[]>('/api/shifts/ems');
}

export async function getShiftsForCompany(companyId: string): Promise<Shift[]> {
  return apiGet<Shift[]>('/api/shifts/company');
}

export async function updateShift(updated: Shift): Promise<void> {
  await apiPut(`/api/shifts/${updated.id}`, updated);
}

export async function getCompanyPostCount(companyId: string): Promise<number> {
  const calls = await apiGet<Call[]>('/api/calls/company');
  const today = new Date().toDateString();
  return calls.filter(c => new Date(c.createdAt).toDateString() === today).length;
}

export async function resetPassword(email: string): Promise<boolean> {
  const result = await apiPost<{ success: boolean }>('/api/auth/reset-password', { email });
  return result.success;
}

export async function createSupportTicket(ticket: Omit<SupportTicket, 'id' | 'createdAt' | 'status'>): Promise<SupportTicket> {
  return apiPost<SupportTicket>('/api/support-tickets', ticket);
}

export async function getMySupportTickets(): Promise<SupportTicket[]> {
  return apiGet<SupportTicket[]>('/api/support-tickets/mine');
}

export async function getAllUsers(): Promise<AppUser[]> {
  return apiGet<AppUser[]>('/api/admin/users');
}

export async function adminUpdateUser(userId: string, updates: Partial<{ isVerified: boolean; isSuspended: boolean }>): Promise<AppUser | null> {
  return apiPut<AppUser>(`/api/admin/users/${userId}`, updates);
}

export interface UserDocuments {
  certificationImage: string | null;
  licenseImage: string | null;
  licenseNumber: string | null;
  certType: string | null;
  fullName: string | null;
  companyName: string | null;
}

export async function adminGetUserDocuments(userId: string): Promise<UserDocuments> {
  return apiGet<UserDocuments>(`/api/admin/users/${userId}/documents`);
}

export async function getAllCalls(): Promise<Call[]> {
  return apiGet<Call[]>('/api/admin/calls');
}

export async function adminDeleteCall(callId: string): Promise<void> {
  await apiDelete<{ message: string }>(`/api/admin/calls/${callId}`);
}

export async function getAllSupportTickets(): Promise<SupportTicket[]> {
  return apiGet<SupportTicket[]>('/api/admin/tickets');
}

export async function updateSupportTicket(ticketId: string, updates: Partial<SupportTicket>): Promise<SupportTicket | null> {
  return apiPut<SupportTicket>(`/api/admin/tickets/${ticketId}`, updates);
}

export async function getAllShifts(): Promise<Shift[]> {
  return apiGet<Shift[]>('/api/admin/shifts');
}

export async function getAllApplications(): Promise<Application[]> {
  return apiGet<Application[]>('/api/admin/applications');
}

export interface Announcement {
  id: string;
  title: string;
  message: string;
  image: string | null;
  city: string | null;
  state: string | null;
  createdAt: string;
}

export async function getAnnouncements(): Promise<Announcement[]> {
  return apiGet<Announcement[]>('/api/announcements');
}

export async function adminGetAnnouncements(): Promise<Announcement[]> {
  return apiGet<Announcement[]>('/api/admin/announcements');
}

export async function adminCreateAnnouncement(data: { title: string; message: string; image?: string; city?: string; state?: string }): Promise<Announcement> {
  return apiPost<Announcement>('/api/admin/announcements', data);
}

export async function adminDeleteAnnouncement(id: string): Promise<void> {
  await apiDelete<{ message: string }>(`/api/admin/announcements/${id}`);
}

export interface PremiumAd {
  id: string;
  companyId: string;
  companyName: string;
  title: string;
  description: string;
  hourlyRate: number;
  daysNeeded: number;
  whyBest: string;
  city: string;
  state: string;
  status: 'active' | 'expired';
  paidAmount: number;
  startDate: string;
  endDate: string;
  createdAt: string;
}

export async function getActivePremiumAds(): Promise<PremiumAd[]> {
  return apiGet<PremiumAd[]>('/api/premium-ads');
}

export async function getMyPremiumAds(): Promise<PremiumAd[]> {
  return apiGet<PremiumAd[]>('/api/premium-ads/mine');
}

export async function createPremiumAd(data: {
  title: string;
  description: string;
  hourlyRate: number;
  daysNeeded: number;
  whyBest: string;
}): Promise<PremiumAd> {
  return apiPost<PremiumAd>('/api/premium-ads', data);
}

export interface Withdrawal {
  id: string;
  userId: string;
  amount: number;
  method: 'bank' | 'cashapp';
  status: 'pending' | 'completed' | 'rejected';
  createdAt: string;
  updatedAt: string;
  userName?: string;
  userRole?: string;
  userEmail?: string;
}

export async function requestWithdrawal(data: { amount: number; method: 'bank' | 'cashapp' }): Promise<{ message: string; withdrawal: Withdrawal }> {
  return apiPost<{ message: string; withdrawal: Withdrawal }>('/api/withdrawals', data);
}

export async function getMyWithdrawals(): Promise<Withdrawal[]> {
  return apiGet<Withdrawal[]>('/api/withdrawals/mine');
}

export async function adminGetWithdrawals(): Promise<Withdrawal[]> {
  return apiGet<Withdrawal[]>('/api/admin/withdrawals');
}

export async function adminCompleteWithdrawal(id: string): Promise<{ message: string }> {
  return apiPatch<{ message: string }>(`/api/admin/withdrawals/${id}/complete`, {});
}

export async function adminRejectWithdrawal(id: string): Promise<{ message: string }> {
  return apiPatch<{ message: string }>(`/api/admin/withdrawals/${id}/reject`, {});
}

export interface AdUnlockRequest {
  id: string;
  companyId: string;
  companyName: string;
  status: 'pending' | 'approved' | 'rejected';
  createdAt: string;
  reviewedAt: string | null;
}

export async function requestAdUnlock(): Promise<AdUnlockRequest> {
  return apiPost<AdUnlockRequest>('/api/ad-unlock-request', {});
}

export async function getMyAdUnlockRequests(): Promise<AdUnlockRequest[]> {
  return apiGet<AdUnlockRequest[]>('/api/ad-unlock-request/mine');
}

export async function adminGetAdUnlockRequests(): Promise<AdUnlockRequest[]> {
  return apiGet<AdUnlockRequest[]>('/api/admin/ad-unlock-requests');
}

export async function adminApproveAdUnlock(id: string): Promise<{ message: string }> {
  return apiPost<{ message: string }>(`/api/admin/ad-unlock-requests/${id}/approve`, {});
}

export async function adminRejectAdUnlock(id: string): Promise<{ message: string }> {
  return apiPost<{ message: string }>(`/api/admin/ad-unlock-requests/${id}/reject`, {});
}
