import { eq, and, or, isNull, sql, desc } from "drizzle-orm";
import { db } from "./db";
import {
  users, calls, applications, negotiationMessages, shifts, supportTickets, announcements, premiumAds, withdrawals, adUnlockRequests,
  type User, type InsertUser, type Call, type Application,
  type NegotiationMessage, type Shift, type SupportTicket, type Announcement, type PremiumAd, type Withdrawal, type AdUnlockRequest,
} from "@shared/schema";

export async function getUserById(id: string): Promise<User | undefined> {
  const [user] = await db.select().from(users).where(eq(users.id, id));
  return user;
}

export async function getUserByEmail(email: string): Promise<User | undefined> {
  const [user] = await db.select().from(users).where(eq(users.email, email.toLowerCase()));
  return user;
}

export async function createUser(data: InsertUser): Promise<User> {
  const [user] = await db.insert(users).values({
    ...data,
    email: data.email.toLowerCase(),
  }).returning();
  return user;
}

export async function updateUser(id: string, data: Partial<User>): Promise<User | undefined> {
  const [user] = await db.update(users).set(data).where(eq(users.id, id)).returning();
  return user;
}

export async function getAllUsers(): Promise<User[]> {
  return db.select().from(users).orderBy(desc(users.createdAt));
}

export async function createCall(data: Omit<Call, "id" | "createdAt" | "status">): Promise<Call> {
  const [call] = await db.insert(calls).values({
    ...data,
    status: "open",
  }).returning();
  return call;
}

export async function getCallsByRegion(city: string, state: string): Promise<Call[]> {
  return db.select().from(calls)
    .where(and(eq(calls.city, city), eq(calls.state, state)))
    .orderBy(desc(calls.createdAt));
}

export async function getAllCalls(): Promise<Call[]> {
  return db.select().from(calls).orderBy(desc(calls.createdAt));
}

export async function getCallById(id: string): Promise<Call | undefined> {
  const [call] = await db.select().from(calls).where(eq(calls.id, id));
  return call;
}

export async function updateCall(id: string, data: Partial<Call>): Promise<Call | undefined> {
  const [call] = await db.update(calls).set(data).where(eq(calls.id, id)).returning();
  return call;
}

export async function getCompanyCallsToday(companyId: string): Promise<number> {
  const today = new Date().toISOString().split("T")[0];
  const result = await db.select({ count: sql<number>`count(*)` })
    .from(calls)
    .where(and(
      eq(calls.companyId, companyId),
      sql`DATE(${calls.createdAt}) = ${today}`
    ));
  return Number(result[0]?.count || 0);
}

export async function deleteCall(id: string): Promise<boolean> {
  const result = await db.delete(calls).where(eq(calls.id, id)).returning();
  return result.length > 0;
}

export async function getCallsByCompany(companyId: string): Promise<Call[]> {
  return db.select().from(calls)
    .where(eq(calls.companyId, companyId))
    .orderBy(desc(calls.createdAt));
}

export async function createApplication(data: Omit<Application, "id" | "createdAt" | "status">): Promise<Application> {
  const [app] = await db.insert(applications).values({
    ...data,
    status: "pending",
  }).returning();
  return app;
}

export async function getApplicationsByCall(callId: string): Promise<Application[]> {
  return db.select().from(applications).where(eq(applications.callId, callId));
}

export async function getApplicationsByEMS(emsId: string): Promise<Application[]> {
  return db.select().from(applications).where(eq(applications.emsId, emsId));
}

export async function getApplicationById(id: string): Promise<Application | undefined> {
  const [app] = await db.select().from(applications).where(eq(applications.id, id));
  return app;
}

export async function updateApplication(id: string, data: Partial<Application>): Promise<Application | undefined> {
  const [app] = await db.update(applications).set(data).where(eq(applications.id, id)).returning();
  return app;
}

export async function getAllApplications(): Promise<Application[]> {
  return db.select().from(applications).orderBy(desc(applications.createdAt));
}

export async function createNegotiationMessage(data: Omit<NegotiationMessage, "id" | "createdAt">): Promise<NegotiationMessage> {
  const [msg] = await db.insert(negotiationMessages).values(data).returning();
  return msg;
}

export async function getMessagesByApplication(applicationId: string): Promise<NegotiationMessage[]> {
  return db.select().from(negotiationMessages)
    .where(eq(negotiationMessages.applicationId, applicationId))
    .orderBy(negotiationMessages.createdAt);
}

export async function createShift(data: Omit<Shift, "id">): Promise<Shift> {
  const [shift] = await db.insert(shifts).values(data).returning();
  return shift;
}

export async function getShiftsByEMS(emsId: string): Promise<Shift[]> {
  return db.select().from(shifts).where(eq(shifts.emsId, emsId));
}

export async function getShiftsByCompany(companyId: string): Promise<Shift[]> {
  return db.select().from(shifts).where(eq(shifts.companyId, companyId));
}

export async function updateShift(id: string, data: Partial<Shift>): Promise<Shift | undefined> {
  const [shift] = await db.update(shifts).set(data).where(eq(shifts.id, id)).returning();
  return shift;
}

export async function getAllShifts(): Promise<Shift[]> {
  return db.select().from(shifts);
}

export async function createSupportTicket(data: Omit<SupportTicket, "id" | "createdAt" | "status">): Promise<SupportTicket> {
  const [ticket] = await db.insert(supportTickets).values({
    ...data,
    status: "open",
  }).returning();
  return ticket;
}

export async function getSupportTicketsByUser(userId: string): Promise<SupportTicket[]> {
  return db.select().from(supportTickets)
    .where(eq(supportTickets.userId, userId))
    .orderBy(desc(supportTickets.createdAt));
}

export async function getAllSupportTickets(): Promise<SupportTicket[]> {
  return db.select().from(supportTickets).orderBy(desc(supportTickets.createdAt));
}

export async function updateSupportTicket(id: string, data: Partial<SupportTicket>): Promise<SupportTicket | undefined> {
  const [ticket] = await db.update(supportTickets).set(data).where(eq(supportTickets.id, id)).returning();
  return ticket;
}

export async function getStats() {
  const [emsCount] = await db.select({ count: sql<number>`count(*)` }).from(users).where(eq(users.role, "ems"));
  const [companyCount] = await db.select({ count: sql<number>`count(*)` }).from(users).where(eq(users.role, "company"));
  const [callCount] = await db.select({ count: sql<number>`count(*)` }).from(calls);
  const [shiftCount] = await db.select({ count: sql<number>`count(*)` }).from(shifts);
  const [ticketCount] = await db.select({ count: sql<number>`count(*)` }).from(supportTickets);
  const [verifiedCount] = await db.select({ count: sql<number>`count(*)` }).from(users).where(eq(users.isVerified, true));

  return {
    emsWorkers: Number(emsCount?.count || 0),
    companies: Number(companyCount?.count || 0),
    totalCalls: Number(callCount?.count || 0),
    totalShifts: Number(shiftCount?.count || 0),
    openTickets: Number(ticketCount?.count || 0),
    verifiedUsers: Number(verifiedCount?.count || 0),
  };
}

export async function createAnnouncement(data: Omit<Announcement, "id" | "createdAt">): Promise<Announcement> {
  const [ann] = await db.insert(announcements).values(data).returning();
  return ann;
}

export async function getAllAnnouncements(): Promise<Announcement[]> {
  return db.select().from(announcements).orderBy(desc(announcements.createdAt));
}

export async function getAnnouncementsByRegion(city: string, state: string): Promise<Announcement[]> {
  return db.select().from(announcements)
    .where(
      or(
        and(isNull(announcements.city), isNull(announcements.state)),
        and(eq(announcements.city, city), eq(announcements.state, state))
      )
    )
    .orderBy(desc(announcements.createdAt));
}

export async function deleteAnnouncement(id: string): Promise<boolean> {
  const result = await db.delete(announcements).where(eq(announcements.id, id)).returning();
  return result.length > 0;
}

export async function createPremiumAd(data: Omit<PremiumAd, "id" | "createdAt" | "status">): Promise<PremiumAd> {
  const [ad] = await db.insert(premiumAds).values({
    ...data,
    status: "active",
  }).returning();
  return ad;
}

export async function getActivePremiumAds(): Promise<PremiumAd[]> {
  const now = new Date();
  await db.update(premiumAds)
    .set({ status: "expired" })
    .where(and(
      eq(premiumAds.status, "active"),
      sql`${premiumAds.endDate} < ${now}`
    ));
  return db.select().from(premiumAds)
    .where(eq(premiumAds.status, "active"))
    .orderBy(desc(premiumAds.createdAt));
}

export async function getPremiumAdsByCompany(companyId: string): Promise<PremiumAd[]> {
  return db.select().from(premiumAds)
    .where(eq(premiumAds.companyId, companyId))
    .orderBy(desc(premiumAds.createdAt));
}

export async function getAllPremiumAds(): Promise<PremiumAd[]> {
  return db.select().from(premiumAds).orderBy(desc(premiumAds.createdAt));
}

export async function deletePremiumAd(id: string): Promise<boolean> {
  const result = await db.delete(premiumAds).where(eq(premiumAds.id, id)).returning();
  return result.length > 0;
}

export async function createWithdrawal(data: { userId: string; amount: number; method: "bank" | "cashapp" }): Promise<Withdrawal> {
  const [w] = await db.insert(withdrawals).values({
    userId: data.userId,
    amount: data.amount,
    method: data.method,
    status: "pending",
  }).returning();
  return w;
}

export async function getWithdrawalsByUser(userId: string): Promise<Withdrawal[]> {
  return db.select().from(withdrawals)
    .where(eq(withdrawals.userId, userId))
    .orderBy(desc(withdrawals.createdAt));
}

export async function getAllWithdrawals(): Promise<Withdrawal[]> {
  return db.select().from(withdrawals).orderBy(desc(withdrawals.createdAt));
}

export async function getWithdrawalById(id: string): Promise<Withdrawal | undefined> {
  const [w] = await db.select().from(withdrawals).where(eq(withdrawals.id, id));
  return w;
}

export async function updateWithdrawal(id: string, data: Partial<Withdrawal>): Promise<Withdrawal | undefined> {
  const [w] = await db.update(withdrawals).set({ ...data, updatedAt: new Date() }).where(eq(withdrawals.id, id)).returning();
  return w;
}

export async function createAdUnlockRequest(data: { companyId: string; companyName: string }): Promise<AdUnlockRequest> {
  const [req] = await db.insert(adUnlockRequests).values({
    companyId: data.companyId,
    companyName: data.companyName,
    status: "pending",
  }).returning();
  return req;
}

export async function getAdUnlockRequestsByCompany(companyId: string): Promise<AdUnlockRequest[]> {
  return db.select().from(adUnlockRequests)
    .where(eq(adUnlockRequests.companyId, companyId))
    .orderBy(desc(adUnlockRequests.createdAt));
}

export async function getAllAdUnlockRequests(): Promise<AdUnlockRequest[]> {
  return db.select().from(adUnlockRequests).orderBy(desc(adUnlockRequests.createdAt));
}

export async function getAdUnlockRequestById(id: string): Promise<AdUnlockRequest | undefined> {
  const [req] = await db.select().from(adUnlockRequests).where(eq(adUnlockRequests.id, id));
  return req;
}

export async function updateAdUnlockRequest(id: string, data: Partial<AdUnlockRequest>): Promise<AdUnlockRequest | undefined> {
  const [req] = await db.update(adUnlockRequests).set(data).where(eq(adUnlockRequests.id, id)).returning();
  return req;
}
