import React, { createContext, useContext, useState, useEffect, useMemo, ReactNode } from 'react';
import { AppUser } from './storage';
import { apiPost, apiGet, setToken, clearToken, getToken } from './api';

interface AuthContextValue {
  user: AppUser | null;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<void>;
  register: (userData: Record<string, any>) => Promise<void>;
  logout: () => Promise<void>;
  refreshUser: () => Promise<void>;
  setUser: (user: AppUser) => void;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<AppUser | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const init = async () => {
      try {
        const token = await getToken();
        if (token) {
          const u = await apiGet<AppUser>('/api/auth/me');
          setUser(u);
        }
      } catch {
      }
      setIsLoading(false);
    };
    init();
  }, []);

  const login = async (email: string, password: string) => {
    const data = await apiPost<{ token: string; user: AppUser }>('/api/auth/login', { email, password });
    await setToken(data.token);
    setUser(data.user);
  };

  const register = async (userData: Record<string, any>) => {
    const data = await apiPost<{ token: string; user: AppUser }>('/api/auth/register', userData);
    await setToken(data.token);
    setUser(data.user);
  };

  const logout = async () => {
    await clearToken();
    setUser(null);
  };

  const refreshUser = async () => {
    try {
      const u = await apiGet<AppUser>('/api/auth/me');
      setUser(u);
    } catch {
      await clearToken();
      setUser(null);
    }
  };

  const value = useMemo(() => ({
    user,
    isLoading,
    login,
    register,
    logout,
    refreshUser,
    setUser,
  }), [user, isLoading]);

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within AuthProvider');
  return context;
}
