import React, { useState, useEffect, useCallback } from 'react';
import { View, Text, Pressable, StyleSheet, Alert, ScrollView, FlatList, Platform } from 'react-native';
import { router, useLocalSearchParams, useFocusEffect } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import Colors from '@/constants/colors';
import { useAuth } from '@/lib/auth-context';
import {
  getCall, Call, createApplication, getApplicationsForCall,
  getApplicationsForEMS, Application, updateCall, createShift,
  updateApplication,
} from '@/lib/storage';
import * as Haptics from 'expo-haptics';

export default function CallDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const webTopInset = Platform.OS === 'web' ? 67 : 0;
  const [call, setCall] = useState<Call | null>(null);
  const [applications, setApplications] = useState<Application[]>([]);
  const [hasApplied, setHasApplied] = useState(false);
  const [myApplication, setMyApplication] = useState<Application | null>(null);

  const loadData = useCallback(async () => {
    if (!id) return;
    const c = await getCall(id);
    if (c) setCall(c);
    const apps = await getApplicationsForCall(id);
    setApplications(apps);
    if (user?.role === 'ems') {
      const myApps = await getApplicationsForEMS(user.id);
      const mine = myApps.find(a => a.callId === id && a.status === 'pending');
      setHasApplied(!!mine);
      setMyApplication(mine || null);
    }
  }, [id, user]);

  useFocusEffect(useCallback(() => { loadData(); }, [loadData]));

  const handleAccept = async () => {
    if (!user || !call || user.role !== 'ems') return;
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    try {
      await createApplication({
        callId: call.id,
        emsId: user.id,
        emsName: (user as any).fullName,
        emsCertType: (user as any).certType,
        status: 'pending',
        proposedPay: 0,
        originalPay: 0,
      });
      if (call.status === 'open') {
        await updateCall({ ...call, status: 'pending' });
      }
      Alert.alert('Request Sent', 'Your offer has been sent. Please wait while the company reviews it.');
      await loadData();
    } catch (err: any) {
      Alert.alert('Error', err.message);
    }
  };

  const handleNotInterested = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    router.back();
  };

  const handleCancelApplication = () => {
    if (!myApplication) return;
    Alert.alert(
      'Cancel Application',
      'Are you sure you want to cancel your application for this call?',
      [
        { text: 'No', style: 'cancel' },
        {
          text: 'Yes, Cancel',
          style: 'destructive',
          onPress: async () => {
            try {
              Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
              await updateApplication({ ...myApplication, status: 'rejected' });
              Alert.alert('Cancelled', 'Your application has been withdrawn.');
              await loadData();
            } catch (err: any) {
              Alert.alert('Error', err.message || 'Failed to cancel application');
            }
          },
        },
      ]
    );
  };

  const handleApplicationAction = async (app: Application, action: 'accept' | 'reject' | 'negotiate') => {
    if (action === 'negotiate') {
      router.push({ pathname: '/negotiate/[id]', params: { id: app.id } });
      return;
    }
    if (action === 'accept') {
      Alert.alert(
        'Confirm Worker',
        `Are you sure you want to confirm ${app.emsName} for this call?`,
        [
          { text: 'Cancel', style: 'cancel' },
          {
            text: 'Confirm',
            onPress: async () => {
              Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
              const updated = { ...app, status: 'accepted' as const };
              await updateApplication(updated);
              if (call) {
                await updateCall({ ...call, status: 'accepted' });
                await createShift({
                  callId: call.id,
                  applicationId: app.id,
                  emsId: app.emsId,
                  companyId: call.companyId,
                  startedAt: new Date().toISOString(),
                  payAmount: app.proposedPay,
                  status: 'active',
                });
              }
              Alert.alert('Confirmed', 'The worker has been confirmed and the shift is now active.');
              await loadData();
            },
          },
        ]
      );
      return;
    }
    Alert.alert(
      'Cancel Application',
      `Are you sure you want to cancel ${app.emsName}'s application?`,
      [
        { text: 'Go Back', style: 'cancel' },
        {
          text: 'Cancel Application',
          style: 'destructive',
          onPress: async () => {
            const updated = { ...app, status: 'rejected' as const };
            await updateApplication(updated);
            Alert.alert('Cancelled', 'The application has been cancelled.');
            await loadData();
          },
        },
      ]
    );
  };

  if (!call) return (
    <View style={[styles.container, styles.center]}>
      <Text style={styles.loadingText}>Loading...</Text>
    </View>
  );

  const formatTime = (iso: string) => new Date(iso).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  const formatDate = (iso: string) => new Date(iso).toLocaleDateString([], { weekday: 'short', month: 'short', day: 'numeric' });

  const isCompanyOwner = user?.role === 'company' && user.id === call.companyId;
  const isEms = user?.role === 'ems';

  return (
    <View style={styles.container}>
      <View style={[styles.topBar, { paddingTop: insets.top + webTopInset + 8 }]}>
        <Pressable style={styles.closeBtn} onPress={() => router.back()}>
          <Ionicons name="close" size={22} color={Colors.text} />
        </Pressable>
        <Text style={styles.topBarTitle}>Call Details</Text>
        <View style={{ width: 36 }} />
      </View>

      <ScrollView style={styles.scrollContent} contentContainerStyle={{ paddingBottom: 120 }}>
        <View style={styles.mainInfo}>
          <Text style={styles.jobType}>{call.jobType}</Text>
          <View style={styles.companyRow}>
            <Ionicons name="business" size={16} color={Colors.secondary} />
            <Text style={styles.companyName}>{call.companyName}</Text>
          </View>
        </View>

        <View style={styles.detailsCard}>
          <DetailRow icon="calendar" label="Date" value={formatDate(call.startTime)} />
          <DetailRow icon="time" label="Time" value={`${formatTime(call.startTime)} - ${formatTime(call.endTime)}`} />
          <DetailRow icon="location" label="Location" value={call.location} />
          <DetailRow icon="shield-checkmark" label="Certification" value={call.certRequired} />
          <DetailRow icon="people" label="Number Needed" value={`${call.numberNeeded}`} />
        </View>

        {isCompanyOwner && applications.length > 0 && (
          <View style={styles.applicantsSection}>
            <Text style={styles.sectionTitle}>Applicants ({applications.length})</Text>
            {applications.map(app => (
              <View key={app.id} style={styles.applicantCard}>
                <View style={styles.applicantInfo}>
                  <Text style={styles.applicantName}>{app.emsName}</Text>
                  <View style={styles.applicantDetail}>
                    <Ionicons name="shield-checkmark-outline" size={12} color={Colors.textSecondary} />
                    <Text style={styles.applicantDetailText}>{app.emsCertType}</Text>
                  </View>
                </View>
                {app.status === 'pending' && (
                  <View style={styles.actionRow}>
                    <Pressable
                      style={[styles.confirmBtn]}
                      onPress={() => handleApplicationAction(app, 'accept')}
                    >
                      <Ionicons name="checkmark-circle" size={16} color={Colors.white} />
                      <Text style={styles.confirmBtnText}>Confirm</Text>
                    </Pressable>
                    <Pressable
                      style={[styles.cancelBtn]}
                      onPress={() => handleApplicationAction(app, 'reject')}
                    >
                      <Ionicons name="close-circle" size={16} color={Colors.accent} />
                      <Text style={styles.cancelBtnText}>Cancel</Text>
                    </Pressable>
                  </View>
                )}
                {app.status !== 'pending' && (
                  <View style={[styles.statusPill, {
                    backgroundColor: app.status === 'accepted' ? 'rgba(46,204,113,0.1)' : app.status === 'rejected' ? 'rgba(230,57,70,0.1)' : 'rgba(243,156,18,0.1)',
                  }]}>
                    <Text style={[styles.statusPillText, {
                      color: app.status === 'accepted' ? Colors.success : app.status === 'rejected' ? Colors.accent : Colors.warning,
                    }]}>{app.status.charAt(0).toUpperCase() + app.status.slice(1)}</Text>
                  </View>
                )}
              </View>
            ))}
          </View>
        )}
      </ScrollView>

      {isEms && (
        <View style={[styles.bottomBar, { paddingBottom: insets.bottom + (Platform.OS === 'web' ? 34 : 16) }]}>
          {hasApplied ? (
            <View style={styles.appliedBar}>
              <View style={styles.appliedBarContent}>
                <Ionicons name="time" size={20} color={Colors.warning} />
                <Text style={styles.appliedBarText}>Waiting for company to confirm</Text>
              </View>
              <Pressable style={styles.cancelAppBtn} onPress={handleCancelApplication}>
                <Ionicons name="close-circle" size={18} color={Colors.accent} />
                <Text style={styles.cancelAppBtnText}>Cancel</Text>
              </Pressable>
            </View>
          ) : (
            <View style={styles.bottomBtnRow}>
              <Pressable
                style={({ pressed }) => [styles.notInterestedBtn, pressed && { opacity: 0.8 }]}
                onPress={handleNotInterested}
              >
                <Text style={styles.notInterestedText}>Not Interested</Text>
              </Pressable>
              <Pressable
                style={({ pressed }) => [styles.acceptCallBtn, pressed && { opacity: 0.9 }]}
                onPress={handleAccept}
              >
                <Ionicons name="checkmark-circle" size={20} color={Colors.white} />
                <Text style={styles.acceptCallText}>Preliminary Accept</Text>
              </Pressable>
            </View>
          )}
        </View>
      )}
    </View>
  );
}

function DetailRow({ icon, label, value, accent }: { icon: string; label: string; value: string; accent?: boolean }) {
  return (
    <View style={styles.detailRow}>
      <View style={styles.detailLeft}>
        <Ionicons name={icon as any} size={18} color={Colors.textTertiary} />
        <Text style={styles.detailLabel}>{label}</Text>
      </View>
      <Text style={[styles.detailValue, accent && { color: Colors.success, fontFamily: 'Inter_700Bold' }]}>{value}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  center: { alignItems: 'center', justifyContent: 'center' },
  loadingText: { fontSize: 16, fontFamily: 'Inter_500Medium', color: Colors.textSecondary },
  topBar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingBottom: 12,
    backgroundColor: Colors.surface,
    borderBottomWidth: 1,
    borderBottomColor: Colors.divider,
  },
  closeBtn: {
    width: 36,
    height: 36,
    borderRadius: 10,
    backgroundColor: Colors.inputBg,
    alignItems: 'center',
    justifyContent: 'center',
  },
  topBarTitle: { fontSize: 16, fontFamily: 'Inter_600SemiBold', color: Colors.text },
  scrollContent: { flex: 1 },
  mainInfo: { padding: 20, gap: 8, backgroundColor: Colors.surface },
  jobType: { fontSize: 24, fontFamily: 'Inter_700Bold', color: Colors.text },
  companyRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  companyName: { fontSize: 15, fontFamily: 'Inter_500Medium', color: Colors.secondary },
  detailsCard: {
    margin: 16,
    backgroundColor: Colors.surface,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: Colors.cardBorder,
    padding: 4,
  },
  detailRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 14,
    paddingHorizontal: 16,
    borderBottomWidth: 0.5,
    borderBottomColor: Colors.divider,
  },
  detailLeft: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  detailLabel: { fontSize: 14, fontFamily: 'Inter_500Medium', color: Colors.textSecondary },
  detailValue: { fontSize: 14, fontFamily: 'Inter_600SemiBold', color: Colors.text },
  applicantsSection: { padding: 16, gap: 12 },
  sectionTitle: { fontSize: 16, fontFamily: 'Inter_700Bold', color: Colors.text },
  applicantCard: {
    backgroundColor: Colors.surface,
    borderRadius: 14,
    padding: 14,
    gap: 10,
    borderWidth: 1,
    borderColor: Colors.cardBorder,
  },
  applicantInfo: { gap: 4 },
  applicantName: { fontSize: 15, fontFamily: 'Inter_600SemiBold', color: Colors.text },
  applicantDetail: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  applicantDetailText: { fontSize: 12, fontFamily: 'Inter_400Regular', color: Colors.textSecondary },
  proposedPay: { fontSize: 14, fontFamily: 'Inter_600SemiBold', color: Colors.success },
  actionRow: { flexDirection: 'row', gap: 8 },
  confirmBtn: {
    flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6,
    backgroundColor: Colors.success, borderRadius: 10, paddingVertical: 10,
  },
  confirmBtnText: { fontSize: 13, fontFamily: 'Inter_600SemiBold', color: Colors.white },
  cancelBtn: {
    flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6,
    backgroundColor: 'rgba(230,57,70,0.08)', borderRadius: 10, paddingVertical: 10,
    borderWidth: 1, borderColor: 'rgba(230,57,70,0.2)',
  },
  cancelBtnText: { fontSize: 13, fontFamily: 'Inter_600SemiBold', color: Colors.accent },
  statusPill: { alignSelf: 'flex-start', paddingHorizontal: 10, paddingVertical: 4, borderRadius: 8 },
  statusPillText: { fontSize: 12, fontFamily: 'Inter_600SemiBold' },
  bottomBar: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    paddingHorizontal: 16,
    paddingTop: 12,
    backgroundColor: Colors.surface,
    borderTopWidth: 1,
    borderTopColor: Colors.divider,
  },
  bottomBtnRow: { flexDirection: 'row', gap: 12 },
  notInterestedBtn: {
    flex: 1,
    paddingVertical: 14,
    borderRadius: 14,
    borderWidth: 1.5,
    borderColor: Colors.inputBorder,
    alignItems: 'center',
  },
  notInterestedText: { fontSize: 15, fontFamily: 'Inter_600SemiBold', color: Colors.textSecondary },
  acceptCallBtn: {
    flex: 2,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 14,
    borderRadius: 14,
    backgroundColor: Colors.success,
  },
  acceptCallText: { fontSize: 15, fontFamily: 'Inter_600SemiBold', color: Colors.white },
  appliedBar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 14,
  },
  appliedBarContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  appliedBarText: { fontSize: 15, fontFamily: 'Inter_500Medium', color: Colors.warning },
  cancelAppBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: Colors.accent,
  },
  cancelAppBtnText: { fontSize: 12, fontFamily: 'Inter_500Medium', color: Colors.accent },
});
