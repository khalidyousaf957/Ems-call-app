import React, { useEffect } from 'react';
import { View, Text, Pressable, StyleSheet, Platform } from 'react-native';
import { router } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import Colors from '@/constants/colors';
import { useAuth } from '@/lib/auth-context';

export default function WelcomeScreen() {
  const insets = useSafeAreaInsets();
  const { user, isLoading } = useAuth();
  const webTopInset = Platform.OS === 'web' ? 67 : 0;

  useEffect(() => {
    if (!isLoading && user) {
      if (user.role === 'ems') {
        router.replace('/(ems)');
      } else if (user.role === 'company') {
        router.replace('/(company)');
      } else if (user.role === 'admin') {
        router.replace('/(admin)');
      }
    }
  }, [user, isLoading]);

  if (isLoading || user) return <View style={{ flex: 1, backgroundColor: Colors.primary }} />;

  return (
    <LinearGradient
      colors={['#1B3A5C', '#0D1F33']}
      style={styles.container}
    >
      <View style={[styles.content, { paddingTop: insets.top + webTopInset + 60 }]}>
        <View style={styles.logoArea}>
          <View style={styles.iconCircle}>
            <Ionicons name="medkit" size={40} color={Colors.white} />
          </View>
          <Text style={styles.appName}>EMS Call</Text>
          <Text style={styles.tagline}>Safe work for EMS, faster staffing{'\n'}for companies – all in one app.</Text>
        </View>

        <View style={[styles.buttonArea, { paddingBottom: insets.bottom + (Platform.OS === 'web' ? 34 : 20) }]}>
          <Text style={styles.sectionLabel}>Login</Text>
          <View style={styles.buttonRow}>
            <Pressable
              style={({ pressed }) => [styles.outlineBtn, pressed && styles.btnPressed]}
              onPress={() => router.push('/(auth)/login?role=ems')}
            >
              <Ionicons name="medkit-outline" size={20} color={Colors.white} />
              <Text style={styles.outlineBtnText}>EMS</Text>
            </Pressable>
            <Pressable
              style={({ pressed }) => [styles.outlineBtn, pressed && styles.btnPressed]}
              onPress={() => router.push('/(auth)/login?role=company')}
            >
              <Ionicons name="business-outline" size={20} color={Colors.white} />
              <Text style={styles.outlineBtnText}>Company</Text>
            </Pressable>
          </View>

          <View style={styles.dividerRow}>
            <View style={styles.dividerLine} />
            <Text style={styles.dividerText}>or</Text>
            <View style={styles.dividerLine} />
          </View>

          <Text style={styles.sectionLabel}>Create Account</Text>
          <View style={styles.buttonRow}>
            <Pressable
              style={({ pressed }) => [styles.solidBtn, pressed && styles.solidBtnPressed]}
              onPress={() => router.push('/(auth)/create-ems')}
            >
              <Ionicons name="medkit" size={20} color={Colors.primary} />
              <Text style={styles.solidBtnText}>EMS</Text>
            </Pressable>
            <Pressable
              style={({ pressed }) => [styles.solidBtn, pressed && styles.solidBtnPressed]}
              onPress={() => router.push('/(auth)/create-company')}
            >
              <Ionicons name="business" size={20} color={Colors.primary} />
              <Text style={styles.solidBtnText}>Company</Text>
            </Pressable>
          </View>
        </View>
      </View>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { flex: 1, justifyContent: 'space-between', paddingHorizontal: 24 },
  logoArea: { alignItems: 'center', gap: 16 },
  iconCircle: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: 'rgba(230, 57, 70, 0.9)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  appName: {
    fontSize: 36,
    fontFamily: 'Inter_700Bold',
    color: Colors.white,
    letterSpacing: -1,
  },
  tagline: {
    fontSize: 16,
    fontFamily: 'Inter_400Regular',
    color: 'rgba(255,255,255,0.7)',
    textAlign: 'center',
    lineHeight: 24,
  },
  buttonArea: { gap: 12 },
  sectionLabel: {
    fontSize: 13,
    fontFamily: 'Inter_600SemiBold',
    color: 'rgba(255,255,255,0.5)',
    textTransform: 'uppercase',
    letterSpacing: 1,
    marginBottom: 4,
  },
  buttonRow: { flexDirection: 'row', gap: 12 },
  outlineBtn: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 16,
    borderRadius: 14,
    borderWidth: 1.5,
    borderColor: 'rgba(255,255,255,0.3)',
  },
  outlineBtnText: {
    fontSize: 16,
    fontFamily: 'Inter_600SemiBold',
    color: Colors.white,
  },
  btnPressed: { opacity: 0.7, transform: [{ scale: 0.98 }] },
  solidBtn: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 16,
    borderRadius: 14,
    backgroundColor: Colors.white,
  },
  solidBtnText: {
    fontSize: 16,
    fontFamily: 'Inter_600SemiBold',
    color: Colors.primary,
  },
  solidBtnPressed: { opacity: 0.9, transform: [{ scale: 0.98 }] },
  dividerRow: { flexDirection: 'row', alignItems: 'center', gap: 12, marginVertical: 4 },
  dividerLine: { flex: 1, height: 1, backgroundColor: 'rgba(255,255,255,0.15)' },
  dividerText: {
    fontSize: 13,
    fontFamily: 'Inter_400Regular',
    color: 'rgba(255,255,255,0.4)',
  },
});
