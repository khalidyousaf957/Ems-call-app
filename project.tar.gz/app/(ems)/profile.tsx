import React, { useState, useCallback } from 'react';
import { View, Text, Pressable, StyleSheet, Alert, ScrollView, Platform, TextInput, Modal, ActivityIndicator, FlatList } from 'react-native';
import { router } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import Colors from '@/constants/colors';
import { useAuth } from '@/lib/auth-context';
import { EMSUser, getUserRegion, requestWithdrawal, getMyWithdrawals, Withdrawal } from '@/lib/storage';
import * as Haptics from 'expo-haptics';
import { useFocusEffect } from 'expo-router';

export default function EMSProfileScreen() {
  const { user, logout, refreshUser } = useAuth();
  const insets = useSafeAreaInsets();
  const webTopInset = Platform.OS === 'web' ? 67 : 0;
  const emsUser = user as EMSUser;

  const [showWithdraw, setShowWithdraw] = useState(false);
  const [withdrawMethod, setWithdrawMethod] = useState<'bank' | 'cashapp'>('bank');
  const [withdrawAmount, setWithdrawAmount] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [withdrawals, setWithdrawals] = useState<Withdrawal[]>([]);
  const [loadingHistory, setLoadingHistory] = useState(false);

  const loadWithdrawals = useCallback(async () => {
    try {
      setLoadingHistory(true);
      const list = await getMyWithdrawals();
      setWithdrawals(list);
    } catch {} finally {
      setLoadingHistory(false);
    }
  }, []);

  useFocusEffect(useCallback(() => { loadWithdrawals(); }, [loadWithdrawals]));

  const doLogout = async () => {
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    await logout();
  };

  const handleLogout = () => {
    if (Platform.OS === 'web') {
      const confirmed = window.confirm('Are you sure you want to sign out?');
      if (confirmed) doLogout();
    } else {
      Alert.alert('Sign Out', 'Are you sure you want to sign out?', [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Sign Out', style: 'destructive', onPress: doLogout },
      ]);
    }
  };

  const handleWithdraw = async () => {
    const amount = parseFloat(withdrawAmount);
    if (isNaN(amount) || amount <= 0) {
      Alert.alert('Invalid Amount', 'Please enter a valid amount.');
      return;
    }
    if (amount > emsUser.balance) {
      Alert.alert('Insufficient Balance', `Your balance is $${emsUser.balance.toFixed(2)}.`);
      return;
    }

    setSubmitting(true);
    try {
      await requestWithdrawal({ amount, method: withdrawMethod });
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      Alert.alert('Withdrawal Submitted', `Your request for $${amount.toFixed(2)} via ${withdrawMethod === 'bank' ? 'Bank Transfer' : 'Cash App'} has been submitted for review.`);
      setShowWithdraw(false);
      setWithdrawAmount('');
      await refreshUser();
      await loadWithdrawals();
    } catch (err: any) {
      Alert.alert('Error', err.message || 'Failed to submit withdrawal.');
    } finally {
      setSubmitting(false);
    }
  };

  const quickAmounts = [25, 50, 100, 250];

  if (!emsUser) return null;

  const statusColor = (s: string) => {
    if (s === 'completed') return Colors.success;
    if (s === 'rejected') return Colors.accent;
    return '#F59E0B';
  };

  return (
    <>
      <ScrollView style={styles.container} contentContainerStyle={{ paddingBottom: 100 }} contentInsetAdjustmentBehavior="automatic">
        <View style={[styles.headerSection, { paddingTop: insets.top + webTopInset + 20 }]}>
          <View style={styles.avatar}>
            <Text style={styles.avatarText}>
              {emsUser.fullName.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase()}
            </Text>
          </View>
          <Text style={styles.name}>{emsUser.fullName}</Text>
          <View style={styles.certBadge}>
            <Ionicons name="shield-checkmark" size={14} color={Colors.primary} />
            <Text style={styles.certText}>{emsUser.certType}</Text>
          </View>
          <View style={styles.regionBadge}>
            <Ionicons name="location" size={12} color={Colors.accent} />
            <Text style={styles.regionText}>{getUserRegion(emsUser)}</Text>
          </View>
        </View>

        <View style={styles.balanceCard}>
          <Text style={styles.balanceLabel}>Available Balance</Text>
          <Text style={styles.balanceAmount}>${emsUser.balance.toFixed(2)}</Text>
          <Pressable
            style={({ pressed }) => [styles.withdrawMainBtn, pressed && { opacity: 0.8 }]}
            onPress={() => setShowWithdraw(true)}
          >
            <Ionicons name="arrow-up-circle-outline" size={18} color={Colors.white} />
            <Text style={styles.withdrawMainBtnText}>Withdraw Funds</Text>
          </Pressable>
        </View>

        {withdrawals.length > 0 && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Withdrawal History</Text>
            <View style={styles.historyCard}>
              {withdrawals.slice(0, 10).map((w) => (
                <View key={w.id} style={styles.historyItem}>
                  <View style={styles.historyLeft}>
                    <Ionicons name={w.method === 'bank' ? 'card' : 'cash'} size={16} color={Colors.textSecondary} />
                    <View>
                      <Text style={styles.historyAmount}>${w.amount.toFixed(2)}</Text>
                      <Text style={styles.historyDate}>{new Date(w.createdAt).toLocaleDateString()}</Text>
                    </View>
                  </View>
                  <View style={[styles.statusBadge, { backgroundColor: `${statusColor(w.status)}18` }]}>
                    <Text style={[styles.statusText, { color: statusColor(w.status) }]}>{w.status}</Text>
                  </View>
                </View>
              ))}
            </View>
          </View>
        )}

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Account</Text>
          <View style={styles.menuCard}>
            <MenuItem icon="mail-outline" label="Email" value={emsUser.email} />
            <MenuItem icon="shield-outline" label="Certification" value={emsUser.certType} />
            <MenuItem icon="location-outline" label="Region" value={getUserRegion(emsUser)} />
          </View>
        </View>

        <Pressable
          style={({ pressed }) => [styles.supportBtn, pressed && { opacity: 0.9 }]}
          onPress={() => router.push('/support')}
        >
          <Ionicons name="help-buoy-outline" size={20} color={Colors.secondary} />
          <Text style={styles.supportText}>Support & Complaints</Text>
          <Ionicons name="chevron-forward" size={16} color={Colors.textTertiary} style={{ marginLeft: 'auto' as const }} />
        </Pressable>

        <Pressable
          style={({ pressed }) => [styles.logoutBtn, pressed && { opacity: 0.9 }]}
          onPress={handleLogout}
        >
          <Ionicons name="log-out-outline" size={20} color={Colors.accent} />
          <Text style={styles.logoutText}>Sign Out</Text>
        </Pressable>
      </ScrollView>

      <Modal visible={showWithdraw} animationType="slide" transparent>
        <View style={styles.modalOverlay}>
          <View style={[styles.modalContent, { paddingBottom: insets.bottom + (Platform.OS === 'web' ? 34 : 16) }]}>
            <View style={styles.modalHandle} />
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Withdraw Funds</Text>
              <Pressable onPress={() => setShowWithdraw(false)}>
                <Ionicons name="close" size={24} color={Colors.textSecondary} />
              </Pressable>
            </View>

            <Text style={styles.modalBalance}>Balance: ${emsUser.balance.toFixed(2)}</Text>

            <Text style={styles.fieldLabel}>Withdrawal Method</Text>
            <View style={styles.methodRow}>
              <Pressable
                style={[styles.methodBtn, withdrawMethod === 'bank' && styles.methodBtnActive]}
                onPress={() => setWithdrawMethod('bank')}
              >
                <Ionicons name="card" size={18} color={withdrawMethod === 'bank' ? Colors.white : Colors.primary} />
                <Text style={[styles.methodBtnText, withdrawMethod === 'bank' && styles.methodBtnTextActive]}>Bank Transfer</Text>
              </Pressable>
              <Pressable
                style={[styles.methodBtn, withdrawMethod === 'cashapp' && styles.methodBtnActiveCash]}
                onPress={() => setWithdrawMethod('cashapp')}
              >
                <Ionicons name="cash" size={18} color={withdrawMethod === 'cashapp' ? Colors.white : '#00D632'} />
                <Text style={[styles.methodBtnText, withdrawMethod === 'cashapp' && styles.methodBtnTextActive]}>Cash App</Text>
              </Pressable>
            </View>

            <Text style={styles.fieldLabel}>Amount</Text>
            <View style={styles.amountInputRow}>
              <Text style={styles.dollarSign}>$</Text>
              <TextInput
                style={styles.amountInput}
                value={withdrawAmount}
                onChangeText={setWithdrawAmount}
                keyboardType="decimal-pad"
                placeholder="0.00"
                placeholderTextColor={Colors.textTertiary}
              />
            </View>

            <View style={styles.quickAmounts}>
              {quickAmounts.map((a) => (
                <Pressable key={a} style={styles.quickBtn} onPress={() => setWithdrawAmount(a.toString())}>
                  <Text style={styles.quickBtnText}>${a}</Text>
                </Pressable>
              ))}
              <Pressable style={styles.quickBtn} onPress={() => setWithdrawAmount(emsUser.balance.toFixed(2))}>
                <Text style={styles.quickBtnText}>All</Text>
              </Pressable>
            </View>

            <Pressable
              style={({ pressed }) => [styles.submitBtn, pressed && { opacity: 0.8 }, submitting && { opacity: 0.6 }]}
              onPress={handleWithdraw}
              disabled={submitting}
            >
              {submitting ? (
                <ActivityIndicator color={Colors.white} size="small" />
              ) : (
                <Text style={styles.submitBtnText}>Submit Withdrawal</Text>
              )}
            </Pressable>
          </View>
        </View>
      </Modal>
    </>
  );
}

function MenuItem({ icon, label, value }: { icon: any; label: string; value: string }) {
  return (
    <View style={styles.menuItem}>
      <View style={styles.menuLeft}>
        <Ionicons name={icon} size={18} color={Colors.textSecondary} />
        <Text style={styles.menuLabel}>{label}</Text>
      </View>
      <Text style={styles.menuValue} numberOfLines={1}>{value}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  headerSection: { alignItems: 'center', paddingBottom: 24, backgroundColor: Colors.surface, paddingHorizontal: 20 },
  avatar: {
    width: 72, height: 72, borderRadius: 36,
    backgroundColor: Colors.primary,
    alignItems: 'center', justifyContent: 'center', marginBottom: 12,
  },
  avatarText: { fontSize: 24, fontFamily: 'Inter_700Bold', color: Colors.white },
  name: { fontSize: 22, fontFamily: 'Inter_700Bold', color: Colors.text },
  certBadge: {
    flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: 6,
    backgroundColor: 'rgba(27,58,92,0.08)', paddingHorizontal: 10, paddingVertical: 4, borderRadius: 8,
  },
  certText: { fontSize: 13, fontFamily: 'Inter_600SemiBold', color: Colors.primary },
  regionBadge: { flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: 6 },
  regionText: { fontSize: 12, fontFamily: 'Inter_500Medium', color: Colors.accent },
  balanceCard: {
    margin: 16, backgroundColor: Colors.primary,
    borderRadius: 20, padding: 20, alignItems: 'center', gap: 8,
  },
  balanceLabel: { fontSize: 13, fontFamily: 'Inter_500Medium', color: 'rgba(255,255,255,0.7)' },
  balanceAmount: { fontSize: 36, fontFamily: 'Inter_700Bold', color: Colors.white },
  withdrawMainBtn: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6,
    backgroundColor: 'rgba(255,255,255,0.2)', paddingVertical: 12, paddingHorizontal: 28,
    borderRadius: 12, marginTop: 6, width: '100%',
  },
  withdrawMainBtnText: { fontSize: 14, fontFamily: 'Inter_600SemiBold', color: Colors.white },
  section: { paddingHorizontal: 16, marginTop: 8 },
  sectionTitle: {
    fontSize: 13, fontFamily: 'Inter_600SemiBold', color: Colors.textSecondary,
    marginBottom: 8, marginLeft: 4, textTransform: 'uppercase', letterSpacing: 0.5,
  },
  historyCard: {
    backgroundColor: Colors.surface, borderRadius: 14,
    borderWidth: 1, borderColor: Colors.cardBorder,
  },
  historyItem: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingVertical: 12, paddingHorizontal: 16,
    borderBottomWidth: 0.5, borderBottomColor: Colors.divider,
  },
  historyLeft: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  historyAmount: { fontSize: 15, fontFamily: 'Inter_600SemiBold', color: Colors.text },
  historyDate: { fontSize: 12, fontFamily: 'Inter_400Regular', color: Colors.textSecondary },
  statusBadge: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 8 },
  statusText: { fontSize: 11, fontFamily: 'Inter_600SemiBold', textTransform: 'uppercase' },
  menuCard: { backgroundColor: Colors.surface, borderRadius: 14, borderWidth: 1, borderColor: Colors.cardBorder },
  menuItem: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingVertical: 14, paddingHorizontal: 16,
    borderBottomWidth: 0.5, borderBottomColor: Colors.divider,
  },
  menuLeft: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  menuLabel: { fontSize: 14, fontFamily: 'Inter_500Medium', color: Colors.text },
  menuValue: { fontSize: 14, fontFamily: 'Inter_400Regular', color: Colors.textSecondary, maxWidth: 180 },
  supportBtn: {
    flexDirection: 'row', alignItems: 'center', gap: 10,
    marginHorizontal: 16, marginTop: 20, paddingVertical: 14, paddingHorizontal: 16,
    borderRadius: 14, backgroundColor: Colors.surface, borderWidth: 1, borderColor: Colors.cardBorder,
  },
  supportText: { fontSize: 15, fontFamily: 'Inter_500Medium', color: Colors.text },
  logoutBtn: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8,
    marginHorizontal: 16, marginTop: 12, paddingVertical: 14, borderRadius: 14,
    borderWidth: 1, borderColor: Colors.accent,
  },
  logoutText: { fontSize: 15, fontFamily: 'Inter_600SemiBold', color: Colors.accent },
  modalOverlay: {
    flex: 1, backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'flex-end',
  },
  modalContent: {
    backgroundColor: Colors.surface, borderTopLeftRadius: 24, borderTopRightRadius: 24,
    padding: 20, maxHeight: '85%',
  },
  modalHandle: {
    width: 36, height: 4, borderRadius: 2, backgroundColor: Colors.divider,
    alignSelf: 'center', marginBottom: 16,
  },
  modalHeader: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12,
  },
  modalTitle: { fontSize: 20, fontFamily: 'Inter_700Bold', color: Colors.text },
  modalBalance: {
    fontSize: 14, fontFamily: 'Inter_500Medium', color: Colors.textSecondary, marginBottom: 20,
  },
  fieldLabel: {
    fontSize: 13, fontFamily: 'Inter_600SemiBold', color: Colors.textSecondary,
    marginBottom: 8, textTransform: 'uppercase', letterSpacing: 0.5,
  },
  methodRow: { flexDirection: 'row', gap: 10, marginBottom: 20 },
  methodBtn: {
    flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6,
    paddingVertical: 14, borderRadius: 12,
    backgroundColor: Colors.background, borderWidth: 1.5, borderColor: Colors.cardBorder,
  },
  methodBtnActive: { backgroundColor: Colors.primary, borderColor: Colors.primary },
  methodBtnActiveCash: { backgroundColor: '#00D632', borderColor: '#00D632' },
  methodBtnText: { fontSize: 14, fontFamily: 'Inter_600SemiBold', color: Colors.text },
  methodBtnTextActive: { color: Colors.white },
  amountInputRow: {
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: Colors.background, borderRadius: 12,
    borderWidth: 1.5, borderColor: Colors.cardBorder,
    paddingHorizontal: 16, marginBottom: 12,
  },
  dollarSign: { fontSize: 22, fontFamily: 'Inter_700Bold', color: Colors.textSecondary },
  amountInput: {
    flex: 1, fontSize: 22, fontFamily: 'Inter_700Bold', color: Colors.text,
    paddingVertical: 14, paddingHorizontal: 8,
  },
  quickAmounts: { flexDirection: 'row', gap: 8, marginBottom: 24 },
  quickBtn: {
    flex: 1, alignItems: 'center', paddingVertical: 10, borderRadius: 10,
    backgroundColor: Colors.background, borderWidth: 1, borderColor: Colors.cardBorder,
  },
  quickBtnText: { fontSize: 13, fontFamily: 'Inter_600SemiBold', color: Colors.primary },
  submitBtn: {
    backgroundColor: Colors.accent, paddingVertical: 16, borderRadius: 14,
    alignItems: 'center', justifyContent: 'center',
  },
  submitBtnText: { fontSize: 16, fontFamily: 'Inter_700Bold', color: Colors.white },
});
