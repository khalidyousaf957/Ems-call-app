import React, { useState, useCallback } from 'react';
import { View, Text, TextInput, Pressable, StyleSheet, Alert, FlatList, Platform } from 'react-native';
import { router, useFocusEffect } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import Colors from '@/constants/colors';
import { useAuth } from '@/lib/auth-context';
import { KeyboardAwareScrollViewCompat } from '@/components/KeyboardAwareScrollViewCompat';
import { SupportTicket, EMSUser, CompanyUser, createSupportTicket, getMySupportTickets } from '@/lib/storage';

const CATEGORIES = [
  'Payment Issue',
  'Shift Problem',
  'Account Issue',
  'App Bug',
  'Report User',
  'Other',
];

export default function SupportScreen() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const webTopInset = Platform.OS === 'web' ? 67 : 0;

  const [tab, setTab] = useState<'new' | 'history'>('new');
  const [category, setCategory] = useState('');
  const [subject, setSubject] = useState('');
  const [description, setDescription] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [tickets, setTickets] = useState<SupportTicket[]>([]);

  const loadTickets = useCallback(async () => {
    if (!user) return;
    const tickets = await getMySupportTickets();
    setTickets(tickets);
  }, [user]);

  useFocusEffect(useCallback(() => { loadTickets(); }, [loadTickets]));

  const handleSubmit = async () => {
    if (!category) {
      Alert.alert('Select Category', 'Please select an issue category.');
      return;
    }
    if (!subject.trim()) {
      Alert.alert('Missing Subject', 'Please enter a subject for your issue.');
      return;
    }
    if (!description.trim()) {
      Alert.alert('Missing Description', 'Please describe your issue.');
      return;
    }
    if (!user) return;

    setSubmitting(true);
    const userName = user.role === 'ems' ? (user as EMSUser).fullName : (user as CompanyUser).companyName;
    const userRole = user.role === 'admin' ? 'company' : user.role;

    await createSupportTicket({
      userId: user.id,
      userRole,
      userName,
      category,
      subject: subject.trim(),
      description: description.trim(),
    });

    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    setSubmitting(false);
    setCategory('');
    setSubject('');
    setDescription('');

    Alert.alert(
      'Ticket Submitted',
      'Your support request has been received. Our team will review it shortly.',
      [{ text: 'OK', onPress: () => { setTab('history'); loadTickets(); } }]
    );
  };

  const getStatusInfo = (status: string) => {
    switch (status) {
      case 'open': return { label: 'Open', color: Colors.warning, bg: 'rgba(243,156,18,0.1)', icon: 'ellipse' as const };
      case 'in_review': return { label: 'In Review', color: Colors.secondary, bg: 'rgba(69,123,157,0.1)', icon: 'eye' as const };
      case 'resolved': return { label: 'Resolved', color: Colors.success, bg: 'rgba(46,204,113,0.1)', icon: 'checkmark-circle' as const };
      default: return { label: status, color: Colors.textSecondary, bg: Colors.inputBg, icon: 'ellipse' as const };
    }
  };

  const formatDate = (iso: string) => {
    const d = new Date(iso);
    return d.toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' });
  };

  const renderTicket = ({ item }: { item: SupportTicket }) => {
    const status = getStatusInfo(item.status);
    return (
      <View style={styles.ticketCard}>
        <View style={styles.ticketHeader}>
          <View style={styles.ticketCatRow}>
            <View style={styles.ticketCatBadge}>
              <Text style={styles.ticketCatText}>{item.category}</Text>
            </View>
            <View style={[styles.statusBadge, { backgroundColor: status.bg }]}>
              <Ionicons name={status.icon} size={10} color={status.color} />
              <Text style={[styles.statusText, { color: status.color }]}>{status.label}</Text>
            </View>
          </View>
          <Text style={styles.ticketDate}>{formatDate(item.createdAt)}</Text>
        </View>
        <Text style={styles.ticketSubject}>{item.subject}</Text>
        <Text style={styles.ticketDesc} numberOfLines={2}>{item.description}</Text>
      </View>
    );
  };

  return (
    <View style={styles.container}>
      <View style={[styles.topBar, { paddingTop: insets.top + webTopInset + 8 }]}>
        <Pressable style={styles.backBtn} onPress={() => router.back()}>
          <Ionicons name="arrow-back" size={22} color={Colors.text} />
        </Pressable>
        <Text style={styles.topBarTitle}>Support</Text>
        <View style={{ width: 36 }} />
      </View>

      <View style={styles.tabRow}>
        <Pressable
          style={[styles.tabBtn, tab === 'new' && styles.tabBtnActive]}
          onPress={() => setTab('new')}
        >
          <Ionicons name="create-outline" size={16} color={tab === 'new' ? Colors.primary : Colors.textTertiary} />
          <Text style={[styles.tabBtnText, tab === 'new' && styles.tabBtnTextActive]}>New Ticket</Text>
        </Pressable>
        <Pressable
          style={[styles.tabBtn, tab === 'history' && styles.tabBtnActive]}
          onPress={() => { setTab('history'); loadTickets(); }}
        >
          <Ionicons name="time-outline" size={16} color={tab === 'history' ? Colors.primary : Colors.textTertiary} />
          <Text style={[styles.tabBtnText, tab === 'history' && styles.tabBtnTextActive]}>History</Text>
          {tickets.length > 0 && (
            <View style={styles.ticketCountBadge}>
              <Text style={styles.ticketCountText}>{tickets.length}</Text>
            </View>
          )}
        </Pressable>
      </View>

      {tab === 'new' ? (
        <KeyboardAwareScrollViewCompat
          style={{ flex: 1 }}
          contentContainerStyle={[styles.formContent, { paddingBottom: insets.bottom + (Platform.OS === 'web' ? 34 : 20) }]}
          bottomOffset={60}
        >
          <View style={styles.formSection}>
            <Text style={styles.formSectionTitle}>What's the issue about?</Text>
            <View style={styles.categoryGrid}>
              {CATEGORIES.map(cat => (
                <Pressable
                  key={cat}
                  style={[styles.categoryChip, category === cat && styles.categoryChipActive]}
                  onPress={() => setCategory(cat)}
                >
                  <Ionicons
                    name={getCategoryIcon(cat)}
                    size={16}
                    color={category === cat ? Colors.white : Colors.textSecondary}
                  />
                  <Text style={[styles.categoryChipText, category === cat && styles.categoryChipTextActive]}>
                    {cat}
                  </Text>
                </Pressable>
              ))}
            </View>
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>Subject</Text>
            <View style={styles.inputWrap}>
              <TextInput
                style={styles.input}
                placeholder="Brief summary of your issue"
                placeholderTextColor={Colors.textTertiary}
                value={subject}
                onChangeText={setSubject}
              />
            </View>
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>Description</Text>
            <View style={[styles.inputWrap, styles.textAreaWrap]}>
              <TextInput
                style={[styles.input, styles.textArea]}
                placeholder="Describe your issue in detail. Include any relevant information like dates, amounts, or names."
                placeholderTextColor={Colors.textTertiary}
                value={description}
                onChangeText={setDescription}
                multiline
                textAlignVertical="top"
              />
            </View>
          </View>

          <Pressable
            style={({ pressed }) => [
              styles.submitBtn,
              pressed && { opacity: 0.9 },
              submitting && { opacity: 0.7 },
            ]}
            onPress={handleSubmit}
            disabled={submitting}
          >
            <Ionicons name="send" size={18} color={Colors.white} />
            <Text style={styles.submitBtnText}>
              {submitting ? 'Submitting...' : 'Submit Ticket'}
            </Text>
          </Pressable>

          <View style={styles.infoCard}>
            <Ionicons name="information-circle-outline" size={20} color={Colors.secondary} />
            <Text style={styles.infoText}>
              Our support team typically responds within 24 hours. For urgent issues, please include as much detail as possible.
            </Text>
          </View>
        </KeyboardAwareScrollViewCompat>
      ) : (
        <FlatList
          data={tickets}
          renderItem={renderTicket}
          keyExtractor={item => item.id}
          contentContainerStyle={[styles.listContent, tickets.length === 0 && { flex: 1 }]}
          showsVerticalScrollIndicator={false}
          ListEmptyComponent={
            <View style={styles.emptyState}>
              <Ionicons name="chatbubbles-outline" size={48} color={Colors.textTertiary} />
              <Text style={styles.emptyTitle}>No Tickets</Text>
              <Text style={styles.emptyText}>You haven't submitted any support requests yet.</Text>
            </View>
          }
        />
      )}
    </View>
  );
}

function getCategoryIcon(cat: string): any {
  switch (cat) {
    case 'Payment Issue': return 'card-outline';
    case 'Shift Problem': return 'time-outline';
    case 'Account Issue': return 'person-outline';
    case 'App Bug': return 'bug-outline';
    case 'Report User': return 'flag-outline';
    case 'Other': return 'help-circle-outline';
    default: return 'help-circle-outline';
  }
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  topBar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingBottom: 12,
    backgroundColor: Colors.surface,
  },
  backBtn: {
    width: 36,
    height: 36,
    borderRadius: 10,
    backgroundColor: Colors.inputBg,
    alignItems: 'center',
    justifyContent: 'center',
  },
  topBarTitle: { fontSize: 17, fontFamily: 'Inter_600SemiBold', color: Colors.text },
  tabRow: {
    flexDirection: 'row',
    gap: 4,
    paddingHorizontal: 16,
    paddingVertical: 8,
    backgroundColor: Colors.surface,
    borderBottomWidth: 1,
    borderBottomColor: Colors.divider,
  },
  tabBtn: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingVertical: 10,
    borderRadius: 10,
    backgroundColor: Colors.inputBg,
  },
  tabBtnActive: { backgroundColor: 'rgba(27,58,92,0.1)' },
  tabBtnText: { fontSize: 14, fontFamily: 'Inter_500Medium', color: Colors.textTertiary },
  tabBtnTextActive: { color: Colors.primary, fontFamily: 'Inter_600SemiBold' },
  ticketCountBadge: {
    backgroundColor: Colors.accent,
    borderRadius: 8,
    minWidth: 18,
    height: 18,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 5,
  },
  ticketCountText: { fontSize: 10, fontFamily: 'Inter_700Bold', color: Colors.white },
  formContent: { padding: 20, gap: 20 },
  formSection: { gap: 10 },
  formSectionTitle: { fontSize: 15, fontFamily: 'Inter_600SemiBold', color: Colors.text },
  categoryGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  categoryChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingVertical: 10,
    paddingHorizontal: 14,
    borderRadius: 10,
    backgroundColor: Colors.surface,
    borderWidth: 1,
    borderColor: Colors.inputBorder,
  },
  categoryChipActive: { backgroundColor: Colors.primary, borderColor: Colors.primary },
  categoryChipText: { fontSize: 13, fontFamily: 'Inter_500Medium', color: Colors.textSecondary },
  categoryChipTextActive: { color: Colors.white },
  inputGroup: { gap: 6 },
  label: { fontSize: 13, fontFamily: 'Inter_600SemiBold', color: Colors.text, marginLeft: 4 },
  inputWrap: {
    backgroundColor: Colors.surface,
    borderWidth: 1,
    borderColor: Colors.inputBorder,
    borderRadius: 12,
    paddingHorizontal: 14,
    height: 50,
    justifyContent: 'center',
  },
  textAreaWrap: { height: 140, paddingVertical: 12 },
  input: { fontSize: 15, fontFamily: 'Inter_400Regular', color: Colors.text },
  textArea: { flex: 1, textAlignVertical: 'top' },
  submitBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: Colors.primary,
    borderRadius: 14,
    height: 52,
  },
  submitBtnText: { fontSize: 16, fontFamily: 'Inter_600SemiBold', color: Colors.white },
  infoCard: {
    flexDirection: 'row',
    gap: 10,
    padding: 14,
    backgroundColor: 'rgba(69,123,157,0.08)',
    borderRadius: 12,
    alignItems: 'flex-start',
  },
  infoText: { flex: 1, fontSize: 13, fontFamily: 'Inter_400Regular', color: Colors.textSecondary, lineHeight: 19 },
  listContent: { padding: 16, paddingBottom: 40, gap: 12 },
  ticketCard: {
    backgroundColor: Colors.surface,
    borderRadius: 14,
    padding: 16,
    gap: 8,
    borderWidth: 1,
    borderColor: Colors.cardBorder,
  },
  ticketHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  ticketCatRow: { flexDirection: 'row', gap: 8, alignItems: 'center' },
  ticketCatBadge: {
    backgroundColor: 'rgba(27,58,92,0.06)',
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 6,
  },
  ticketCatText: { fontSize: 11, fontFamily: 'Inter_600SemiBold', color: Colors.primary },
  statusBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 6,
  },
  statusText: { fontSize: 11, fontFamily: 'Inter_600SemiBold' },
  ticketDate: { fontSize: 11, fontFamily: 'Inter_400Regular', color: Colors.textTertiary },
  ticketSubject: { fontSize: 15, fontFamily: 'Inter_600SemiBold', color: Colors.text },
  ticketDesc: { fontSize: 13, fontFamily: 'Inter_400Regular', color: Colors.textSecondary, lineHeight: 19 },
  emptyState: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 12 },
  emptyTitle: { fontSize: 18, fontFamily: 'Inter_600SemiBold', color: Colors.text },
  emptyText: { fontSize: 14, fontFamily: 'Inter_400Regular', color: Colors.textSecondary, textAlign: 'center' },
});
