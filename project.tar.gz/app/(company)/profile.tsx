import React, { useState, useMemo, useCallback } from 'react';
import { View, Text, Pressable, StyleSheet, Alert, ScrollView, Platform, Modal, TextInput, ActivityIndicator } from 'react-native';
import { router } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import Colors from '@/constants/colors';
import { useAuth } from '@/lib/auth-context';
import { CompanyUser, updateUser, getUserRegion, requestWithdrawal, getMyWithdrawals, Withdrawal } from '@/lib/storage';
import * as Haptics from 'expo-haptics';
import { useFocusEffect } from 'expo-router';

const QUICK_AMOUNTS = [25, 50, 100, 250, 500];
const MONTHLY_FEE = 25;
const FREE_TRIAL_MONTHS = 2;

function getSubscriptionInfo(createdAt: string, subscriptionPaidThrough?: string) {
  const created = new Date(createdAt);
  const now = new Date();
  const freeUntil = new Date(created);
  freeUntil.setMonth(freeUntil.getMonth() + FREE_TRIAL_MONTHS);

  const isInFreeTrial = now < freeUntil;

  if (isInFreeTrial) {
    const daysLeft = Math.ceil((freeUntil.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
    return { status: 'free_trial' as const, daysLeft, freeUntil, isActive: true, nextDue: freeUntil };
  }

  if (subscriptionPaidThrough) {
    const paidThrough = new Date(subscriptionPaidThrough);
    if (now <= paidThrough) {
      const daysLeft = Math.ceil((paidThrough.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
      return { status: 'active' as const, daysLeft, freeUntil, isActive: true, nextDue: paidThrough };
    }
  }

  return { status: 'past_due' as const, daysLeft: 0, freeUntil, isActive: false, nextDue: null };
}

export default function CompanyProfileScreen() {
  const { user, logout, refreshUser } = useAuth();
  const insets = useSafeAreaInsets();
  const webTopInset = Platform.OS === 'web' ? 67 : 0;
  const companyUser = user as CompanyUser;

  const [showAddMoney, setShowAddMoney] = useState(false);
  const [addAmount, setAddAmount] = useState('');
  const [addingMoney, setAddingMoney] = useState(false);
  const [bankName, setBankName] = useState(companyUser?.bankName || '');
  const [accountNumber, setAccountNumber] = useState('');
  const [routingNumber, setRoutingNumber] = useState('');

  const [showWithdraw, setShowWithdraw] = useState(false);
  const [withdrawMethod, setWithdrawMethod] = useState<'bank' | 'cashapp'>('bank');
  const [withdrawAmount, setWithdrawAmount] = useState('');
  const [submittingWithdraw, setSubmittingWithdraw] = useState(false);
  const [withdrawals, setWithdrawals] = useState<Withdrawal[]>([]);

  const loadWithdrawals = useCallback(async () => {
    try {
      const list = await getMyWithdrawals();
      setWithdrawals(list);
    } catch {}
  }, []);

  useFocusEffect(useCallback(() => { loadWithdrawals(); }, [loadWithdrawals]));

  const handleWithdraw = async () => {
    const amount = parseFloat(withdrawAmount);
    if (isNaN(amount) || amount <= 0) {
      Alert.alert('Invalid Amount', 'Please enter a valid amount.');
      return;
    }
    if (amount > companyUser.balance) {
      Alert.alert('Insufficient Balance', `Your balance is $${companyUser.balance.toFixed(2)}.`);
      return;
    }
    setSubmittingWithdraw(true);
    try {
      await requestWithdrawal({ amount, method: withdrawMethod });
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      Alert.alert('Withdrawal Submitted', `Your request for $${amount.toFixed(2)} via ${withdrawMethod === 'bank' ? 'Bank Transfer' : 'Cash App'} has been submitted for review.`);
      setShowWithdraw(false);
      setWithdrawAmount('');
      await refreshUser();
      await loadWithdrawals();
    } catch (err: any) {
      Alert.alert('Error', err.message || 'Failed to submit withdrawal.');
    } finally {
      setSubmittingWithdraw(false);
    }
  };

  const statusColor = (s: string) => {
    if (s === 'completed') return Colors.success;
    if (s === 'rejected') return Colors.accent;
    return '#F59E0B';
  };

  const subInfo = useMemo(() => {
    if (!companyUser) return null;
    return getSubscriptionInfo(companyUser.createdAt, companyUser.subscriptionPaidThrough);
  }, [companyUser?.createdAt, companyUser?.subscriptionPaidThrough]);

  const doLogout = async () => {
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    await logout();
  };

  const handleLogout = () => {
    if (Platform.OS === 'web') {
      const confirmed = window.confirm('Are you sure you want to sign out?');
      if (confirmed) doLogout();
    } else {
      Alert.alert('Sign Out', 'Are you sure you want to sign out?', [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Sign Out', style: 'destructive', onPress: doLogout },
      ]);
    }
  };

  const handleBankTransfer = async () => {
    const amount = parseFloat(addAmount);
    if (isNaN(amount) || amount <= 0) {
      Alert.alert('Invalid Amount', 'Please enter a valid amount.');
      return;
    }
    if (!bankName.trim()) {
      Alert.alert('Missing Info', 'Please enter your bank name.');
      return;
    }
    if (!accountNumber.trim() || accountNumber.length < 4) {
      Alert.alert('Missing Info', 'Please enter a valid account number.');
      return;
    }

    setAddingMoney(true);
    try {
      const last4 = accountNumber.slice(-4);
      const updated = {
        ...companyUser,
        balance: companyUser.balance + amount,
        bankName: bankName.trim(),
        bankAccountLast4: last4,
      };
      await updateUser(updated);
      await refreshUser();
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      setShowAddMoney(false);
      setAddAmount('');
      setAccountNumber('');
      setRoutingNumber('');
      Alert.alert('Transfer Complete', `$${amount.toFixed(2)} has been transferred from your bank account (****${last4}) to your app account.`);
    } catch (err: any) {
      Alert.alert('Error', err.message);
    }
    setAddingMoney(false);
  };

  const handlePaySubscription = async () => {
    if (companyUser.balance < MONTHLY_FEE) {
      Alert.alert('Insufficient Balance', `You need at least $${MONTHLY_FEE}.00 in your account. Please add funds first.`, [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Add Funds', onPress: () => setShowAddMoney(true) },
      ]);
      return;
    }

    Alert.alert('Monthly Subscription', `Pay $${MONTHLY_FEE}.00 for one month of service?`, [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Pay $25',
        onPress: async () => {
          const now = new Date();
          let startFrom = now;
          if (companyUser.subscriptionPaidThrough) {
            const existing = new Date(companyUser.subscriptionPaidThrough);
            if (existing > now) startFrom = existing;
          }
          const nextDue = new Date(startFrom);
          nextDue.setMonth(nextDue.getMonth() + 1);

          const updated = {
            ...companyUser,
            balance: companyUser.balance - MONTHLY_FEE,
            subscriptionPaidThrough: nextDue.toISOString(),
          };
          await updateUser(updated);
          await refreshUser();
          Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
          Alert.alert('Payment Successful', `Your subscription is now active through ${nextDue.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}.`);
        },
      },
    ]);
  };

  if (!companyUser) return null;

  const hasBankOnFile = !!companyUser.bankName && !!companyUser.bankAccountLast4;

  return (
    <>
      <ScrollView style={styles.container} contentContainerStyle={{ paddingBottom: 100 }} contentInsetAdjustmentBehavior="automatic">
        <View style={[styles.headerSection, { paddingTop: insets.top + webTopInset + 20 }]}>
          <View style={styles.avatar}>
            <Ionicons name="business" size={28} color={Colors.white} />
          </View>
          <Text style={styles.name}>{companyUser.companyName}</Text>
          <View style={styles.regionBadge}>
            <Ionicons name="location" size={12} color={Colors.accent} />
            <Text style={styles.regionText}>{getUserRegion(companyUser)}</Text>
          </View>
        </View>

        {subInfo && (
          <View style={[styles.subCard, subInfo.status === 'past_due' && styles.subCardDue]}>
            <View style={styles.subCardTop}>
              <View style={styles.subStatusRow}>
                <Ionicons
                  name={subInfo.status === 'past_due' ? 'alert-circle' : 'shield-checkmark'}
                  size={20}
                  color={subInfo.status === 'past_due' ? Colors.accent : Colors.success}
                />
                <Text style={styles.subStatusLabel}>
                  {subInfo.status === 'free_trial' ? 'Free Trial' : subInfo.status === 'active' ? 'Active Subscription' : 'Payment Due'}
                </Text>
              </View>
              {subInfo.status === 'free_trial' && (
                <Text style={styles.subDetail}>{subInfo.daysLeft} days remaining in free trial</Text>
              )}
              {subInfo.status === 'active' && (
                <Text style={styles.subDetail}>Paid through {subInfo.nextDue?.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}</Text>
              )}
              {subInfo.status === 'past_due' && (
                <Text style={[styles.subDetail, { color: Colors.accent }]}>$25/month subscription payment required</Text>
              )}
            </View>
            {subInfo.status !== 'free_trial' && (
              <Pressable
                style={({ pressed }) => [styles.paySubBtn, subInfo.status === 'past_due' && styles.paySubBtnDue, pressed && { opacity: 0.8 }]}
                onPress={handlePaySubscription}
              >
                <Ionicons name="card-outline" size={16} color={Colors.white} />
                <Text style={styles.paySubBtnText}>
                  {subInfo.status === 'past_due' ? 'Pay Now - $25/mo' : 'Renew - $25/mo'}
                </Text>
              </Pressable>
            )}
          </View>
        )}

        <View style={styles.balanceCard}>
          <Text style={styles.balanceLabel}>App Account Balance</Text>
          <Text style={styles.balanceAmount}>${companyUser.balance.toFixed(2)}</Text>
          {hasBankOnFile && (
            <View style={styles.bankOnFile}>
              <Ionicons name="card" size={14} color="rgba(255,255,255,0.6)" />
              <Text style={styles.bankOnFileText}>{companyUser.bankName} ****{companyUser.bankAccountLast4}</Text>
            </View>
          )}
          <View style={styles.balanceBtnRow}>
            <Pressable
              style={({ pressed }) => [styles.addMoneyBtn, pressed && { opacity: 0.8 }]}
              onPress={() => {
                if (hasBankOnFile) setBankName(companyUser.bankName || '');
                setShowAddMoney(true);
              }}
            >
              <Ionicons name="arrow-down-circle-outline" size={16} color={Colors.white} />
              <Text style={styles.addMoneyBtnText}>Add Funds</Text>
            </Pressable>
            <Pressable
              style={({ pressed }) => [styles.withdrawBtn, pressed && { opacity: 0.8 }]}
              onPress={() => setShowWithdraw(true)}
            >
              <Ionicons name="arrow-up-circle-outline" size={16} color={Colors.white} />
              <Text style={styles.addMoneyBtnText}>Withdraw</Text>
            </Pressable>
          </View>
        </View>

        {withdrawals.length > 0 && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Withdrawal History</Text>
            <View style={styles.historyCard}>
              {withdrawals.slice(0, 10).map((w) => (
                <View key={w.id} style={styles.historyItem}>
                  <View style={styles.historyLeft}>
                    <Ionicons name={w.method === 'bank' ? 'card' : 'cash'} size={16} color={Colors.textSecondary} />
                    <View>
                      <Text style={styles.historyAmount}>${w.amount.toFixed(2)}</Text>
                      <Text style={styles.historyDate}>{new Date(w.createdAt).toLocaleDateString()}</Text>
                    </View>
                  </View>
                  <View style={[styles.wStatusBadge, { backgroundColor: `${statusColor(w.status)}18` }]}>
                    <Text style={[styles.wStatusText, { color: statusColor(w.status) }]}>{w.status}</Text>
                  </View>
                </View>
              ))}
            </View>
          </View>
        )}

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Company Details</Text>
          <View style={styles.menuCard}>
            <MenuItem icon="person-outline" label="Owner" value={companyUser.ownerName} />
            <MenuItem icon="mail-outline" label="Email" value={companyUser.email} />
            <MenuItem icon="call-outline" label="Phone" value={companyUser.phone} />
            <MenuItem icon="document-text-outline" label="License" value={companyUser.licenseNumber} />
            <MenuItem icon="location-outline" label="Region" value={getUserRegion(companyUser)} />
          </View>
        </View>

        <Pressable
          style={({ pressed }) => [styles.supportBtn, pressed && { opacity: 0.9 }]}
          onPress={() => router.push('/support')}
        >
          <Ionicons name="help-buoy-outline" size={20} color={Colors.secondary} />
          <Text style={styles.supportText}>Support & Complaints</Text>
          <Ionicons name="chevron-forward" size={16} color={Colors.textTertiary} style={{ marginLeft: 'auto' }} />
        </Pressable>

        <Pressable
          style={({ pressed }) => [styles.logoutBtn, pressed && { opacity: 0.9 }]}
          onPress={handleLogout}
        >
          <Ionicons name="log-out-outline" size={20} color={Colors.accent} />
          <Text style={styles.logoutText}>Sign Out</Text>
        </Pressable>
      </ScrollView>

      <Modal visible={showAddMoney} transparent animationType="fade" onRequestClose={() => setShowAddMoney(false)}>
        <Pressable style={styles.modalOverlay} onPress={() => setShowAddMoney(false)}>
          <Pressable style={styles.addMoneyCard} onPress={() => {}}>
            <View style={styles.addMoneyHeader}>
              <Text style={styles.addMoneyTitle}>Bank Transfer</Text>
              <Pressable onPress={() => setShowAddMoney(false)} hitSlop={12}>
                <Ionicons name="close" size={22} color={Colors.textSecondary} />
              </Pressable>
            </View>

            <View style={styles.bankInfoSection}>
              <Ionicons name="business-outline" size={20} color={Colors.primary} />
              <Text style={styles.bankInfoTitle}>Transfer funds from your bank to your app account</Text>
            </View>

            <View style={styles.bankInputGroup}>
              <Text style={styles.bankInputLabel}>Bank Name</Text>
              <View style={styles.bankInputWrap}>
                <Ionicons name="home-outline" size={16} color={Colors.textTertiary} />
                <TextInput
                  style={styles.bankInput}
                  placeholder="e.g. Chase, Wells Fargo"
                  placeholderTextColor={Colors.textTertiary}
                  value={bankName}
                  onChangeText={setBankName}
                />
              </View>
            </View>

            <View style={styles.bankInputGroup}>
              <Text style={styles.bankInputLabel}>Account Number</Text>
              <View style={styles.bankInputWrap}>
                <Ionicons name="lock-closed-outline" size={16} color={Colors.textTertiary} />
                <TextInput
                  style={styles.bankInput}
                  placeholder="Enter account number"
                  placeholderTextColor={Colors.textTertiary}
                  value={accountNumber}
                  onChangeText={setAccountNumber}
                  keyboardType="number-pad"
                  secureTextEntry
                />
              </View>
            </View>

            <View style={styles.bankInputGroup}>
              <Text style={styles.bankInputLabel}>Routing Number</Text>
              <View style={styles.bankInputWrap}>
                <Ionicons name="git-branch-outline" size={16} color={Colors.textTertiary} />
                <TextInput
                  style={styles.bankInput}
                  placeholder="Enter routing number"
                  placeholderTextColor={Colors.textTertiary}
                  value={routingNumber}
                  onChangeText={setRoutingNumber}
                  keyboardType="number-pad"
                />
              </View>
            </View>

            <View style={styles.bankInputGroup}>
              <Text style={styles.bankInputLabel}>Amount to Transfer</Text>
              <View style={styles.quickAmounts}>
                {QUICK_AMOUNTS.map(amt => (
                  <Pressable
                    key={amt}
                    style={[styles.quickAmtChip, addAmount === String(amt) && styles.quickAmtChipActive]}
                    onPress={() => setAddAmount(String(amt))}
                  >
                    <Text style={[styles.quickAmtText, addAmount === String(amt) && styles.quickAmtTextActive]}>${amt}</Text>
                  </Pressable>
                ))}
              </View>
              <View style={styles.addMoneyInputWrap}>
                <Text style={styles.dollarSign}>$</Text>
                <TextInput
                  style={styles.addMoneyInput}
                  placeholder="0.00"
                  placeholderTextColor={Colors.textTertiary}
                  value={addAmount}
                  onChangeText={setAddAmount}
                  keyboardType="decimal-pad"
                />
              </View>
            </View>

            <Pressable
              style={({ pressed }) => [styles.confirmAddBtn, pressed && { opacity: 0.9 }, addingMoney && { opacity: 0.7 }]}
              onPress={handleBankTransfer}
              disabled={addingMoney}
            >
              <Ionicons name="arrow-down-circle" size={18} color={Colors.white} />
              <Text style={styles.confirmAddText}>{addingMoney ? 'Processing...' : 'Transfer to App Account'}</Text>
            </Pressable>
          </Pressable>
        </Pressable>
      </Modal>

      <Modal visible={showWithdraw} animationType="slide" transparent>
        <View style={styles.wModalOverlay}>
          <View style={[styles.wModalContent, { paddingBottom: insets.bottom + (Platform.OS === 'web' ? 34 : 16) }]}>
            <View style={styles.wModalHandle} />
            <View style={styles.wModalHeader}>
              <Text style={styles.wModalTitle}>Withdraw Funds</Text>
              <Pressable onPress={() => setShowWithdraw(false)}>
                <Ionicons name="close" size={24} color={Colors.textSecondary} />
              </Pressable>
            </View>

            <Text style={styles.wModalBalance}>Balance: ${companyUser.balance.toFixed(2)}</Text>

            <Text style={styles.wFieldLabel}>Withdrawal Method</Text>
            <View style={styles.wMethodRow}>
              <Pressable
                style={[styles.wMethodBtn, withdrawMethod === 'bank' && styles.wMethodBtnActive]}
                onPress={() => setWithdrawMethod('bank')}
              >
                <Ionicons name="card" size={18} color={withdrawMethod === 'bank' ? Colors.white : Colors.primary} />
                <Text style={[styles.wMethodBtnText, withdrawMethod === 'bank' && styles.wMethodBtnTextActive]}>Bank Transfer</Text>
              </Pressable>
              <Pressable
                style={[styles.wMethodBtn, withdrawMethod === 'cashapp' && styles.wMethodBtnActiveCash]}
                onPress={() => setWithdrawMethod('cashapp')}
              >
                <Ionicons name="cash" size={18} color={withdrawMethod === 'cashapp' ? Colors.white : '#00D632'} />
                <Text style={[styles.wMethodBtnText, withdrawMethod === 'cashapp' && styles.wMethodBtnTextActive]}>Cash App</Text>
              </Pressable>
            </View>

            <Text style={styles.wFieldLabel}>Amount</Text>
            <View style={styles.wAmountInputRow}>
              <Text style={styles.wDollarSign}>$</Text>
              <TextInput
                style={styles.wAmountInput}
                value={withdrawAmount}
                onChangeText={setWithdrawAmount}
                keyboardType="decimal-pad"
                placeholder="0.00"
                placeholderTextColor={Colors.textTertiary}
              />
            </View>

            <View style={styles.wQuickAmounts}>
              {[25, 50, 100, 250].map((a) => (
                <Pressable key={a} style={styles.wQuickBtn} onPress={() => setWithdrawAmount(a.toString())}>
                  <Text style={styles.wQuickBtnText}>${a}</Text>
                </Pressable>
              ))}
              <Pressable style={styles.wQuickBtn} onPress={() => setWithdrawAmount(companyUser.balance.toFixed(2))}>
                <Text style={styles.wQuickBtnText}>All</Text>
              </Pressable>
            </View>

            <Pressable
              style={({ pressed }) => [styles.wSubmitBtn, pressed && { opacity: 0.8 }, submittingWithdraw && { opacity: 0.6 }]}
              onPress={handleWithdraw}
              disabled={submittingWithdraw}
            >
              {submittingWithdraw ? (
                <ActivityIndicator color={Colors.white} size="small" />
              ) : (
                <Text style={styles.wSubmitBtnText}>Submit Withdrawal</Text>
              )}
            </Pressable>
          </View>
        </View>
      </Modal>
    </>
  );
}

function MenuItem({ icon, label, value }: { icon: any; label: string; value: string }) {
  return (
    <View style={styles.menuItem}>
      <View style={styles.menuLeft}>
        <Ionicons name={icon} size={18} color={Colors.textSecondary} />
        <Text style={styles.menuLabel}>{label}</Text>
      </View>
      <Text style={styles.menuValue} numberOfLines={1}>{value}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  headerSection: { alignItems: 'center', paddingBottom: 24, backgroundColor: Colors.surface, paddingHorizontal: 20 },
  avatar: {
    width: 72,
    height: 72,
    borderRadius: 36,
    backgroundColor: Colors.secondary,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
  },
  name: { fontSize: 22, fontFamily: 'Inter_700Bold', color: Colors.text },
  regionBadge: { flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: 6 },
  regionText: { fontSize: 12, fontFamily: 'Inter_500Medium', color: Colors.accent },
  subCard: {
    margin: 16,
    marginBottom: 0,
    backgroundColor: Colors.surface,
    borderRadius: 16,
    padding: 16,
    borderWidth: 1,
    borderColor: Colors.success,
    gap: 12,
  },
  subCardDue: { borderColor: Colors.accent, backgroundColor: '#FFF5F5' },
  subCardTop: { gap: 4 },
  subStatusRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  subStatusLabel: { fontSize: 15, fontFamily: 'Inter_600SemiBold', color: Colors.text },
  subDetail: { fontSize: 13, fontFamily: 'Inter_400Regular', color: Colors.textSecondary, marginLeft: 28 },
  paySubBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    backgroundColor: Colors.primary,
    borderRadius: 10,
    paddingVertical: 10,
  },
  paySubBtnDue: { backgroundColor: Colors.accent },
  paySubBtnText: { fontSize: 14, fontFamily: 'Inter_600SemiBold', color: Colors.white },
  balanceCard: {
    margin: 16,
    backgroundColor: Colors.secondary,
    borderRadius: 20,
    padding: 20,
    alignItems: 'center',
    gap: 6,
  },
  balanceLabel: { fontSize: 13, fontFamily: 'Inter_500Medium', color: 'rgba(255,255,255,0.7)' },
  balanceAmount: { fontSize: 36, fontFamily: 'Inter_700Bold', color: Colors.white },
  bankOnFile: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginTop: 2,
  },
  bankOnFileText: { fontSize: 12, fontFamily: 'Inter_400Regular', color: 'rgba(255,255,255,0.6)' },
  addMoneyBtn: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    backgroundColor: 'rgba(255,255,255,0.2)',
    paddingVertical: 12,
    borderRadius: 12,
  },
  addMoneyBtnText: { fontSize: 14, fontFamily: 'Inter_600SemiBold', color: Colors.white },
  section: { paddingHorizontal: 16, marginTop: 8 },
  sectionTitle: { fontSize: 13, fontFamily: 'Inter_600SemiBold', color: Colors.textSecondary, marginBottom: 8, marginLeft: 4, textTransform: 'uppercase', letterSpacing: 0.5 },
  menuCard: { backgroundColor: Colors.surface, borderRadius: 14, borderWidth: 1, borderColor: Colors.cardBorder },
  menuItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 14,
    paddingHorizontal: 16,
    borderBottomWidth: 0.5,
    borderBottomColor: Colors.divider,
  },
  menuLeft: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  menuLabel: { fontSize: 14, fontFamily: 'Inter_500Medium', color: Colors.text },
  menuValue: { fontSize: 14, fontFamily: 'Inter_400Regular', color: Colors.textSecondary, maxWidth: 180 },
  supportBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginHorizontal: 16,
    marginTop: 20,
    paddingVertical: 14,
    paddingHorizontal: 16,
    borderRadius: 14,
    backgroundColor: Colors.surface,
    borderWidth: 1,
    borderColor: Colors.cardBorder,
  },
  supportText: { fontSize: 15, fontFamily: 'Inter_500Medium', color: Colors.text },
  logoutBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    marginHorizontal: 16,
    marginTop: 12,
    paddingVertical: 14,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: Colors.accent,
  },
  logoutText: { fontSize: 15, fontFamily: 'Inter_600SemiBold', color: Colors.accent },
  modalOverlay: {
    flex: 1,
    backgroundColor: Colors.overlay,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  addMoneyCard: {
    width: '100%',
    maxWidth: 380,
    backgroundColor: Colors.surface,
    borderRadius: 20,
    padding: 24,
    maxHeight: '90%',
  },
  addMoneyHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  addMoneyTitle: { fontSize: 20, fontFamily: 'Inter_700Bold', color: Colors.text },
  bankInfoSection: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    backgroundColor: 'rgba(27,58,92,0.06)',
    borderRadius: 12,
    padding: 12,
    marginBottom: 16,
  },
  bankInfoTitle: { fontSize: 13, fontFamily: 'Inter_400Regular', color: Colors.textSecondary, flex: 1 },
  bankInputGroup: { marginBottom: 12, gap: 4 },
  bankInputLabel: { fontSize: 12, fontFamily: 'Inter_600SemiBold', color: Colors.text, marginLeft: 2 },
  bankInputWrap: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: Colors.background,
    borderWidth: 1,
    borderColor: Colors.inputBorder,
    borderRadius: 10,
    paddingHorizontal: 12,
    height: 44,
  },
  bankInput: { flex: 1, fontSize: 14, fontFamily: 'Inter_400Regular', color: Colors.text },
  quickAmounts: { flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginBottom: 8, marginTop: 4 },
  quickAmtChip: {
    paddingVertical: 8,
    paddingHorizontal: 14,
    borderRadius: 8,
    backgroundColor: Colors.background,
    borderWidth: 1,
    borderColor: Colors.inputBorder,
  },
  quickAmtChipActive: { backgroundColor: Colors.primary, borderColor: Colors.primary },
  quickAmtText: { fontSize: 13, fontFamily: 'Inter_600SemiBold', color: Colors.text },
  quickAmtTextActive: { color: Colors.white },
  addMoneyInputWrap: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.background,
    borderWidth: 1,
    borderColor: Colors.inputBorder,
    borderRadius: 10,
    paddingHorizontal: 12,
    height: 48,
  },
  dollarSign: { fontSize: 18, fontFamily: 'Inter_700Bold', color: Colors.text, marginRight: 4 },
  addMoneyInput: { flex: 1, fontSize: 18, fontFamily: 'Inter_600SemiBold', color: Colors.text },
  confirmAddBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: Colors.success,
    borderRadius: 14,
    height: 50,
    marginTop: 16,
  },
  confirmAddText: { fontSize: 15, fontFamily: 'Inter_600SemiBold', color: Colors.white },
  balanceBtnRow: { flexDirection: 'row', gap: 10, marginTop: 6, width: '100%' },
  withdrawBtn: {
    flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6,
    backgroundColor: 'rgba(255,255,255,0.15)', paddingVertical: 12, borderRadius: 12,
    borderWidth: 1, borderColor: 'rgba(255,255,255,0.3)',
  },
  historyCard: {
    backgroundColor: Colors.surface, borderRadius: 14,
    borderWidth: 1, borderColor: Colors.cardBorder,
  },
  historyItem: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingVertical: 12, paddingHorizontal: 16,
    borderBottomWidth: 0.5, borderBottomColor: Colors.divider,
  },
  historyLeft: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  historyAmount: { fontSize: 15, fontFamily: 'Inter_600SemiBold', color: Colors.text },
  historyDate: { fontSize: 12, fontFamily: 'Inter_400Regular', color: Colors.textSecondary },
  wStatusBadge: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 8 },
  wStatusText: { fontSize: 11, fontFamily: 'Inter_600SemiBold', textTransform: 'uppercase' },
  wModalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end' },
  wModalContent: {
    backgroundColor: Colors.surface, borderTopLeftRadius: 24, borderTopRightRadius: 24,
    padding: 20, maxHeight: '85%',
  },
  wModalHandle: { width: 36, height: 4, borderRadius: 2, backgroundColor: Colors.divider, alignSelf: 'center', marginBottom: 16 },
  wModalHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  wModalTitle: { fontSize: 20, fontFamily: 'Inter_700Bold', color: Colors.text },
  wModalBalance: { fontSize: 14, fontFamily: 'Inter_500Medium', color: Colors.textSecondary, marginBottom: 20 },
  wFieldLabel: {
    fontSize: 13, fontFamily: 'Inter_600SemiBold', color: Colors.textSecondary,
    marginBottom: 8, textTransform: 'uppercase', letterSpacing: 0.5,
  },
  wMethodRow: { flexDirection: 'row', gap: 10, marginBottom: 20 },
  wMethodBtn: {
    flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6,
    paddingVertical: 14, borderRadius: 12,
    backgroundColor: Colors.background, borderWidth: 1.5, borderColor: Colors.cardBorder,
  },
  wMethodBtnActive: { backgroundColor: Colors.primary, borderColor: Colors.primary },
  wMethodBtnActiveCash: { backgroundColor: '#00D632', borderColor: '#00D632' },
  wMethodBtnText: { fontSize: 14, fontFamily: 'Inter_600SemiBold', color: Colors.text },
  wMethodBtnTextActive: { color: Colors.white },
  wAmountInputRow: {
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: Colors.background, borderRadius: 12,
    borderWidth: 1.5, borderColor: Colors.cardBorder, paddingHorizontal: 16, marginBottom: 12,
  },
  wDollarSign: { fontSize: 22, fontFamily: 'Inter_700Bold', color: Colors.textSecondary },
  wAmountInput: { flex: 1, fontSize: 22, fontFamily: 'Inter_700Bold', color: Colors.text, paddingVertical: 14, paddingHorizontal: 8 },
  wQuickAmounts: { flexDirection: 'row', gap: 8, marginBottom: 24 },
  wQuickBtn: {
    flex: 1, alignItems: 'center', paddingVertical: 10, borderRadius: 10,
    backgroundColor: Colors.background, borderWidth: 1, borderColor: Colors.cardBorder,
  },
  wQuickBtnText: { fontSize: 13, fontFamily: 'Inter_600SemiBold', color: Colors.primary },
  wSubmitBtn: { backgroundColor: Colors.accent, paddingVertical: 16, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  wSubmitBtnText: { fontSize: 16, fontFamily: 'Inter_700Bold', color: Colors.white },
});
