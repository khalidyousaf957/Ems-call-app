import React, { useState, useCallback } from 'react';
import { View, Text, FlatList, Pressable, StyleSheet, RefreshControl, Platform, Image } from 'react-native';
import { router } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import Colors from '@/constants/colors';
import { useAuth } from '@/lib/auth-context';
import { getCalls, Call, getApplicationsForCall, getUserRegion, getAnnouncements, Announcement, getActivePremiumAds } from '@/lib/storage';
import { useFocusEffect } from 'expo-router';

interface CallWithApps extends Call {
  applicationCount: number;
}

export default function CompanyCallsScreen() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const webTopInset = Platform.OS === 'web' ? 67 : 0;
  const [calls, setCalls] = useState<CallWithApps[]>([]);
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [premiumAdCount, setPremiumAdCount] = useState(0);
  const [refreshing, setRefreshing] = useState(false);

  const loadData = useCallback(async () => {
    if (!user) return;
    const allCalls = await getCalls();
    const myCalls = allCalls.filter(c => c.companyId === user.id);
    const enriched = await Promise.all(myCalls.map(async c => {
      const apps = await getApplicationsForCall(c.id);
      return { ...c, applicationCount: apps.length };
    }));
    setCalls(enriched.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()));
    try {
      const anns = await getAnnouncements();
      setAnnouncements(anns);
    } catch {}
    try {
      const ads = await getActivePremiumAds();
      setPremiumAdCount(ads.length);
    } catch {}
  }, [user]);

  useFocusEffect(useCallback(() => { loadData(); }, [loadData]));

  const onRefresh = async () => {
    setRefreshing(true);
    await loadData();
    setRefreshing(false);
  };

  const formatTime = (iso: string) => new Date(iso).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  const formatDate = (iso: string) => new Date(iso).toLocaleDateString([], { month: 'short', day: 'numeric' });

  const getStatusInfo = (status: string) => {
    switch (status) {
      case 'open': return { label: 'Open', color: Colors.success, bg: 'rgba(46,204,113,0.1)' };
      case 'pending': return { label: 'Pending', color: Colors.warning, bg: 'rgba(243,156,18,0.1)' };
      case 'accepted': return { label: 'Accepted', color: Colors.primary, bg: 'rgba(27,58,92,0.1)' };
      case 'in_progress': return { label: 'In Progress', color: Colors.secondary, bg: 'rgba(69,123,157,0.1)' };
      case 'completed': return { label: 'Completed', color: Colors.textSecondary, bg: Colors.inputBg };
      default: return { label: status, color: Colors.textSecondary, bg: Colors.inputBg };
    }
  };

  const renderCall = ({ item }: { item: CallWithApps }) => {
    const status = getStatusInfo(item.status);
    return (
      <Pressable
        style={({ pressed }) => [styles.card, pressed && { opacity: 0.95, transform: [{ scale: 0.99 }] }]}
        onPress={() => router.push({ pathname: '/call/[id]', params: { id: item.id } })}
      >
        <View style={styles.cardHeader}>
          <Text style={styles.jobType}>{item.jobType}</Text>
          <View style={[styles.statusBadge, { backgroundColor: status.bg }]}>
            <Text style={[styles.statusText, { color: status.color }]}>{status.label}</Text>
          </View>
        </View>

        <View style={styles.detailsRow}>
          <View style={styles.detailItem}>
            <Ionicons name="calendar-outline" size={14} color={Colors.textTertiary} />
            <Text style={styles.detailText}>{formatDate(item.startTime)}</Text>
          </View>
          <View style={styles.detailItem}>
            <Ionicons name="time-outline" size={14} color={Colors.textTertiary} />
            <Text style={styles.detailText}>{formatTime(item.startTime)} - {formatTime(item.endTime)}</Text>
          </View>
        </View>

        <View style={styles.cardFooter}>
          <View style={styles.footerLeft}>
            <View style={styles.footerTag}>
              <Ionicons name="shield-checkmark-outline" size={12} color={Colors.primary} />
              <Text style={styles.footerTagText}>{item.certRequired}</Text>
            </View>
          </View>
          {item.applicationCount > 0 && (
            <View style={styles.appCountBadge}>
              <Ionicons name="people" size={14} color={Colors.accent} />
              <Text style={styles.appCountText}>{item.applicationCount} applicant{item.applicationCount > 1 ? 's' : ''}</Text>
            </View>
          )}
        </View>
      </Pressable>
    );
  };

  return (
    <View style={styles.container}>
      <View style={[styles.header, { paddingTop: insets.top + webTopInset + 12 }]}>
        <View style={{ flex: 1 }}>
          <Text style={styles.title}>My Posted Calls</Text>
          <View style={styles.regionRow}>
            <Ionicons name="location" size={14} color={Colors.accent} />
            <Text style={styles.regionText}>{getUserRegion(user)}</Text>
          </View>
        </View>
        <Pressable style={styles.headerBtn} onPress={() => router.push('/premium-ads')}>
          <Ionicons name="notifications" size={20} color={Colors.accent} />
          {premiumAdCount > 0 && (
            <View style={styles.bellBadge}>
              <Text style={styles.bellBadgeText}>{premiumAdCount > 9 ? '9+' : premiumAdCount}</Text>
            </View>
          )}
        </Pressable>
      </View>

      <FlatList
        data={calls}
        renderItem={renderCall}
        keyExtractor={item => item.id}
        contentContainerStyle={[styles.listContent, calls.length === 0 && { flex: 1 }]}
        contentInsetAdjustmentBehavior="automatic"
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={Colors.primary} />}
        showsVerticalScrollIndicator={false}
        ListHeaderComponent={announcements.length > 0 ? (
          <View style={styles.announcementsSection}>
            {announcements.slice(0, 3).map(ann => (
              <View key={ann.id} style={styles.announcementCard}>
                <View style={styles.announcementIcon}>
                  <Ionicons name="megaphone" size={14} color={Colors.accent} />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={styles.announcementTitle}>{ann.title}</Text>
                  <Text style={styles.announcementMsg} numberOfLines={2}>{ann.message}</Text>
                  {ann.image && (
                    <Image source={{ uri: ann.image }} style={styles.announcementImage} />
                  )}
                </View>
              </View>
            ))}
          </View>
        ) : null}
        ListEmptyComponent={
          <View style={styles.emptyState}>
            <Ionicons name="document-text-outline" size={48} color={Colors.textTertiary} />
            <Text style={styles.emptyTitle}>No Calls Posted</Text>
            <Text style={styles.emptyText}>Post your first call to find EMS personnel in your area.</Text>
          </View>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  header: {
    paddingHorizontal: 20,
    paddingBottom: 12,
    backgroundColor: Colors.surface,
    borderBottomWidth: 1,
    borderBottomColor: Colors.divider,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  headerBtn: {
    width: 36, height: 36, borderRadius: 10,
    backgroundColor: 'rgba(27,58,92,0.08)',
    alignItems: 'center', justifyContent: 'center',
  },
  bellBadge: {
    position: 'absolute', top: -4, right: -4,
    backgroundColor: Colors.accent, borderRadius: 10,
    minWidth: 18, height: 18, alignItems: 'center', justifyContent: 'center',
    paddingHorizontal: 4, borderWidth: 2, borderColor: Colors.surface,
  },
  bellBadgeText: { fontSize: 10, fontFamily: 'Inter_700Bold', color: Colors.white },
  title: { fontSize: 24, fontFamily: 'Inter_700Bold', color: Colors.text },
  regionRow: { flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: 4 },
  regionText: { fontSize: 13, fontFamily: 'Inter_500Medium', color: Colors.accent },
  listContent: { padding: 16, paddingBottom: 100, gap: 12 },
  card: {
    backgroundColor: Colors.surface,
    borderRadius: 16,
    padding: 16,
    gap: 10,
    borderWidth: 1,
    borderColor: Colors.cardBorder,
  },
  cardHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  jobType: { fontSize: 17, fontFamily: 'Inter_600SemiBold', color: Colors.text },
  statusBadge: { paddingHorizontal: 8, paddingVertical: 3, borderRadius: 6 },
  statusText: { fontSize: 11, fontFamily: 'Inter_600SemiBold' },
  detailsRow: { flexDirection: 'row', gap: 16 },
  detailItem: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  detailText: { fontSize: 13, fontFamily: 'Inter_400Regular', color: Colors.textSecondary },
  cardFooter: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 4 },
  footerLeft: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  footerTag: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: 'rgba(27,58,92,0.06)',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
  },
  footerTagText: { fontSize: 11, fontFamily: 'Inter_500Medium', color: Colors.primary },
  payRate: { fontSize: 15, fontFamily: 'Inter_700Bold', color: Colors.success },
  appCountBadge: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  appCountText: { fontSize: 12, fontFamily: 'Inter_600SemiBold', color: Colors.accent },
  emptyState: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 12, paddingBottom: 60 },
  emptyTitle: { fontSize: 18, fontFamily: 'Inter_600SemiBold', color: Colors.text },
  emptyText: { fontSize: 14, fontFamily: 'Inter_400Regular', color: Colors.textSecondary, textAlign: 'center', lineHeight: 20 },
  announcementsSection: { gap: 8, marginBottom: 12 },
  announcementCard: {
    flexDirection: 'row', gap: 10, alignItems: 'flex-start',
    backgroundColor: 'rgba(230,57,70,0.04)', borderRadius: 12, padding: 12,
    borderWidth: 1, borderColor: 'rgba(230,57,70,0.12)',
  },
  announcementIcon: {
    width: 28, height: 28, borderRadius: 14,
    backgroundColor: 'rgba(230,57,70,0.1)',
    alignItems: 'center', justifyContent: 'center', marginTop: 2,
  },
  announcementTitle: { fontSize: 13, fontFamily: 'Inter_600SemiBold', color: Colors.text },
  announcementMsg: { fontSize: 12, fontFamily: 'Inter_400Regular', color: Colors.textSecondary, marginTop: 2, lineHeight: 17 },
  announcementImage: { width: '100%', height: 120, borderRadius: 8, marginTop: 8, backgroundColor: Colors.background },
});
