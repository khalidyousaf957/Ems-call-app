import React from 'react';
import { View, Text, Pressable, StyleSheet, Alert, ScrollView, Platform } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import Colors from '@/constants/colors';
import { useAuth } from '@/lib/auth-context';
import { AdminUser } from '@/lib/storage';
import * as Haptics from 'expo-haptics';

export default function AdminProfileScreen() {
  const { user, logout } = useAuth();
  const insets = useSafeAreaInsets();
  const webTopInset = Platform.OS === 'web' ? 67 : 0;
  const admin = user as AdminUser;

  const doLogout = async () => {
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    await logout();
  };

  const handleLogout = () => {
    if (Platform.OS === 'web') {
      const confirmed = window.confirm('Are you sure you want to sign out?');
      if (confirmed) doLogout();
    } else {
      Alert.alert('Sign Out', 'Are you sure you want to sign out?', [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Sign Out', style: 'destructive', onPress: doLogout },
      ]);
    }
  };

  if (!admin) return null;

  const formatDate = (iso: string) => {
    const d = new Date(iso);
    return d.toLocaleDateString([], { month: 'long', day: 'numeric', year: 'numeric' });
  };

  return (
    <View style={styles.container}>
      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{ paddingBottom: insets.bottom + (Platform.OS === 'web' ? 118 : 100) }}
        showsVerticalScrollIndicator={false}
      >
        <View style={[styles.headerSection, { paddingTop: insets.top + webTopInset + 24 }]}>
          <View style={styles.avatarCircle}>
            <Ionicons name="shield-checkmark" size={36} color={Colors.white} />
          </View>
          <Text style={styles.adminName}>{admin.fullName}</Text>
          <View style={styles.roleBadge}>
            <Ionicons name="key" size={12} color={Colors.accent} />
            <Text style={styles.roleBadgeText}>Administrator</Text>
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>ACCOUNT INFO</Text>
          <View style={styles.infoCard}>
            <View style={styles.infoRow}>
              <View style={styles.infoIconWrap}>
                <Ionicons name="mail" size={16} color={Colors.primary} />
              </View>
              <View style={styles.infoContent}>
                <Text style={styles.infoLabel}>Email</Text>
                <Text style={styles.infoValue}>{admin.email}</Text>
              </View>
            </View>
            <View style={styles.infoDivider} />
            <View style={styles.infoRow}>
              <View style={styles.infoIconWrap}>
                <Ionicons name="calendar" size={16} color={Colors.primary} />
              </View>
              <View style={styles.infoContent}>
                <Text style={styles.infoLabel}>Account Created</Text>
                <Text style={styles.infoValue}>{formatDate(admin.createdAt)}</Text>
              </View>
            </View>
            <View style={styles.infoDivider} />
            <View style={styles.infoRow}>
              <View style={styles.infoIconWrap}>
                <Ionicons name="shield" size={16} color={Colors.success} />
              </View>
              <View style={styles.infoContent}>
                <Text style={styles.infoLabel}>Status</Text>
                <Text style={[styles.infoValue, { color: Colors.success }]}>Verified Administrator</Text>
              </View>
            </View>
          </View>
        </View>

        <View style={styles.section}>
          <Pressable
            style={({ pressed }) => [styles.logoutBtn, pressed && { opacity: 0.9 }]}
            onPress={handleLogout}
          >
            <Ionicons name="log-out-outline" size={20} color={Colors.accent} />
            <Text style={styles.logoutBtnText}>Sign Out</Text>
          </Pressable>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  headerSection: {
    alignItems: 'center',
    paddingBottom: 24,
    backgroundColor: Colors.surface,
    gap: 10,
  },
  avatarCircle: {
    width: 80, height: 80, borderRadius: 40,
    backgroundColor: Colors.primary,
    alignItems: 'center', justifyContent: 'center',
  },
  adminName: { fontSize: 22, fontFamily: 'Inter_700Bold', color: Colors.text },
  roleBadge: {
    flexDirection: 'row', alignItems: 'center', gap: 6,
    paddingHorizontal: 12, paddingVertical: 5, borderRadius: 8,
    backgroundColor: 'rgba(230,57,70,0.08)',
  },
  roleBadgeText: { fontSize: 13, fontFamily: 'Inter_600SemiBold', color: Colors.accent },
  section: { padding: 16, gap: 10 },
  sectionTitle: {
    fontSize: 12, fontFamily: 'Inter_600SemiBold', color: Colors.textTertiary,
    letterSpacing: 1, marginLeft: 4,
  },
  infoCard: {
    backgroundColor: Colors.surface,
    borderRadius: 16,
    overflow: 'hidden' as const,
    borderWidth: 1,
    borderColor: Colors.cardBorder,
  },
  infoRow: {
    flexDirection: 'row', alignItems: 'center', gap: 12, padding: 16,
  },
  infoIconWrap: {
    width: 36, height: 36, borderRadius: 10,
    backgroundColor: 'rgba(27,58,92,0.06)',
    alignItems: 'center', justifyContent: 'center',
  },
  infoContent: { flex: 1, gap: 2 },
  infoLabel: { fontSize: 12, fontFamily: 'Inter_500Medium', color: Colors.textTertiary },
  infoValue: { fontSize: 15, fontFamily: 'Inter_500Medium', color: Colors.text },
  infoDivider: { height: 1, backgroundColor: Colors.divider, marginLeft: 64 },
  logoutBtn: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
    gap: 8, paddingVertical: 16, borderRadius: 14,
    backgroundColor: Colors.surface, borderWidth: 1, borderColor: 'rgba(230,57,70,0.2)',
  },
  logoutBtnText: { fontSize: 16, fontFamily: 'Inter_600SemiBold', color: Colors.accent },
});
