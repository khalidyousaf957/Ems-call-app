import React, { useState, useCallback } from 'react';
import { View, Text, FlatList, Pressable, StyleSheet, Alert, Platform, TextInput, Image, ActivityIndicator, Modal, ScrollView } from 'react-native';
import { useFocusEffect } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import Colors from '@/constants/colors';
import { AppUser, EMSUser, CompanyUser, getAllUsers, adminUpdateUser, getUserRegion, adminGetUserDocuments, UserDocuments } from '@/lib/storage';

type FilterRole = 'all' | 'ems' | 'company';
type FilterStatus = 'all' | 'verified' | 'unverified' | 'suspended';

export default function AdminUsersScreen() {
  const insets = useSafeAreaInsets();
  const webTopInset = Platform.OS === 'web' ? 67 : 0;

  const [users, setUsers] = useState<(AppUser & { hasDocuments?: boolean })[]>([]);
  const [filterRole, setFilterRole] = useState<FilterRole>('all');
  const [filterStatus, setFilterStatus] = useState<FilterStatus>('all');
  const [search, setSearch] = useState('');
  const [docModal, setDocModal] = useState<{ visible: boolean; userId: string; userName: string; userRole: string } | null>(null);
  const [docs, setDocs] = useState<UserDocuments | null>(null);
  const [loadingDocs, setLoadingDocs] = useState(false);
  const [imagePreview, setImagePreview] = useState<string | null>(null);

  const loadUsers = useCallback(async () => {
    const all = await getAllUsers();
    setUsers(all.filter(u => u.role !== 'admin'));
  }, []);

  useFocusEffect(useCallback(() => { loadUsers(); }, [loadUsers]));

  const filtered = users.filter(u => {
    if (filterRole !== 'all' && u.role !== filterRole) return false;
    if (filterStatus === 'verified' && !u.isVerified) return false;
    if (filterStatus === 'unverified' && u.isVerified) return false;
    if (filterStatus === 'suspended' && !u.isSuspended) return false;
    if (search.trim()) {
      const term = search.toLowerCase();
      const name = u.role === 'ems' ? (u as EMSUser).fullName : (u as CompanyUser).companyName;
      if (!name.toLowerCase().includes(term) && !u.email.toLowerCase().includes(term)) return false;
    }
    return true;
  });

  const handleVerify = async (userId: string, current: boolean) => {
    const action = current ? 'remove verification from' : 'verify';
    const doAction = async () => {
      await adminUpdateUser(userId, { isVerified: !current });
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      loadUsers();
    };
    if (Platform.OS === 'web') {
      if (window.confirm(`Are you sure you want to ${action} this user?`)) doAction();
    } else {
      Alert.alert('Confirm', `Are you sure you want to ${action} this user?`, [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Yes', onPress: doAction },
      ]);
    }
  };

  const handleSuspend = async (userId: string, current: boolean) => {
    const action = current ? 'unsuspend' : 'suspend';
    const doAction = async () => {
      await adminUpdateUser(userId, { isSuspended: !current });
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      loadUsers();
    };
    if (Platform.OS === 'web') {
      if (window.confirm(`Are you sure you want to ${action} this user?`)) doAction();
    } else {
      Alert.alert('Confirm', `Are you sure you want to ${action} this user?`, [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Yes', style: current ? 'default' : 'destructive', onPress: doAction },
      ]);
    }
  };

  const openDocuments = async (userId: string, userName: string, userRole: string) => {
    setDocModal({ visible: true, userId, userName, userRole });
    setDocs(null);
    setLoadingDocs(true);
    try {
      const data = await adminGetUserDocuments(userId);
      setDocs(data);
    } catch {
      setDocs(null);
    } finally {
      setLoadingDocs(false);
    }
  };

  const renderUser = ({ item }: { item: AppUser & { hasDocuments?: boolean } }) => {
    const isEMS = item.role === 'ems';
    const name = isEMS ? (item as EMSUser).fullName : (item as CompanyUser).companyName;
    const subtitle = isEMS
      ? `${(item as EMSUser).certType} | ${getUserRegion(item)}`
      : `${(item as CompanyUser).ownerName} | ${getUserRegion(item)}`;
    const licenseNum = isEMS ? undefined : (item as CompanyUser).licenseNumber;

    return (
      <View style={[styles.userCard, item.isSuspended && styles.userCardSuspended]}>
        <View style={styles.userInfo}>
          <View style={styles.userTop}>
            <View style={[styles.roleBadge, isEMS ? styles.emsBadge : styles.companyBadge]}>
              <Ionicons name={isEMS ? 'medkit' : 'business'} size={12} color={isEMS ? Colors.accent : Colors.primary} />
              <Text style={[styles.roleBadgeText, { color: isEMS ? Colors.accent : Colors.primary }]}>{isEMS ? 'EMS' : 'Company'}</Text>
            </View>
            <View style={styles.statusBadges}>
              {item.hasDocuments && (
                <View style={styles.docBadge}>
                  <Ionicons name="document-attach" size={12} color={Colors.secondary} />
                </View>
              )}
              {item.isVerified && (
                <View style={styles.verifiedBadge}>
                  <Ionicons name="shield-checkmark" size={12} color={Colors.success} />
                </View>
              )}
              {item.isSuspended && (
                <View style={styles.suspendedBadge}>
                  <Ionicons name="ban" size={12} color={Colors.accent} />
                </View>
              )}
            </View>
          </View>
          <Text style={styles.userName}>{name}</Text>
          <Text style={styles.userSubtitle}>{subtitle}</Text>
          <Text style={styles.userEmail}>{item.email}</Text>
          {licenseNum && <Text style={styles.userLicense}>License: {licenseNum}</Text>}
        </View>

        <View style={styles.actionRow}>
          <Pressable
            style={({ pressed }) => [styles.actionBtn, styles.actionBtnDoc, pressed && { opacity: 0.7 }]}
            onPress={() => openDocuments(item.id, name, item.role)}
          >
            <Ionicons name="document-text" size={16} color={Colors.secondary} />
            <Text style={[styles.actionBtnText, { color: Colors.secondary }]}>Documents</Text>
          </Pressable>
          <Pressable
            style={({ pressed }) => [styles.actionBtn, item.isVerified ? styles.actionBtnOutline : styles.actionBtnGreen, pressed && { opacity: 0.7 }]}
            onPress={() => handleVerify(item.id, item.isVerified)}
          >
            <Ionicons name={item.isVerified ? 'shield' : 'shield-checkmark'} size={16} color={item.isVerified ? Colors.textSecondary : Colors.white} />
            <Text style={[styles.actionBtnText, { color: item.isVerified ? Colors.textSecondary : Colors.white }]}>
              {item.isVerified ? 'Unverify' : 'Verify'}
            </Text>
          </Pressable>
        </View>
        <View style={styles.actionRow}>
          <Pressable
            style={({ pressed }) => [styles.actionBtn, item.isSuspended ? styles.actionBtnOutline : styles.actionBtnRed, pressed && { opacity: 0.7 }]}
            onPress={() => handleSuspend(item.id, item.isSuspended)}
          >
            <Ionicons name={item.isSuspended ? 'checkmark-circle' : 'ban'} size={16} color={item.isSuspended ? Colors.success : Colors.white} />
            <Text style={[styles.actionBtnText, { color: item.isSuspended ? Colors.success : Colors.white }]}>
              {item.isSuspended ? 'Unsuspend' : 'Suspend'}
            </Text>
          </Pressable>
        </View>
      </View>
    );
  };

  return (
    <View style={styles.container}>
      <View style={[styles.header, { paddingTop: insets.top + webTopInset + 12 }]}>
        <Text style={styles.headerTitle}>User Management</Text>
        <Text style={styles.headerCount}>{filtered.length} user{filtered.length !== 1 ? 's' : ''}</Text>
      </View>

      <View style={styles.searchBar}>
        <Ionicons name="search" size={18} color={Colors.textTertiary} />
        <TextInput
          style={styles.searchInput}
          placeholder="Search by name or email..."
          placeholderTextColor={Colors.textTertiary}
          value={search}
          onChangeText={setSearch}
        />
        {search.length > 0 && (
          <Pressable onPress={() => setSearch('')}>
            <Ionicons name="close-circle" size={18} color={Colors.textTertiary} />
          </Pressable>
        )}
      </View>

      <View style={styles.filterRow}>
        {(['all', 'ems', 'company'] as FilterRole[]).map(r => (
          <Pressable key={r} style={[styles.filterChip, filterRole === r && styles.filterChipActive]} onPress={() => setFilterRole(r)}>
            <Text style={[styles.filterChipText, filterRole === r && styles.filterChipTextActive]}>
              {r === 'all' ? 'All' : r === 'ems' ? 'EMS' : 'Companies'}
            </Text>
          </Pressable>
        ))}
      </View>
      <View style={[styles.filterRow, { paddingTop: 0 }]}>
        {(['all', 'verified', 'unverified', 'suspended'] as FilterStatus[]).map(s => (
          <Pressable key={s} style={[styles.filterChip, filterStatus === s && styles.filterChipActive]} onPress={() => setFilterStatus(s)}>
            <Text style={[styles.filterChipText, filterStatus === s && styles.filterChipTextActive]}>
              {s.charAt(0).toUpperCase() + s.slice(1)}
            </Text>
          </Pressable>
        ))}
      </View>

      <FlatList
        data={filtered}
        renderItem={renderUser}
        keyExtractor={item => item.id}
        contentContainerStyle={[styles.listContent, filtered.length === 0 && { flex: 1 }]}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={
          <View style={styles.emptyState}>
            <Ionicons name="people-outline" size={48} color={Colors.textTertiary} />
            <Text style={styles.emptyTitle}>No Users Found</Text>
            <Text style={styles.emptyText}>
              {search ? 'Try a different search term.' : 'No users match the current filters.'}
            </Text>
          </View>
        }
      />

      <Modal visible={!!docModal?.visible} animationType="slide" transparent>
        <View style={styles.docOverlay}>
          <View style={[styles.docSheet, { paddingBottom: insets.bottom + (Platform.OS === 'web' ? 34 : 16) }]}>
            <View style={styles.docHandle} />
            <View style={styles.docHeader}>
              <View>
                <Text style={styles.docTitle}>Documents</Text>
                <Text style={styles.docSubtitle}>{docModal?.userName} ({docModal?.userRole === 'ems' ? 'EMS' : 'Company'})</Text>
              </View>
              <Pressable onPress={() => { setDocModal(null); setDocs(null); }}>
                <Ionicons name="close" size={24} color={Colors.textSecondary} />
              </Pressable>
            </View>

            {loadingDocs ? (
              <View style={styles.docLoading}>
                <ActivityIndicator size="large" color={Colors.primary} />
                <Text style={styles.docLoadingText}>Loading documents...</Text>
              </View>
            ) : docs ? (
              <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.docScrollContent}>
                {docs.certType && (
                  <View style={styles.docInfoRow}>
                    <Ionicons name="ribbon" size={16} color={Colors.textSecondary} />
                    <Text style={styles.docInfoLabel}>Cert Type:</Text>
                    <Text style={styles.docInfoValue}>{docs.certType}</Text>
                  </View>
                )}
                {docs.licenseNumber && (
                  <View style={styles.docInfoRow}>
                    <Ionicons name="document-text" size={16} color={Colors.textSecondary} />
                    <Text style={styles.docInfoLabel}>License #:</Text>
                    <Text style={styles.docInfoValue}>{docs.licenseNumber}</Text>
                  </View>
                )}

                <Text style={styles.docSectionLabel}>
                  {docModal?.userRole === 'ems' ? 'Certification Image' : 'Business License Photo'}
                </Text>
                {docs.certificationImage ? (
                  <Pressable onPress={() => setImagePreview(docs.certificationImage)}>
                    <Image source={{ uri: docs.certificationImage }} style={styles.docImage} />
                    <View style={styles.tapHint}>
                      <Ionicons name="expand" size={14} color={Colors.white} />
                      <Text style={styles.tapHintText}>Tap to enlarge</Text>
                    </View>
                  </Pressable>
                ) : (
                  <View style={styles.noDoc}>
                    <Ionicons name="image-outline" size={32} color={Colors.textTertiary} />
                    <Text style={styles.noDocText}>Not uploaded</Text>
                  </View>
                )}

                <Text style={styles.docSectionLabel}>
                  {docModal?.userRole === 'ems' ? 'Work License / ID' : 'Owner ID Photo'}
                </Text>
                {docs.licenseImage ? (
                  <Pressable onPress={() => setImagePreview(docs.licenseImage)}>
                    <Image source={{ uri: docs.licenseImage }} style={styles.docImage} />
                    <View style={styles.tapHint}>
                      <Ionicons name="expand" size={14} color={Colors.white} />
                      <Text style={styles.tapHintText}>Tap to enlarge</Text>
                    </View>
                  </Pressable>
                ) : (
                  <View style={styles.noDoc}>
                    <Ionicons name="id-card-outline" size={32} color={Colors.textTertiary} />
                    <Text style={styles.noDocText}>Not uploaded</Text>
                  </View>
                )}

                {!docs.certificationImage && !docs.licenseImage && (
                  <View style={styles.noDocsAll}>
                    <Ionicons name="alert-circle-outline" size={40} color={Colors.warning} />
                    <Text style={styles.noDocsAllText}>No documents have been uploaded by this user.</Text>
                  </View>
                )}
              </ScrollView>
            ) : (
              <View style={styles.docLoading}>
                <Ionicons name="alert-circle" size={40} color={Colors.accent} />
                <Text style={styles.docLoadingText}>Failed to load documents.</Text>
              </View>
            )}
          </View>
        </View>
      </Modal>

      <Modal visible={!!imagePreview} animationType="fade" transparent>
        <Pressable style={styles.previewOverlay} onPress={() => setImagePreview(null)}>
          <Pressable onPress={() => setImagePreview(null)} style={styles.previewClose}>
            <Ionicons name="close-circle" size={36} color={Colors.white} />
          </Pressable>
          {imagePreview && (
            <Image source={{ uri: imagePreview }} style={styles.previewImage} resizeMode="contain" />
          )}
        </Pressable>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  header: {
    backgroundColor: Colors.primary,
    paddingHorizontal: 20,
    paddingBottom: 16,
  },
  headerTitle: { fontSize: 22, fontFamily: 'Inter_700Bold', color: Colors.white },
  headerCount: { fontSize: 13, fontFamily: 'Inter_500Medium', color: 'rgba(255,255,255,0.6)', marginTop: 2 },
  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginHorizontal: 16,
    marginTop: 12,
    backgroundColor: Colors.surface,
    borderRadius: 12,
    paddingHorizontal: 14,
    height: 44,
    borderWidth: 1,
    borderColor: Colors.cardBorder,
  },
  searchInput: { flex: 1, fontSize: 14, fontFamily: 'Inter_400Regular', color: Colors.text },
  filterRow: {
    flexDirection: 'row',
    gap: 8,
    paddingHorizontal: 16,
    paddingVertical: 8,
  },
  filterChip: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 8,
    backgroundColor: Colors.surface,
    borderWidth: 1,
    borderColor: Colors.cardBorder,
  },
  filterChipActive: { backgroundColor: Colors.primary, borderColor: Colors.primary },
  filterChipText: { fontSize: 12, fontFamily: 'Inter_500Medium', color: Colors.textSecondary },
  filterChipTextActive: { color: Colors.white },
  listContent: { padding: 16, paddingBottom: 120, gap: 12 },
  userCard: {
    backgroundColor: Colors.surface,
    borderRadius: 16,
    padding: 16,
    gap: 10,
    borderWidth: 1,
    borderColor: Colors.cardBorder,
  },
  userCardSuspended: { borderColor: 'rgba(230,57,70,0.3)', backgroundColor: 'rgba(230,57,70,0.02)' },
  userInfo: { gap: 4 },
  userTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 },
  roleBadge: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    paddingHorizontal: 8, paddingVertical: 3, borderRadius: 6,
  },
  emsBadge: { backgroundColor: 'rgba(230,57,70,0.08)' },
  companyBadge: { backgroundColor: 'rgba(27,58,92,0.08)' },
  roleBadgeText: { fontSize: 11, fontFamily: 'Inter_600SemiBold' },
  statusBadges: { flexDirection: 'row', gap: 6 },
  docBadge: {
    width: 24, height: 24, borderRadius: 12,
    backgroundColor: 'rgba(69,123,157,0.1)',
    alignItems: 'center', justifyContent: 'center',
  },
  verifiedBadge: {
    width: 24, height: 24, borderRadius: 12,
    backgroundColor: 'rgba(46,204,113,0.1)',
    alignItems: 'center', justifyContent: 'center',
  },
  suspendedBadge: {
    width: 24, height: 24, borderRadius: 12,
    backgroundColor: 'rgba(230,57,70,0.1)',
    alignItems: 'center', justifyContent: 'center',
  },
  userName: { fontSize: 16, fontFamily: 'Inter_600SemiBold', color: Colors.text },
  userSubtitle: { fontSize: 13, fontFamily: 'Inter_400Regular', color: Colors.textSecondary },
  userEmail: { fontSize: 12, fontFamily: 'Inter_400Regular', color: Colors.textTertiary },
  userLicense: { fontSize: 12, fontFamily: 'Inter_500Medium', color: Colors.textSecondary, marginTop: 2 },
  actionRow: { flexDirection: 'row', gap: 8 },
  actionBtn: {
    flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
    gap: 6, paddingVertical: 10, borderRadius: 10,
  },
  actionBtnDoc: { backgroundColor: 'rgba(69,123,157,0.08)', borderWidth: 1, borderColor: 'rgba(69,123,157,0.2)' },
  actionBtnGreen: { backgroundColor: Colors.success },
  actionBtnRed: { backgroundColor: Colors.accent },
  actionBtnOutline: { backgroundColor: Colors.inputBg, borderWidth: 1, borderColor: Colors.inputBorder },
  actionBtnText: { fontSize: 13, fontFamily: 'Inter_600SemiBold' },
  emptyState: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 12 },
  emptyTitle: { fontSize: 18, fontFamily: 'Inter_600SemiBold', color: Colors.text },
  emptyText: { fontSize: 14, fontFamily: 'Inter_400Regular', color: Colors.textSecondary, textAlign: 'center' },

  docOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end' },
  docSheet: {
    backgroundColor: Colors.surface, borderTopLeftRadius: 24, borderTopRightRadius: 24,
    padding: 20, maxHeight: '90%',
  },
  docHandle: { width: 36, height: 4, borderRadius: 2, backgroundColor: Colors.divider, alignSelf: 'center', marginBottom: 16 },
  docHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 20 },
  docTitle: { fontSize: 20, fontFamily: 'Inter_700Bold', color: Colors.text },
  docSubtitle: { fontSize: 14, fontFamily: 'Inter_400Regular', color: Colors.textSecondary, marginTop: 2 },
  docLoading: { alignItems: 'center', paddingVertical: 40, gap: 12 },
  docLoadingText: { fontSize: 14, fontFamily: 'Inter_500Medium', color: Colors.textSecondary },
  docScrollContent: { paddingBottom: 20, gap: 16 },
  docInfoRow: {
    flexDirection: 'row', alignItems: 'center', gap: 8,
    backgroundColor: Colors.background, borderRadius: 10, padding: 12,
  },
  docInfoLabel: { fontSize: 13, fontFamily: 'Inter_600SemiBold', color: Colors.textSecondary },
  docInfoValue: { fontSize: 14, fontFamily: 'Inter_600SemiBold', color: Colors.text },
  docSectionLabel: {
    fontSize: 13, fontFamily: 'Inter_600SemiBold', color: Colors.textSecondary,
    textTransform: 'uppercase', letterSpacing: 0.5, marginTop: 4,
  },
  docImage: {
    width: '100%', height: 220, borderRadius: 14,
    backgroundColor: Colors.background, resizeMode: 'cover',
  },
  tapHint: {
    position: 'absolute', bottom: 8, right: 8,
    flexDirection: 'row', alignItems: 'center', gap: 4,
    backgroundColor: 'rgba(0,0,0,0.6)', borderRadius: 8, paddingHorizontal: 8, paddingVertical: 4,
  },
  tapHintText: { fontSize: 11, fontFamily: 'Inter_500Medium', color: Colors.white },
  noDoc: {
    alignItems: 'center', justifyContent: 'center', paddingVertical: 32,
    backgroundColor: Colors.background, borderRadius: 14,
    borderWidth: 1, borderColor: Colors.cardBorder, borderStyle: 'dashed',
  },
  noDocText: { fontSize: 13, fontFamily: 'Inter_500Medium', color: Colors.textTertiary, marginTop: 8 },
  noDocsAll: { alignItems: 'center', paddingVertical: 24, gap: 8 },
  noDocsAllText: { fontSize: 14, fontFamily: 'Inter_500Medium', color: Colors.textSecondary, textAlign: 'center' },

  previewOverlay: {
    flex: 1, backgroundColor: 'rgba(0,0,0,0.9)',
    justifyContent: 'center', alignItems: 'center',
  },
  previewClose: { position: 'absolute', top: 50, right: 20, zIndex: 10 },
  previewImage: { width: '90%', height: '80%' },
});
