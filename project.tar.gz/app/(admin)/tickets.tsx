import React, { useState, useCallback } from 'react';
import { View, Text, FlatList, Pressable, StyleSheet, Alert, Platform, TextInput } from 'react-native';
import { useFocusEffect } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import Colors from '@/constants/colors';
import { SupportTicket, getAllSupportTickets, updateSupportTicket } from '@/lib/storage';

type FilterTab = 'open' | 'in_review' | 'resolved' | 'all';

export default function AdminTicketsScreen() {
  const insets = useSafeAreaInsets();
  const webTopInset = Platform.OS === 'web' ? 67 : 0;

  const [tickets, setTickets] = useState<SupportTicket[]>([]);
  const [filterTab, setFilterTab] = useState<FilterTab>('open');
  const [noteInput, setNoteInput] = useState<{ [id: string]: string }>({});
  const [expanded, setExpanded] = useState<string | null>(null);

  const loadTickets = useCallback(async () => {
    const all = await getAllSupportTickets();
    setTickets(all.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()));
  }, []);

  useFocusEffect(useCallback(() => { loadTickets(); }, [loadTickets]));

  const filtered = tickets.filter(t => filterTab === 'all' || t.status === filterTab);

  const handleStatusChange = async (ticketId: string, newStatus: SupportTicket['status']) => {
    const note = noteInput[ticketId]?.trim();
    await updateSupportTicket(ticketId, { status: newStatus, ...(note ? { adminNote: note } : {}) });
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    setNoteInput(prev => { const n = { ...prev }; delete n[ticketId]; return n; });
    loadTickets();
  };

  const formatDate = (iso: string) => {
    const d = new Date(iso);
    return d.toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric', hour: '2-digit', minute: '2-digit' });
  };

  const getStatusInfo = (status: string) => {
    switch (status) {
      case 'open': return { label: 'Open', color: Colors.warning, bg: 'rgba(243,156,18,0.1)', icon: 'ellipse' as const };
      case 'in_review': return { label: 'In Review', color: Colors.secondary, bg: 'rgba(69,123,157,0.1)', icon: 'eye' as const };
      case 'resolved': return { label: 'Resolved', color: Colors.success, bg: 'rgba(46,204,113,0.1)', icon: 'checkmark-circle' as const };
      default: return { label: status, color: Colors.textSecondary, bg: Colors.inputBg, icon: 'ellipse' as const };
    }
  };

  const getCategoryIcon = (cat: string): any => {
    switch (cat) {
      case 'Payment Issue': return 'card-outline';
      case 'Shift Problem': return 'time-outline';
      case 'Account Issue': return 'person-outline';
      case 'App Bug': return 'bug-outline';
      case 'Report User': return 'flag-outline';
      default: return 'help-circle-outline';
    }
  };

  const tabCounts = {
    open: tickets.filter(t => t.status === 'open').length,
    in_review: tickets.filter(t => t.status === 'in_review').length,
    resolved: tickets.filter(t => t.status === 'resolved').length,
    all: tickets.length,
  };

  const renderTicket = ({ item }: { item: SupportTicket }) => {
    const status = getStatusInfo(item.status);
    const isExpanded = expanded === item.id;

    return (
      <Pressable style={styles.ticketCard} onPress={() => setExpanded(isExpanded ? null : item.id)}>
        <View style={styles.ticketTop}>
          <View style={styles.ticketMeta}>
            <View style={[styles.statusBadge, { backgroundColor: status.bg }]}>
              <Ionicons name={status.icon} size={10} color={status.color} />
              <Text style={[styles.statusText, { color: status.color }]}>{status.label}</Text>
            </View>
            <View style={styles.categoryBadge}>
              <Ionicons name={getCategoryIcon(item.category)} size={12} color={Colors.primary} />
              <Text style={styles.categoryText}>{item.category}</Text>
            </View>
          </View>
          <Text style={styles.ticketDate}>{formatDate(item.createdAt)}</Text>
        </View>

        <Text style={styles.ticketSubject}>{item.subject}</Text>
        <Text style={styles.ticketUser}>
          <Text style={{ fontFamily: 'Inter_500Medium' }}>{item.userName}</Text>
          {' '}({item.userRole.toUpperCase()})
        </Text>

        {isExpanded && (
          <View style={styles.expandedSection}>
            <View style={styles.descBox}>
              <Text style={styles.descLabel}>Description</Text>
              <Text style={styles.descText}>{item.description}</Text>
            </View>

            {item.adminNote && (
              <View style={styles.noteBox}>
                <Ionicons name="document-text" size={14} color={Colors.primary} />
                <Text style={styles.noteText}>{item.adminNote}</Text>
              </View>
            )}

            <View style={styles.noteInputWrap}>
              <TextInput
                style={styles.noteInput}
                placeholder="Add admin note..."
                placeholderTextColor={Colors.textTertiary}
                value={noteInput[item.id] || ''}
                onChangeText={text => setNoteInput(prev => ({ ...prev, [item.id]: text }))}
                multiline
              />
            </View>

            <View style={styles.statusActions}>
              {item.status !== 'in_review' && (
                <Pressable
                  style={({ pressed }) => [styles.statusBtn, styles.reviewBtn, pressed && { opacity: 0.7 }]}
                  onPress={() => handleStatusChange(item.id, 'in_review')}
                >
                  <Ionicons name="eye" size={16} color={Colors.white} />
                  <Text style={styles.statusBtnText}>Mark In Review</Text>
                </Pressable>
              )}
              {item.status !== 'resolved' && (
                <Pressable
                  style={({ pressed }) => [styles.statusBtn, styles.resolveBtn, pressed && { opacity: 0.7 }]}
                  onPress={() => handleStatusChange(item.id, 'resolved')}
                >
                  <Ionicons name="checkmark-circle" size={16} color={Colors.white} />
                  <Text style={styles.statusBtnText}>Resolve</Text>
                </Pressable>
              )}
              {item.status === 'resolved' && (
                <Pressable
                  style={({ pressed }) => [styles.statusBtn, styles.reopenBtn, pressed && { opacity: 0.7 }]}
                  onPress={() => handleStatusChange(item.id, 'open')}
                >
                  <Ionicons name="arrow-undo" size={16} color={Colors.white} />
                  <Text style={styles.statusBtnText}>Reopen</Text>
                </Pressable>
              )}
            </View>
          </View>
        )}

        <View style={styles.expandHint}>
          <Ionicons name={isExpanded ? 'chevron-up' : 'chevron-down'} size={16} color={Colors.textTertiary} />
        </View>
      </Pressable>
    );
  };

  return (
    <View style={styles.container}>
      <View style={[styles.header, { paddingTop: insets.top + webTopInset + 12 }]}>
        <Text style={styles.headerTitle}>Support Tickets</Text>
        <Text style={styles.headerCount}>{tabCounts.open} open</Text>
      </View>

      <View style={styles.tabRow}>
        {([
          { key: 'open' as FilterTab, label: 'Open' },
          { key: 'in_review' as FilterTab, label: 'Review' },
          { key: 'resolved' as FilterTab, label: 'Resolved' },
          { key: 'all' as FilterTab, label: 'All' },
        ]).map(tab => (
          <Pressable key={tab.key} style={[styles.tabChip, filterTab === tab.key && styles.tabChipActive]} onPress={() => setFilterTab(tab.key)}>
            <Text style={[styles.tabChipText, filterTab === tab.key && styles.tabChipTextActive]}>{tab.label}</Text>
            {tabCounts[tab.key] > 0 && (
              <View style={[styles.tabCount, filterTab === tab.key && styles.tabCountActive]}>
                <Text style={[styles.tabCountText, filterTab === tab.key && styles.tabCountTextActive]}>{tabCounts[tab.key]}</Text>
              </View>
            )}
          </Pressable>
        ))}
      </View>

      <FlatList
        data={filtered}
        renderItem={renderTicket}
        keyExtractor={item => item.id}
        contentContainerStyle={[styles.listContent, filtered.length === 0 && { flex: 1 }]}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={
          <View style={styles.emptyState}>
            <Ionicons name="chatbubbles-outline" size={48} color={Colors.textTertiary} />
            <Text style={styles.emptyTitle}>No Tickets</Text>
            <Text style={styles.emptyText}>
              {filterTab === 'all' ? 'No support tickets have been submitted yet.' : `No ${filterTab.replace('_', ' ')} tickets.`}
            </Text>
          </View>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  header: {
    backgroundColor: Colors.primary,
    paddingHorizontal: 20,
    paddingBottom: 16,
  },
  headerTitle: { fontSize: 22, fontFamily: 'Inter_700Bold', color: Colors.white },
  headerCount: { fontSize: 13, fontFamily: 'Inter_500Medium', color: 'rgba(255,255,255,0.6)', marginTop: 2 },
  tabRow: {
    flexDirection: 'row',
    gap: 8,
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: Colors.surface,
    borderBottomWidth: 1,
    borderBottomColor: Colors.divider,
  },
  tabChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 12,
    paddingVertical: 7,
    borderRadius: 8,
    backgroundColor: Colors.inputBg,
  },
  tabChipActive: { backgroundColor: Colors.primary },
  tabChipText: { fontSize: 13, fontFamily: 'Inter_500Medium', color: Colors.textSecondary },
  tabChipTextActive: { color: Colors.white },
  tabCount: {
    minWidth: 18, height: 18, borderRadius: 9,
    backgroundColor: Colors.cardBorder,
    alignItems: 'center', justifyContent: 'center',
    paddingHorizontal: 4,
  },
  tabCountActive: { backgroundColor: 'rgba(255,255,255,0.25)' },
  tabCountText: { fontSize: 10, fontFamily: 'Inter_700Bold', color: Colors.textSecondary },
  tabCountTextActive: { color: Colors.white },
  listContent: { padding: 16, paddingBottom: 120, gap: 12 },
  ticketCard: {
    backgroundColor: Colors.surface,
    borderRadius: 16,
    padding: 16,
    gap: 8,
    borderWidth: 1,
    borderColor: Colors.cardBorder,
  },
  ticketTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  ticketMeta: { flexDirection: 'row', gap: 6 },
  statusBadge: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    paddingHorizontal: 8, paddingVertical: 3, borderRadius: 6,
  },
  statusText: { fontSize: 11, fontFamily: 'Inter_600SemiBold' },
  categoryBadge: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    paddingHorizontal: 8, paddingVertical: 3, borderRadius: 6,
    backgroundColor: 'rgba(27,58,92,0.06)',
  },
  categoryText: { fontSize: 11, fontFamily: 'Inter_600SemiBold', color: Colors.primary },
  ticketDate: { fontSize: 11, fontFamily: 'Inter_400Regular', color: Colors.textTertiary },
  ticketSubject: { fontSize: 15, fontFamily: 'Inter_600SemiBold', color: Colors.text },
  ticketUser: { fontSize: 13, fontFamily: 'Inter_400Regular', color: Colors.textSecondary },
  expandedSection: { marginTop: 8, gap: 12 },
  descBox: {
    backgroundColor: Colors.inputBg, borderRadius: 10, padding: 12, gap: 4,
  },
  descLabel: { fontSize: 11, fontFamily: 'Inter_600SemiBold', color: Colors.textTertiary, textTransform: 'uppercase' as const, letterSpacing: 0.5 },
  descText: { fontSize: 14, fontFamily: 'Inter_400Regular', color: Colors.text, lineHeight: 20 },
  noteBox: {
    flexDirection: 'row', gap: 8, alignItems: 'flex-start',
    backgroundColor: 'rgba(27,58,92,0.04)', borderRadius: 10, padding: 12,
    borderWidth: 1, borderColor: 'rgba(27,58,92,0.1)',
  },
  noteText: { flex: 1, fontSize: 13, fontFamily: 'Inter_400Regular', color: Colors.text, lineHeight: 19 },
  noteInputWrap: {
    backgroundColor: Colors.surface,
    borderWidth: 1, borderColor: Colors.inputBorder,
    borderRadius: 10, padding: 12,
    minHeight: 60,
  },
  noteInput: { fontSize: 14, fontFamily: 'Inter_400Regular', color: Colors.text, minHeight: 40 },
  statusActions: { flexDirection: 'row', gap: 8 },
  statusBtn: {
    flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
    gap: 6, paddingVertical: 10, borderRadius: 10,
  },
  reviewBtn: { backgroundColor: Colors.secondary },
  resolveBtn: { backgroundColor: Colors.success },
  reopenBtn: { backgroundColor: Colors.warning },
  statusBtnText: { fontSize: 13, fontFamily: 'Inter_600SemiBold', color: Colors.white },
  expandHint: { alignItems: 'center', marginTop: 2 },
  emptyState: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 12 },
  emptyTitle: { fontSize: 18, fontFamily: 'Inter_600SemiBold', color: Colors.text },
  emptyText: { fontSize: 14, fontFamily: 'Inter_400Regular', color: Colors.textSecondary, textAlign: 'center' },
});
