import React, { useState } from 'react';
import { View, Text, TextInput, Pressable, StyleSheet, Alert, ActivityIndicator, Image, Platform } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import Colors from '@/constants/colors';
import { useAuth } from '@/lib/auth-context';
import { REGIONS, RegionOption } from '@/lib/storage';
import { KeyboardAwareScrollViewCompat } from '@/components/KeyboardAwareScrollViewCompat';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import * as ImagePicker from 'expo-image-picker';
import * as FileSystem from 'expo-file-system';

export default function CreateCompanyScreen() {
  const { register } = useAuth();
  const insets = useSafeAreaInsets();
  const [companyName, setCompanyName] = useState('');
  const [ownerName, setOwnerName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [licenseNumber, setLicenseNumber] = useState('');
  const [selectedRegion, setSelectedRegion] = useState<RegionOption | null>(null);
  const [showRegions, setShowRegions] = useState(false);
  const [loading, setLoading] = useState(false);
  const [licensePhoto, setLicensePhoto] = useState<string | undefined>();
  const [ownerIdPhoto, setOwnerIdPhoto] = useState<string | undefined>();

  const convertToBase64 = async (uri: string): Promise<string> => {
    if (Platform.OS === 'web') {
      const response = await fetch(uri);
      const blob = await response.blob();
      return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onloadend = () => resolve(reader.result as string);
        reader.onerror = reject;
        reader.readAsDataURL(blob);
      });
    }
    const base64 = await FileSystem.readAsStringAsync(uri, { encoding: FileSystem.EncodingType.Base64 });
    return `data:image/jpeg;base64,${base64}`;
  };

  const pickImage = async (type: 'license' | 'id') => {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ['images'],
      quality: 0.5,
    });
    if (!result.canceled && result.assets[0]) {
      if (type === 'license') setLicensePhoto(result.assets[0].uri);
      else setOwnerIdPhoto(result.assets[0].uri);
    }
  };

  const handleCreate = async () => {
    if (!companyName.trim() || !ownerName.trim() || !email.trim() || !phone.trim() || !password.trim() || !licenseNumber.trim() || !selectedRegion) {
      Alert.alert('Missing Fields', 'Please fill in all required fields.');
      return;
    }
    if (password.length < 6) {
      Alert.alert('Weak Password', 'Password must be at least 6 characters.');
      return;
    }
    setLoading(true);
    try {
      let licenseBase64: string | undefined;
      let idBase64: string | undefined;
      if (licensePhoto) licenseBase64 = await convertToBase64(licensePhoto);
      if (ownerIdPhoto) idBase64 = await convertToBase64(ownerIdPhoto);

      await register({
        role: 'company',
        email: email.trim(),
        password,
        companyName: companyName.trim(),
        ownerName: ownerName.trim(),
        phone: phone.trim(),
        licenseNumber: licenseNumber.trim(),
        certificationImage: licenseBase64,
        licenseImage: idBase64,
        city: selectedRegion.city,
        state: selectedRegion.state,
        postsToday: 0,
        lastPostDate: '',
      });
    } catch (err: any) {
      Alert.alert('Error', err.message);
      setLoading(false);
    }
  };

  return (
    <KeyboardAwareScrollViewCompat
      style={styles.container}
      contentContainerStyle={[styles.content, { paddingBottom: insets.bottom + 20 }]}
      bottomOffset={60}
    >
      <View style={styles.header}>
        <View style={styles.iconWrap}>
          <Ionicons name="business" size={24} color={Colors.secondary} />
        </View>
        <Text style={styles.title}>Company Registration</Text>
      </View>

      <View style={styles.form}>
        <InputField label="Company Name" icon="business-outline" value={companyName} onChangeText={setCompanyName} placeholder="Enter company name" />
        <InputField label="Owner Name" icon="person-outline" value={ownerName} onChangeText={setOwnerName} placeholder="Enter owner name" />
        <InputField label="Email" icon="mail-outline" value={email} onChangeText={setEmail} placeholder="Enter email" keyboardType="email-address" />
        <InputField label="Phone Number" icon="call-outline" value={phone} onChangeText={setPhone} placeholder="Enter phone number" keyboardType="phone-pad" />
        <InputField label="Company License Number" icon="document-text-outline" value={licenseNumber} onChangeText={setLicenseNumber} placeholder="Enter license number" />

        <View style={styles.inputGroup}>
          <Text style={styles.label}>Business License Photo</Text>
          <Pressable style={styles.uploadBtn} onPress={() => pickImage('license')}>
            {licensePhoto ? (
              <Image source={{ uri: licensePhoto }} style={styles.uploadPreview} />
            ) : (
              <View style={styles.uploadPlaceholder}>
                <Ionicons name="document-text-outline" size={24} color={Colors.textTertiary} />
                <Text style={styles.uploadText}>Upload Business License</Text>
              </View>
            )}
          </Pressable>
        </View>

        <View style={styles.inputGroup}>
          <Text style={styles.label}>Owner ID Photo</Text>
          <Pressable style={styles.uploadBtn} onPress={() => pickImage('id')}>
            {ownerIdPhoto ? (
              <Image source={{ uri: ownerIdPhoto }} style={styles.uploadPreview} />
            ) : (
              <View style={styles.uploadPlaceholder}>
                <Ionicons name="id-card-outline" size={24} color={Colors.textTertiary} />
                <Text style={styles.uploadText}>Upload Owner ID</Text>
              </View>
            )}
          </Pressable>
        </View>

        <InputField label="Password" icon="lock-closed-outline" value={password} onChangeText={setPassword} placeholder="Create a password" secure />

        <View style={styles.inputGroup}>
          <Text style={styles.label}>City / Region</Text>
          <Pressable style={styles.selectBtn} onPress={() => setShowRegions(!showRegions)}>
            <Ionicons name="location-outline" size={18} color={selectedRegion ? Colors.text : Colors.textTertiary} />
            <Text style={[styles.selectText, !selectedRegion && { color: Colors.textTertiary }]}>
              {selectedRegion ? selectedRegion.label : 'Select your city'}
            </Text>
            <Ionicons name={showRegions ? "chevron-up" : "chevron-down"} size={16} color={Colors.textTertiary} />
          </Pressable>
          {showRegions && (
            <View style={styles.regionList}>
              {REGIONS.map(r => (
                <Pressable
                  key={r.label}
                  style={[styles.regionItem, selectedRegion?.label === r.label && styles.regionItemActive]}
                  onPress={() => { setSelectedRegion(r); setShowRegions(false); }}
                >
                  <Text style={[styles.regionItemText, selectedRegion?.label === r.label && styles.regionItemTextActive]}>{r.label}</Text>
                  {selectedRegion?.label === r.label && <Ionicons name="checkmark" size={18} color={Colors.primary} />}
                </Pressable>
              ))}
            </View>
          )}
        </View>

        <Pressable
          style={({ pressed }) => [styles.createBtn, pressed && { opacity: 0.9 }, loading && { opacity: 0.7 }]}
          onPress={handleCreate}
          disabled={loading}
        >
          {loading ? <ActivityIndicator color={Colors.white} /> : <Text style={styles.createBtnText}>Create Account</Text>}
        </Pressable>
      </View>
    </KeyboardAwareScrollViewCompat>
  );
}

function InputField({ label, icon, value, onChangeText, placeholder, keyboardType, secure }: any) {
  const [show, setShow] = useState(false);
  return (
    <View style={styles.inputGroup}>
      <Text style={styles.label}>{label}</Text>
      <View style={styles.inputWrap}>
        <Ionicons name={icon} size={18} color={Colors.textTertiary} />
        <TextInput
          style={styles.input}
          placeholder={placeholder}
          placeholderTextColor={Colors.textTertiary}
          value={value}
          onChangeText={onChangeText}
          keyboardType={keyboardType}
          autoCapitalize={keyboardType === 'email-address' ? 'none' : keyboardType === 'phone-pad' ? 'none' : 'words'}
          secureTextEntry={secure && !show}
        />
        {secure && (
          <Pressable onPress={() => setShow(!show)} hitSlop={8}>
            <Ionicons name={show ? "eye-off-outline" : "eye-outline"} size={18} color={Colors.textTertiary} />
          </Pressable>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  content: { padding: 24, gap: 24 },
  header: { alignItems: 'center', gap: 12 },
  iconWrap: {
    width: 48,
    height: 48,
    borderRadius: 14,
    backgroundColor: 'rgba(69,123,157,0.1)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: { fontSize: 22, fontFamily: 'Inter_700Bold', color: Colors.text },
  form: { gap: 18 },
  inputGroup: { gap: 6 },
  label: { fontSize: 13, fontFamily: 'Inter_600SemiBold', color: Colors.text, marginLeft: 4 },
  inputWrap: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    backgroundColor: Colors.surface,
    borderWidth: 1,
    borderColor: Colors.inputBorder,
    borderRadius: 12,
    paddingHorizontal: 14,
    height: 50,
  },
  input: { flex: 1, fontSize: 15, fontFamily: 'Inter_400Regular', color: Colors.text },
  selectBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    backgroundColor: Colors.surface,
    borderWidth: 1,
    borderColor: Colors.inputBorder,
    borderRadius: 12,
    paddingHorizontal: 14,
    height: 50,
  },
  selectText: { flex: 1, fontSize: 15, fontFamily: 'Inter_400Regular', color: Colors.text },
  regionList: {
    backgroundColor: Colors.surface,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: Colors.inputBorder,
    maxHeight: 200,
  },
  regionItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 12,
    paddingHorizontal: 14,
    borderBottomWidth: 0.5,
    borderBottomColor: Colors.divider,
  },
  regionItemActive: { backgroundColor: 'rgba(27,58,92,0.05)' },
  regionItemText: { fontSize: 14, fontFamily: 'Inter_400Regular', color: Colors.text },
  regionItemTextActive: { fontFamily: 'Inter_600SemiBold', color: Colors.primary },
  uploadBtn: {
    borderRadius: 12,
    borderWidth: 1,
    borderColor: Colors.inputBorder,
    borderStyle: 'dashed' as const,
    overflow: 'hidden',
    backgroundColor: Colors.surface,
  },
  uploadPlaceholder: { paddingVertical: 24, alignItems: 'center', gap: 8 },
  uploadText: { fontSize: 13, fontFamily: 'Inter_400Regular', color: Colors.textTertiary },
  uploadPreview: { width: '100%', height: 120, resizeMode: 'cover' as const },
  createBtn: {
    backgroundColor: Colors.primary,
    borderRadius: 14,
    height: 52,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 8,
  },
  createBtnText: { fontSize: 16, fontFamily: 'Inter_600SemiBold', color: Colors.white },
});
