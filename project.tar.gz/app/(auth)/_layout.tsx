import { Stack } from "expo-router";
import { router } from "expo-router";
import { Pressable } from "react-native";
import { Ionicons } from "@expo/vector-icons";

export default function AuthLayout() {
  return (
    <Stack
      screenOptions={{
        headerStyle: { backgroundColor: '#F0F2F5' },
        headerTintColor: '#1B3A5C',
        headerTitleStyle: { fontFamily: 'Inter_600SemiBold' },
        headerLeft: () => (
          <Pressable onPress={() => router.replace('/')} hitSlop={12} style={{ marginRight: 8 }}>
            <Ionicons name="arrow-back" size={24} color="#1B3A5C" />
          </Pressable>
        ),
      }}
    >
      <Stack.Screen name="login" options={{ title: "Sign In" }} />
      <Stack.Screen name="create-ems" options={{ title: "EMS Account" }} />
      <Stack.Screen name="create-company" options={{ title: "Company Account" }} />
      <Stack.Screen name="forgot-password" options={{ title: "Reset Password" }} />
    </Stack>
  );
}
