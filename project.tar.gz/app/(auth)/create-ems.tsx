import React, { useState } from 'react';
import { View, Text, TextInput, Pressable, StyleSheet, Alert, ActivityIndicator, Image, Platform } from 'react-native';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import Colors from '@/constants/colors';
import { useAuth } from '@/lib/auth-context';
import { REGIONS, CertType, RegionOption } from '@/lib/storage';
import { KeyboardAwareScrollViewCompat } from '@/components/KeyboardAwareScrollViewCompat';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import * as ImagePicker from 'expo-image-picker';
import * as FileSystem from 'expo-file-system';

export default function CreateEMSScreen() {
  const { register } = useAuth();
  const insets = useSafeAreaInsets();
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [certType, setCertType] = useState<CertType>('EMT');
  const [certImage, setCertImage] = useState<string | undefined>();
  const [licenseImage, setLicenseImage] = useState<string | undefined>();
  const [selectedRegion, setSelectedRegion] = useState<RegionOption | null>(null);
  const [showRegions, setShowRegions] = useState(false);
  const [loading, setLoading] = useState(false);

  const convertToBase64 = async (uri: string): Promise<string> => {
    if (Platform.OS === 'web') {
      const response = await fetch(uri);
      const blob = await response.blob();
      return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onloadend = () => resolve(reader.result as string);
        reader.onerror = reject;
        reader.readAsDataURL(blob);
      });
    }
    const base64 = await FileSystem.readAsStringAsync(uri, { encoding: FileSystem.EncodingType.Base64 });
    return `data:image/jpeg;base64,${base64}`;
  };

  const pickImage = async (type: 'cert' | 'license') => {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ['images'],
      quality: 0.5,
    });
    if (!result.canceled && result.assets[0]) {
      if (type === 'cert') setCertImage(result.assets[0].uri);
      else setLicenseImage(result.assets[0].uri);
    }
  };

  const handleCreate = async () => {
    if (!fullName.trim() || !email.trim() || !password.trim() || !selectedRegion) {
      Alert.alert('Missing Fields', 'Please fill in all required fields.');
      return;
    }
    if (password.length < 6) {
      Alert.alert('Weak Password', 'Password must be at least 6 characters.');
      return;
    }
    setLoading(true);
    try {
      let certBase64: string | undefined;
      let licenseBase64: string | undefined;
      if (certImage) certBase64 = await convertToBase64(certImage);
      if (licenseImage) licenseBase64 = await convertToBase64(licenseImage);

      await register({
        role: 'ems',
        email: email.trim(),
        password,
        fullName: fullName.trim(),
        certType,
        certificationImage: certBase64,
        licenseImage: licenseBase64,
        city: selectedRegion.city,
        state: selectedRegion.state,
      });
    } catch (err: any) {
      Alert.alert('Error', err.message);
      setLoading(false);
    }
  };

  return (
    <KeyboardAwareScrollViewCompat
      style={styles.container}
      contentContainerStyle={[styles.content, { paddingBottom: insets.bottom + 20 }]}
      bottomOffset={60}
    >
      <View style={styles.header}>
        <View style={styles.iconWrap}>
          <Ionicons name="medkit" size={24} color={Colors.accent} />
        </View>
        <Text style={styles.title}>EMS Registration</Text>
      </View>

      <View style={styles.form}>
        <InputField label="Full Name" icon="person-outline" value={fullName} onChangeText={setFullName} placeholder="Enter your full name" />
        <InputField label="Email" icon="mail-outline" value={email} onChangeText={setEmail} placeholder="Enter your email" keyboardType="email-address" />
        <InputField label="Password" icon="lock-closed-outline" value={password} onChangeText={setPassword} placeholder="Create a password" secure />

        <View style={styles.inputGroup}>
          <Text style={styles.label}>Certification Type</Text>
          <View style={styles.certRow}>
            {(['EMT', 'Paramedic'] as CertType[]).map(type => (
              <Pressable
                key={type}
                style={[styles.certChip, certType === type && styles.certChipActive]}
                onPress={() => setCertType(type)}
              >
                <Text style={[styles.certChipText, certType === type && styles.certChipTextActive]}>
                  {type}
                </Text>
              </Pressable>
            ))}
          </View>
        </View>

        <View style={styles.inputGroup}>
          <Text style={styles.label}>Certification Image</Text>
          <Pressable style={styles.uploadBtn} onPress={() => pickImage('cert')}>
            {certImage ? (
              <Image source={{ uri: certImage }} style={styles.uploadPreview} />
            ) : (
              <View style={styles.uploadPlaceholder}>
                <Ionicons name="camera-outline" size={24} color={Colors.textTertiary} />
                <Text style={styles.uploadText}>Upload Certificate</Text>
              </View>
            )}
          </Pressable>
        </View>

        <View style={styles.inputGroup}>
          <Text style={styles.label}>Work License / ID</Text>
          <Pressable style={styles.uploadBtn} onPress={() => pickImage('license')}>
            {licenseImage ? (
              <Image source={{ uri: licenseImage }} style={styles.uploadPreview} />
            ) : (
              <View style={styles.uploadPlaceholder}>
                <Ionicons name="id-card-outline" size={24} color={Colors.textTertiary} />
                <Text style={styles.uploadText}>Upload License</Text>
              </View>
            )}
          </Pressable>
        </View>

        <View style={styles.inputGroup}>
          <Text style={styles.label}>City / Region</Text>
          <Pressable style={styles.selectBtn} onPress={() => setShowRegions(!showRegions)}>
            <Ionicons name="location-outline" size={18} color={selectedRegion ? Colors.text : Colors.textTertiary} />
            <Text style={[styles.selectText, !selectedRegion && { color: Colors.textTertiary }]}>
              {selectedRegion ? selectedRegion.label : 'Select your city'}
            </Text>
            <Ionicons name={showRegions ? "chevron-up" : "chevron-down"} size={16} color={Colors.textTertiary} />
          </Pressable>
          {showRegions && (
            <View style={styles.regionList}>
              {REGIONS.map(r => (
                <Pressable
                  key={r.label}
                  style={[styles.regionItem, selectedRegion?.label === r.label && styles.regionItemActive]}
                  onPress={() => { setSelectedRegion(r); setShowRegions(false); }}
                >
                  <Text style={[styles.regionItemText, selectedRegion?.label === r.label && styles.regionItemTextActive]}>{r.label}</Text>
                  {selectedRegion?.label === r.label && <Ionicons name="checkmark" size={18} color={Colors.primary} />}
                </Pressable>
              ))}
            </View>
          )}
        </View>

        <Pressable
          style={({ pressed }) => [styles.createBtn, pressed && { opacity: 0.9 }, loading && { opacity: 0.7 }]}
          onPress={handleCreate}
          disabled={loading}
        >
          {loading ? <ActivityIndicator color={Colors.white} /> : <Text style={styles.createBtnText}>Create Account</Text>}
        </Pressable>
      </View>
    </KeyboardAwareScrollViewCompat>
  );
}

function InputField({ label, icon, value, onChangeText, placeholder, keyboardType, secure }: any) {
  const [show, setShow] = useState(false);
  return (
    <View style={styles.inputGroup}>
      <Text style={styles.label}>{label}</Text>
      <View style={styles.inputWrap}>
        <Ionicons name={icon} size={18} color={Colors.textTertiary} />
        <TextInput
          style={styles.input}
          placeholder={placeholder}
          placeholderTextColor={Colors.textTertiary}
          value={value}
          onChangeText={onChangeText}
          keyboardType={keyboardType}
          autoCapitalize={keyboardType === 'email-address' ? 'none' : 'words'}
          secureTextEntry={secure && !show}
        />
        {secure && (
          <Pressable onPress={() => setShow(!show)} hitSlop={8}>
            <Ionicons name={show ? "eye-off-outline" : "eye-outline"} size={18} color={Colors.textTertiary} />
          </Pressable>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.background },
  content: { padding: 24, gap: 24 },
  header: { alignItems: 'center', gap: 12 },
  iconWrap: {
    width: 48,
    height: 48,
    borderRadius: 14,
    backgroundColor: 'rgba(230,57,70,0.1)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: { fontSize: 22, fontFamily: 'Inter_700Bold', color: Colors.text },
  form: { gap: 18 },
  inputGroup: { gap: 6 },
  label: { fontSize: 13, fontFamily: 'Inter_600SemiBold', color: Colors.text, marginLeft: 4 },
  inputWrap: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    backgroundColor: Colors.surface,
    borderWidth: 1,
    borderColor: Colors.inputBorder,
    borderRadius: 12,
    paddingHorizontal: 14,
    height: 50,
  },
  input: { flex: 1, fontSize: 15, fontFamily: 'Inter_400Regular', color: Colors.text },
  certRow: { flexDirection: 'row', gap: 10 },
  certChip: {
    flex: 1,
    paddingVertical: 12,
    borderRadius: 10,
    backgroundColor: Colors.surface,
    borderWidth: 1,
    borderColor: Colors.inputBorder,
    alignItems: 'center',
  },
  certChipActive: { backgroundColor: Colors.primary, borderColor: Colors.primary },
  certChipText: { fontSize: 14, fontFamily: 'Inter_500Medium', color: Colors.text },
  certChipTextActive: { color: Colors.white },
  uploadBtn: {
    borderRadius: 12,
    borderWidth: 1,
    borderColor: Colors.inputBorder,
    borderStyle: 'dashed',
    overflow: 'hidden',
    backgroundColor: Colors.surface,
  },
  uploadPlaceholder: { paddingVertical: 24, alignItems: 'center', gap: 8 },
  uploadText: { fontSize: 13, fontFamily: 'Inter_400Regular', color: Colors.textTertiary },
  uploadPreview: { width: '100%', height: 120, resizeMode: 'cover' },
  selectBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    backgroundColor: Colors.surface,
    borderWidth: 1,
    borderColor: Colors.inputBorder,
    borderRadius: 12,
    paddingHorizontal: 14,
    height: 50,
  },
  selectText: { flex: 1, fontSize: 15, fontFamily: 'Inter_400Regular', color: Colors.text },
  regionList: {
    backgroundColor: Colors.surface,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: Colors.inputBorder,
    maxHeight: 200,
  },
  regionItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 12,
    paddingHorizontal: 14,
    borderBottomWidth: 0.5,
    borderBottomColor: Colors.divider,
  },
  regionItemActive: { backgroundColor: 'rgba(27,58,92,0.05)' },
  regionItemText: { fontSize: 14, fontFamily: 'Inter_400Regular', color: Colors.text },
  regionItemTextActive: { fontFamily: 'Inter_600SemiBold', color: Colors.primary },
  createBtn: {
    backgroundColor: Colors.primary,
    borderRadius: 14,
    height: 52,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 8,
  },
  createBtnText: { fontSize: 16, fontFamily: 'Inter_600SemiBold', color: Colors.white },
});
