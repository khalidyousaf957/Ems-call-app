import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, boolean, timestamp, doublePrecision, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const roleEnum = pgEnum("user_role", ["ems", "company", "admin"]);
export const certTypeEnum = pgEnum("cert_type", ["EMT", "Paramedic"]);
export const callStatusEnum = pgEnum("call_status", ["open", "pending", "accepted", "in_progress", "completed"]);
export const negotiationStatusEnum = pgEnum("negotiation_status", ["pending", "negotiating", "accepted", "rejected"]);
export const shiftStatusEnum = pgEnum("shift_status", ["active", "ended_pending", "completed"]);
export const ticketStatusEnum = pgEnum("ticket_status", ["open", "in_review", "resolved"]);

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  role: roleEnum("role").notNull(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  fullName: text("full_name"),
  certType: certTypeEnum("cert_type"),
  certificationImage: text("certification_image"),
  licenseImage: text("license_image"),
  companyName: text("company_name"),
  ownerName: text("owner_name"),
  phone: text("phone"),
  licenseNumber: text("license_number"),
  city: text("city"),
  state: text("state"),
  balance: doublePrecision("balance").default(0).notNull(),
  postsToday: integer("posts_today").default(0).notNull(),
  lastPostDate: text("last_post_date"),
  bankName: text("bank_name"),
  bankAccountLast4: text("bank_account_last4"),
  subscriptionPaidThrough: text("subscription_paid_through"),
  adsUnlocked: boolean("ads_unlocked").default(false).notNull(),
  isVerified: boolean("is_verified").default(false).notNull(),
  isSuspended: boolean("is_suspended").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const calls = pgTable("calls", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  companyId: varchar("company_id").notNull().references(() => users.id),
  companyName: text("company_name").notNull(),
  jobType: text("job_type").notNull(),
  location: text("location").notNull(),
  startTime: text("start_time").notNull(),
  endTime: text("end_time").notNull(),
  certRequired: certTypeEnum("cert_required").notNull(),
  numberNeeded: integer("number_needed").notNull(),
  payRate: doublePrecision("pay_rate").notNull(),
  city: text("city").notNull(),
  state: text("state").notNull(),
  status: callStatusEnum("status").default("open").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const applications = pgTable("applications", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  callId: varchar("call_id").notNull().references(() => calls.id),
  emsId: varchar("ems_id").notNull().references(() => users.id),
  emsName: text("ems_name").notNull(),
  emsCertType: certTypeEnum("ems_cert_type").notNull(),
  status: negotiationStatusEnum("status").default("pending").notNull(),
  proposedPay: doublePrecision("proposed_pay").notNull(),
  originalPay: doublePrecision("original_pay").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const negotiationMessages = pgTable("negotiation_messages", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  applicationId: varchar("application_id").notNull().references(() => applications.id),
  senderId: varchar("sender_id").notNull(),
  senderRole: roleEnum("sender_role").notNull(),
  message: text("message").notNull(),
  proposedPay: doublePrecision("proposed_pay"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const shifts = pgTable("shifts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  callId: varchar("call_id").notNull().references(() => calls.id),
  applicationId: varchar("application_id").notNull().references(() => applications.id),
  emsId: varchar("ems_id").notNull().references(() => users.id),
  companyId: varchar("company_id").notNull().references(() => users.id),
  startedAt: text("started_at").notNull(),
  endedAt: text("ended_at"),
  confirmedAt: text("confirmed_at"),
  payAmount: doublePrecision("pay_amount").notNull(),
  status: shiftStatusEnum("status").default("active").notNull(),
});

export const supportTickets = pgTable("support_tickets", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  userRole: roleEnum("user_role").notNull(),
  userName: text("user_name").notNull(),
  category: text("category").notNull(),
  subject: text("subject").notNull(),
  description: text("description").notNull(),
  status: ticketStatusEnum("status").default("open").notNull(),
  adminNote: text("admin_note"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const adUnlockRequestStatusEnum = pgEnum("ad_unlock_request_status", ["pending", "approved", "rejected"]);

export const adUnlockRequests = pgTable("ad_unlock_requests", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  companyId: varchar("company_id").notNull().references(() => users.id),
  companyName: text("company_name").notNull(),
  status: adUnlockRequestStatusEnum("status").default("pending").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  reviewedAt: timestamp("reviewed_at"),
});

export const announcements = pgTable("announcements", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  message: text("message").notNull(),
  image: text("image"),
  city: text("city"),
  state: text("state"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const premiumAdStatusEnum = pgEnum("premium_ad_status", ["active", "expired"]);

export const premiumAds = pgTable("premium_ads", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  companyId: varchar("company_id").notNull().references(() => users.id),
  companyName: text("company_name").notNull(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  hourlyRate: doublePrecision("hourly_rate").notNull(),
  daysNeeded: integer("days_needed").notNull(),
  whyBest: text("why_best").notNull(),
  city: text("city").notNull(),
  state: text("state").notNull(),
  status: premiumAdStatusEnum("status").default("active").notNull(),
  paidAmount: doublePrecision("paid_amount").default(69).notNull(),
  startDate: timestamp("start_date").defaultNow().notNull(),
  endDate: timestamp("end_date").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const withdrawalStatusEnum = pgEnum("withdrawal_status", ["pending", "completed", "rejected"]);
export const withdrawalMethodEnum = pgEnum("withdrawal_method", ["bank", "cashapp"]);

export const withdrawals = pgTable("withdrawals", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  amount: doublePrecision("amount").notNull(),
  method: withdrawalMethodEnum("method").notNull(),
  status: withdrawalStatusEnum("status").default("pending").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  email: true,
  password: true,
  role: true,
  fullName: true,
  certType: true,
  certificationImage: true,
  licenseImage: true,
  companyName: true,
  ownerName: true,
  phone: true,
  licenseNumber: true,
  city: true,
  state: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type Call = typeof calls.$inferSelect;
export type Application = typeof applications.$inferSelect;
export type NegotiationMessage = typeof negotiationMessages.$inferSelect;
export type Shift = typeof shifts.$inferSelect;
export type SupportTicket = typeof supportTickets.$inferSelect;
export type Announcement = typeof announcements.$inferSelect;
export type PremiumAd = typeof premiumAds.$inferSelect;
export type Withdrawal = typeof withdrawals.$inferSelect;
export type AdUnlockRequest = typeof adUnlockRequests.$inferSelect;
